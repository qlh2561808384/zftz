create trigger T_SRFX_CZFC_FC_DELETE
  after delete
  on SRFX_DM_FC
  for each row
  declare
  --a number;
begin
delete from srfx_dm_czfp where czfp_dm=:old.czfp_dm;
end t_srfx_czfc_fc_delete;
/

