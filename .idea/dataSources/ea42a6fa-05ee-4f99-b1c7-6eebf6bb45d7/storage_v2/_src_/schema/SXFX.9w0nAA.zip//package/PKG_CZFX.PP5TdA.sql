create package pkg_czfx is
  type cur is ref cursor;

  procedure GET_CZFX_JCGC_ZBMX(riqi varchar2);
  procedure GET_CZFX_JCGC_YKJH(riqi varchar2);
  procedure GET_CZFX_JCGC_ZFMX(riqi varchar2);
  procedure GET_CZFX_JCGC_ZBZXHZ(riqi varchar2);
  procedure GET_CZFX_JCGC_ZFZXHZ(riqi varchar2);
  procedure GET_CZFX_ZKJ_DYB(riqi varchar2);
  procedure GET_CZFX_ZKJ_BJ(riqi varchar2);

  -- procedure GET_CZFX_JCGC_ZBZXHZ(riqi varchar2);

end pkg_czfx;
/

