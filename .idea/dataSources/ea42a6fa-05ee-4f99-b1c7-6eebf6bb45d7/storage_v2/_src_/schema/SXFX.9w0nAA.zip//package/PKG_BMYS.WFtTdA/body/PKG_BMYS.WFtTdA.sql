create package body pkg_bmys is
/* 
procedure GET_CZFX_DM_YSDWRY(riqi varchar2) is
  begin
      commit;
end;
*/
 procedure GET_CZFX_BMYS_YSMX(riqi varchar2) is

  begin
delete from czfx_bmys_ysmx where year=substr(riqi, 0, 4) ;
insert into czfx_bmys_ysmx
select aa.xzqh,
       aa.year,
       aa.startdate,
       aa.enddate,
       -------预算单位编码--------
       case
         when (select a.bmys
                 from czfx_dm_bmbqd a
                where a.bmb = 'CZFX_DM_YSDW') = 1 then
          (select case
                    when a1.dwbm is null then
                     '-1'
                    else
                     a1.dwbm
                  end
             from v_sx_bmys_efm_t_division t
             left join CZFX_DM_YSDW a1
               on t.divshowid = a1.dwbm
            where t.divid = aa.divid
            and t.nd=substr(riqi, 0, 4)
            )
         when (select a2.bmys
                 from czfx_dm_bmbqd a2
                where a2.bmb = 'CZFX_DM_YSDW') = 2 then
          (select case
                    when a3.bm is null then
                     '-1'
                    else
                     a3.bm
                  end
             from v_sx_bmys_efm_t_division t
             left join (select *
                         from czfx_dm_dygx t1
                        where t1.bmb = 'CZFX_DM_YSDW'
                          and t1.dynf = substr(riqi, 0, 4)
                          and t1.dyxzqh = '3306010101'
                          and t1.dyly = 0) a3
               on t.divshowid = a3.dybm
            where t.divid = aa.divid
            and t.nd=substr(riqi, 0, 4)
            )
         else
          '-1'
       end dwbm,
       ----------------------
       --(select t.divshowid from EFM_TRA_ZJSX_substr(riqi, 0, 4).Efm_t_Division t where t.divid=aa.divid) dwbm,
      -- '' dwmc, --(select t.divname from EFM_TRA_ZJSX_substr(riqi, 0, 4).Efm_t_Division t where t.divid=aa.divid) dwmc,
      -- '' zgdwbm, /*(select t1.divshowid from EFM_TRA_ZJSX_substr(riqi, 0, 4).EFM_T_DIVISION t left join EFM_TRA_ZJSX_substr(riqi, 0, 4).EFM_T_DIVISION t1
                                   --on t.superid=t1.divid where t.divid=aa.divid ) zgdwbm*/
      -- '' zgdwmc, /*(select t1.divname from EFM_TRA_ZJSX_substr(riqi, 0, 4).EFM_T_DIVISION t left join EFM_TRA_ZJSX_substr(riqi, 0, 4).EFM_T_DIVISION t1
                                  -- on t.superid=t1.divid where t.divid=aa.divid ) zgdwmc，*/
      -- '' ssgkbm,
      -- '' ssgkmc,
       /*(select t1.deptcode from EFM_TRA_ZJSX_substr(riqi, 0, 4).exp_t_deptdiv t left join EFM_TRA_ZJSX_substr(riqi, 0, 4).efm_t_dept t1
       on t.deptid=t1.deptid where t.divid=aa.divid ) ssgkbm,
              (select t1.deptname from EFM_TRA_ZJSX_substr(riqi, 0, 4).exp_t_deptdiv t left join EFM_TRA_ZJSX_substr(riqi, 0, 4).efm_t_dept t1
       on t.deptid=t1.deptid where t.divid=aa.divid ) ssgkmc,*/
       -----------单位性质-------
       case
         when (select a.bmys
                 from czfx_dm_bmbqd a
                where a.bmb = 'CZFX_DM_DWXZ') = 1 then
          (select case
                    when t4.bm is null then
                     '-1'
                    else
                     t4.bm
                  end
             from v_sx_bmys_bas_t_ysdwjbxxb t
             left join v_sx_bmys_ref_t_djc_dwxz t1
               on t.dwxz2748 = t1.refid
               and t.nd=t1.nd
             left join v_sx_bmys_efm_t_division t3
               on t.divid = t3.divid
               and t.nd=t3.nd
             left join CZFX_DM_DWXZ t4
               on t1.refcode = t4.bm
            where t.divid = aa.divid
            and t.nd=substr(riqi, 0, 4)
            )
         when (select a2.bmys
                 from czfx_dm_bmbqd a2
                where a2.bmb = 'CZFX_DM_DWXZ') = 2 then
          (select case
                    when t4.bm is null then
                     '-1'
                    else
                     t4.bm
                  end
             from v_sx_bmys_bas_t_ysdwjbxxb t
             left join v_sx_bmys_ref_t_djc_dwxz t1
               on t.dwxz2748 = t1.refid
               and t.nd=t1.nd
             left join v_sx_bmys_efm_t_division t3
               on t.divid = t3.divid
               and t.nd=t3.nd
             left join (select *
                         from czfx_dm_dygx a
                        where a.bmb = 'CZFX_DM_DWXZ'
                          and a.dyly = 1
                          and a.dyxzqh = 0
                          and a.dynf = 0) t4
               on t1.refcode = t4.dybm
            where t.divid = aa.divid
            and t.nd=substr(riqi, 0, 4)
            )
         else
          '-1'
       end dwxz,
       -- aa.divid,
       -------------单位性质级别---------------
       case
         when (select a.bmys
                 from czfx_dm_bmbqd a
                where a.bmb = 'CZFX_DM_DWXZJB') = 1 then
          (select case
                    when t4.bm is null then
                     '-1'
                    else
                     t4.bm
                  end
             from v_sx_bmys_bas_t_ysdwjbxxb t
             left join v_sx_bmys_ref_t_djc_dwxzjb t1
               on t.dwjb4956 = t1.refid
               and t.nd=t1.nd
             left join v_sx_bmys_efm_t_division t3
               on t.divid = t3.divid
               and t.nd=t3.nd
             left join CZFX_DM_DWXZJB t4
               on t1.refcode = t4.bm
            where t.divid = aa.divid
            and t.nd=substr(riqi, 0, 4)
            )
         when (select a2.bmys
                 from czfx_dm_bmbqd a2
                where a2.bmb = 'CZFX_DM_DWXZJB') = 2 then
          (select case
                    when t4.bm is null then
                     '-1'
                    else
                     t4.bm
                  end
             from v_sx_bmys_bas_t_ysdwjbxxb t
             left join v_sx_bmys_ref_t_djc_dwxzjb t1
               on t.dwjb4956 = t1.refid
               and t.nd=t1.nd
             left join v_sx_bmys_efm_t_division t3
               on t.divid = t3.divid
               and t.nd=t3.nd
             left join (select *
                         from czfx_dm_dygx a
                        where a.bmb = 'CZFX_DM_DWXZJB'
                          and a.dyly = 1
                          and a.dyxzqh = 0
                          and a.dynf = 0) t4
               on t1.refcode = t4.dybm
            where t.divid = aa.divid and t.nd=substr(riqi, 0, 4) )
         else
          '-1'
       end dwxzjb,
       -----------单位类别--------------------------
       case
         when (select a.bmys
                 from czfx_dm_bmbqd a
                where a.bmb = 'CZFX_DM_DWLB') = 1 then
          (select case
                    when t4.bm is null then
                     '-1'
                    else
                     t4.bm
                  end
             from v_sx_bmys_bas_t_ysdwjbxxb t
             left join v_sx_bmys_ref_t_djc_dwlb t1
               on t.dwlb2179 = t1.refid
               and t.nd=t1.nd
             left join v_sx_bmys_efm_t_division t3
               on t.divid = t3.divid
               and t.nd=t3.nd
             left join CZFX_DM_DWLB t4
               on t1.refcode = t4.bm
            where t.divid = aa.divid
            and t.nd=substr(riqi, 0, 4)
            )
         when (select a2.bmys
                 from czfx_dm_bmbqd a2
                where a2.bmb = 'CZFX_DM_DWLB') = 2 then
          (select case
                    when t4.bm is null then
                     '-1'
                    else
                     t4.bm
                  end
             from v_sx_bmys_bas_t_ysdwjbxxb t
             left join v_sx_bmys_ref_t_djc_dwlb t1
               on t.dwlb2179 = t1.refid
               and t.nd=t1.nd
             left join v_sx_bmys_efm_t_division t3
               on t.divid = t3.divid
               and t.nd=t3.nd
             left join (select *
                         from czfx_dm_dygx a
                        where a.bmb = 'CZFX_DM_DWLB'
                          and a.dyly = 1
                          and a.dyxzqh = 0
                          and a.dynf = 0) t4
               on t1.refcode = t4.dybm
            where t.divid = aa.divid
            and t.nd=substr(riqi, 0, 4)
            )
         else
          '-1'
       end dwlb,
       -------功能科目----------------------------
       case
         when (select a.bmys
                 from czfx_dm_bmbqd a
                where a.bmb = 'CZFX_DM_GNKM') = 1 then
          (select case
                    when t4.bm is null then
                     '-1'
                    else
                     t4.bm
                  end
             from v_sx_bmys_efm_t_acctitem t
             left join CZFX_DM_GNKM t4
               on t.acctcode = t4.bm
            where t.acctid = aa.acctcode
            and t.nd=substr(riqi, 0, 4)
            )
         when (select a2.bmys
                 from czfx_dm_bmbqd a2
                where a2.bmb = 'CZFX_DM_GNKM') = 2 then
          (select case
                    when t4.bm is null then
                     '-1'
                    else
                     t4.bm
                  end
             from v_sx_bmys_efm_t_acctitem t
             left join (select *
                         from czfx_dm_dygx a
                        where a.bmb = 'CZFX_DM_GNKM'
                          and a.dyly = 1
                          and a.dyxzqh = 0
                          and a.dynf = 0) t4
               on t.acctcode = t4.dybm
            where t.acctid = aa.acctcode
            and t.nd=substr(riqi, 0, 4)
            )
         else
          '-1'
       end gnkmbm,
       ----------------------------------------------
      -- '' gnkmmc, /*(select a.acctname
        --                              from EFM_TRA_ZJSX_substr(riqi, 0, 4).efm_t_acctitem a
          --                           where a.acctid = aa.acctcode) gnkmmc,*/
       --aa.acctcode,
       ---政府经济科目--------------------
       case
         when (select a.bmys
                 from czfx_dm_bmbqd a
                where a.bmb = 'CZFX_DM_ZFJJKM') = 1 and aa.divid in
                         (select t.divid
                            from v_sx_bmys_bas_t_ysdwjbxxb t
                           where t.dwxz2748 in
                                 ('F0917CEEE75240568BBF0F13AEA164CD',
                                  '6B5AA03D688F4F9E9C5655679D66072D') and t.nd=substr(riqi, 0, 4) )then
                                  (select case when 
                                  (select zf1.bm from v_sx_bmys_bgt_t_dzfbmjjkmdyb zf 
                                  left join czfx_dm_zfjjkm zf1 on zf.d_zfjgjjkm=zf1.bm
                                  where zf.d_bmjjkm=aa.acctcode_jj and zf.nd=substr(riqi, 0, 4)) is null then '-1' else 
                                  (select zf1.bm from v_sx_bmys_bgt_t_dzfbmjjkmdyb zf 
                                  left join czfx_dm_zfjjkm zf1 on zf.d_zfjgjjkm=zf1.bm
                                  where zf.d_bmjjkm=aa.acctcode_jj and zf.nd=substr(riqi, 0, 4)) end from dual)
                                  
               
           --
           when (select a.bmys
                 from czfx_dm_bmbqd a
                where a.bmb = 'CZFX_DM_ZFJJKM') = 1 and aa.divid in
                         (select t.divid
                            from v_sx_bmys_bas_t_ysdwjbxxb t
                           where t.dwxz2748 not in
                                 ('F0917CEEE75240568BBF0F13AEA164CD',
                                  '6B5AA03D688F4F9E9C5655679D66072D') and t.nd=substr(riqi, 0, 4)  )then
                                  (select case when 
                                  (select zf1.bm from v_sx_bmys_bgt_t_dzfbmjjkmdyb zf 
                                  left join czfx_dm_zfjjkm zf1 on zf.d_zfsyjjkm=zf1.bm
                                  where zf.d_bmjjkm=aa.acctcode_jj and zf.nd=substr(riqi, 0, 4) ) is null then '-1' else 
                                  (select zf1.bm from v_sx_bmys_bgt_t_dzfbmjjkmdyb zf 
                                  left join czfx_dm_zfjjkm zf1 on zf.d_zfsyjjkm=zf1.bm
                                  where zf.d_bmjjkm=aa.acctcode_jj and zf.nd=substr(riqi, 0, 4) ) end from dual)
           --
           ------------------------------------
           when (select a.bmys
                 from czfx_dm_bmbqd a
                where a.bmb = 'CZFX_DM_ZFJJKM') = 2 and aa.divid in
                         (select t.divid
                            from v_sx_bmys_bas_t_ysdwjbxxb t
                           where t.dwxz2748  in
                                 ('F0917CEEE75240568BBF0F13AEA164CD',
                                  '6B5AA03D688F4F9E9C5655679D66072D') and t.nd=substr(riqi, 0, 4) )then
                                  (select case when 
                                  (select zf1.bm from v_sx_bmys_bgt_t_dzfbmjjkmdyb zf 
                                  left join (select * from czfx_dm_dygx zz where zz.dyly=1 and zz.dyxzqh='0' and zz.dynf='0' and zz.bmb='CZFX_DM_ZFJJKM') zf1 on zf.d_zfsyjjkm=zf1.dybm
                                  where zf.d_bmjjkm=aa.acctcode_jj and zf.nd=substr(riqi, 0, 4)) is null then '-1' else 
                                  (select zf1.bm from v_sx_bmys_bgt_t_dzfbmjjkmdyb zf 
                                  left join (select * from czfx_dm_dygx zz where zz.dyly=1 and zz.dyxzqh='0' and zz.dynf='0' and zz.bmb='CZFX_DM_ZFJJKM') zf1 on zf.d_zfsyjjkm=zf1.bm
                                  where zf.d_bmjjkm=aa.acctcode_jj and zf.nd=substr(riqi, 0, 4) ) end from dual)
                                   when (select a.bmys
                 from czfx_dm_bmbqd a
                where a.bmb = 'CZFX_DM_ZFJJKM') = 2 and aa.divid in
                         (select t.divid
                            from v_sx_bmys_bas_t_ysdwjbxxb t
                           where t.dwxz2748 not in
                                 ('F0917CEEE75240568BBF0F13AEA164CD',
                                  '6B5AA03D688F4F9E9C5655679D66072D') and t.nd=substr(riqi, 0, 4))then
                                  (select case when 
                                  (select zf1.bm from v_sx_bmys_bgt_t_dzfbmjjkmdyb zf 
                                  left join (select * from czfx_dm_dygx zz where zz.dyly=1 and zz.dyxzqh='0' and zz.dynf='0' and zz.bmb='CZFX_DM_ZFJJKM') zf1 on zf.d_zfsyjjkm=zf1.dybm
                                  where zf.d_bmjjkm=aa.acctcode_jj and zf.nd=substr(riqi, 0, 4)) is null then '-1' else 
                                  (select zf1.bm from v_sx_bmys_bgt_t_dzfbmjjkmdyb zf 
                                  left join (select * from czfx_dm_dygx zz where zz.dyly=1 and zz.dyxzqh='0' and zz.dynf='0' and zz.bmb='CZFX_DM_ZFJJKM') zf1 on zf.d_zfsyjjkm=zf1.bm
                                  where zf.d_bmjjkm=aa.acctcode_jj and zf.nd=substr(riqi, 0, 4)) end from dual)
           --------------------------------------
         else
          '-1'
       end zfjjkm,
       --------------------------------------
      -- '' zfjjkmbm,
      -- '' zfjjkmmc,
       ------------部门经济科目-----------------
       case
         when (select a.bmys
                 from czfx_dm_bmbqd a
                where a.bmb = 'CZFX_DM_BMJJKM') = 1 then
          (select case
                    when t4.bm is null then
                     '-1'
                    else
                     t4.bm
                  end
             from v_sx_bmys_efm_t_acctitem t
             left join CZFX_DM_BMJJKM t4
               on t.acctcode = t4.bm
            where t.acctid = aa.acctcode_jj and t.nd=substr(riqi, 0, 4))
         when (select a2.bmys
                 from czfx_dm_bmbqd a2
                where a2.bmb = 'CZFX_DM_BMJJKM') = 2 then
          (select case
                    when t4.bm is null then
                     '-1'
                    else
                     t4.bm
                  end
             from v_sx_bmys_efm_t_acctitem t
             left join (select *
                         from czfx_dm_dygx a
                        where a.bmb = 'CZFX_DM_BMJJKM'
                          and a.dyly = 1
                          and a.dyxzqh = 0
                          and a.dynf = 0) t4
               on t.acctcode = t4.dybm
            where t.acctid = aa.acctcode_jj and t.nd=substr(riqi, 0, 4))
         else
          '-1'
       end bmjjkmbm,
      -- aa.acctcode_jj,
       -------------------------------------------
       /*'' bmjjkmmc, (select a.acctname
                                      from EFM_TRA_ZJSX_substr(riqi, 0, 4).efm_t_acctitem a
                                     where a.acctid = aa.acctcode_jj) bmjjkmmc,*/
       --aa.acctcode_jj,
       ----项目类别----------------
       case
         when (select a.bmys
                 from czfx_dm_bmbqd a
                where a.bmb = 'CZFX_DM_XMLB') = 1 then
          (select case
                    when a1.bm is null then
                     '-1'
                    else
                     a1.bm
                  end
             from CZFX_DM_XMLB a1
            where a1.bm = aa.xmlbbm)
         when (select a2.bmys
                 from czfx_dm_bmbqd a2
                where a2.bmb = 'CZFX_DM_XMLB') = 2 then
          (select case
                    when t1.bm is null then
                     '-1'
                    else
                     t1.bm
                  end
             from czfx_dm_dygx t1
            where t1.bmb = 'CZFX_DM_YSDW'
              and t1.dynf = substr(riqi, 0, 4)
              and t1.dyxzqh = '3306010101'
              and t1.dyly = 0
              and t1.dybm = aa.xmlbbm)
         else
          '-1'
       end xmlbbm,
       -------------------------------
       (select pp.projtypename
          from v_sx_bmys_exp_t_projecttype pp
         where pp.lvlid = aa.xmlbbm and pp.nd=substr(riqi, 0, 4)) xmlbmc,
       aa.xmid,
       aa.xmbm,
       aa.xmmc,
       aa.sfdfpxm,
       aa.sfcg,
       -------采购目录--------------
       case
         when (select a.bmys
                 from czfx_dm_bmbqd a
                where a.bmb = 'CZFX_DM_CGML') = 1 then
          (select case
                    when t.bm is null then
                     '-1'
                    else
                     t.bm
                  end
             from v_sx_bmys_ref_t_dys_zfcgml z
             left join CZFX_DM_CGML t
               on z.refcode = t.bm
            where t.bm = aa.cgml and z.nd=substr(riqi, 0, 4))
         when (select a.bmys
                 from czfx_dm_bmbqd a
                where a.bmb = 'CZFX_DM_CGML') = 2 then
          (select case
                    when t1.bm is null then
                     '-1'
                    else
                     t1.bm
                  end
             from v_sx_bmys_ref_t_dys_zfcgml z
             left join (select *
                         from CZFX_DM_dygx t
                        where t.dyly = 1
                          and t.dyxzqh = '0'
                          and t.dynf = 0) t1
               on z.refcode = t1.dybm
            where z.refcode = aa.cgml
            and z.nd=substr(riqi, 0, 4)
            )
         else
          '-1'
       end cgml,
       -----------------------------
       -- aa.cgml,
       aa.cglx,
       aa.sfzfgmfw,
       --------政府购买服务----------------------------
       case
         when (select a.bmys
                 from czfx_dm_bmbqd a
                where a.bmb = 'CZFX_DM_ZFGMFWML') = 1 then
          (select case
                    when t.bm is null then
                     '-1'
                    else
                     t.bm
                  end
             from v_sx_bmys_ref_t_dys_zfgmfwml z
             left join CZFX_DM_ZFGMFWML t
               on z.refcode = t.bm
            where t.bm = aa.zfgmfwbm
            and z.nd=substr(riqi, 0, 4)
            )
         when (select a.bmys
                 from czfx_dm_bmbqd a
                where a.bmb = 'CZFX_DM_ZFGMFWML') = 2 then
          (select case
                    when t1.bm is null then
                     '-1'
                    else
                     t1.bm
                  end
             from v_sx_bmys_ref_t_dys_zfgmfwml z
             left join (select *
                         from CZFX_DM_dygx t
                        where t.dyly = 1
                          and t.dyxzqh = '0'
                          and t.dynf = 0) t1
               on z.refcode = t1.dybm
            where z.refcode = aa.zfgmfwbm
            and z.nd=substr(riqi, 0, 4)
            )
         else
          '-1'
       end zfgmfwbm,
       -----------------------------------------
       --aa.zfgmfwbm,
       aa.zfgmfwmc,
       -------资金来源-------------------------------
       case
         when (select a.bmys
                 from czfx_dm_bmbqd a
                where a.bmb = 'CZFX_DM_ZJLY_BMYS') = 1 then
         
          (select case
                    when (select case
                                   when t.bm is null then
                                    '-1'
                                   else
                                    t.bm
                                 end
                            from CZFX_DM_ZJLY_BMYS t
                           WHERE T.BM = lower(aa.zjlybm)) is null then
                     '-1'
                    else
                     (select case
                               when t.bm is null then
                                '-1'
                               else
                                t.bm
                             end
                        from CZFX_DM_ZJLY_BMYS t
                       WHERE T.BM = lower(aa.zjlybm))
                  end
             from dual)
       
         when (select a.bmys
                 from czfx_dm_bmbqd a
                where a.bmb = 'CZFX_DM_ZJLY_BMYS') = 2 then
         
          (select case
                    when (select case
                                   when t.bm is null then
                                    '-1'
                                   else
                                    t.bm
                                 end
                            from CZFX_DM_dygx t
                           where t.dyly = 1
                             AND T.BMB = 'CZFX_DM_ZJLY_BMYS'
                             and t.dyxzqh = '0'
                             and t.dynf = 0
                             AND t.dybm = lower(aa.zjlybm)) is null then
                     '-1'
                    else
                     (select case
                               when t.bm is null then
                                '-1'
                               else
                                t.bm
                             end
                        from CZFX_DM_dygx t
                       where t.dyly = 1
                         AND T.BMB = 'CZFX_DM_ZJLY_BMYS'
                         and t.dyxzqh = '0'
                         and t.dynf = 0
                         AND t.dybm = lower(aa.zjlybm))
                  end
             from dual)
       end zjlybm,
       --------------------------------------
       --lower(aa.zjlybm) zjlybm,
       aa.money,
       case
         when aa.money < 0 then
          '该项目的采购金额大于预算支出明细的金额，异常'
         else
          ''
       end bz,
       sysdate
  from (select '3306010101' xzqh,
               case
                 when x.year is null then
                  y.year
                 else
                  x.year
               end year,
               case
                 when x.startdate is null then
                  y.startdate
                 else
                  x.startdate
               end startdate,
               case
                 when x.enddate is null then
                  y.enddate
                 else
                  x.enddate
               end enddate,
               case
                 when x.divid is null then
                  y.divid
                 else
                  x.divid
               end divid,
               case
                 when x.acctcode is null then
                  y.acctcode
                 else
                  x.acctcode
               end acctcode,
               case
                 when x.acctcode_jj is null then
                  y.jjkm6805
                 else
                  x.acctcode_jj
               end acctcode_jj,
               case
                 when x.xmlbbm is null then
                  y.xmlbbm
                 else
                  x.xmlbbm
               end xmlbbm,
               case
                 when x.xmid is null then
                  y.xmid
                 else
                  x.xmid
               end xmid,
               case
                 when x.xmbm is null then
                  y.xmbm
                 else
                  x.xmbm
               end xmbm,
               case
                 when x.xmmc is null then
                  y.xmmc
                 else
                  x.xmmc
               end xmmc,
               case
                 when x.sfdfpxm is null then
                  '0'
                 else
                  x.sfdfpxm
               end sfdfpxm,
               '0' sfcg,
               x.cgml,
               x.cglx,
               x.sfzfgmfw,
               x.zfgmfwbm,
               x.zfgmfwmc,
               case
                 when x.zjlybm is null then
                  y.zjlybm
                 else
                  x.zjlybm
               end zjlybm,
               nvl(x.money, 0) - nvl(y.money, 0) money
          from (select p.currentyear year,
                       p1.startdate,
                       p1.enddate,
                       p.divid,
                       p1.acctcode,
                       p.acctcode_jj,
                       p1.projtypeid xmlbbm,
                       p1.projectid xmid,
                       p1.projectno xmbm,
                       p1.projectname xmmc,
                       p1.sfdfpxm, --是否待分配项目
                       p1.isbuycatalog sfcg,
                       '' cgml,
                       '' cglx,
                       '' sfzfgmfw,
                       '' zfgmfwbm,
                       '' zfgmfwmc,
                       --p.ce002,
                       p.ce003, --事业收入(不含专户资金)
                       p.ce004, --事业单位经营收入
                       p.ce005, --上级补助收入(非财政专户核拨)
                       p.ce006, --附属单位上缴收入(非财政专户核拨)
                       p.ce007, --其他收入
                       p.ce008, --政府性基金预算拨款
                       p.ce009, --用事业基金弥补收支差额
                       -- p.ce010,
                       p.ce011, --专户资金
                       -- p.ce012, --ce012=ce013+ce014+ce015+ce016+ce017
                       p.ce013, --一般公共预算（补助）收入
                       -- p.ce014,
                       p.ce015, --预算内基建投资
                       p.ce016, --纳入预算管理的行政事业性收费收入
                       p.ce017, --省经常性经费补助
                       --p.ce018,
                       --  p.ce019,
                       -- p.ce020,
                       --p.ce021,
                       --p.ce022,
                       --p.ce023,
                       p.ce025, --专项结转
                       p.ce026, --政府性基金预算拨款结转
                       p.ce027 --其他结转
                -- count(*)
                  from v_sx_bmys_exp_t_projstore_out p
                  left join v_sx_bmys_exp_t_project_out p1
                    on p.divid = p1.divid
                    and p.nd=p1.nd
                   and p.projectid = p1.projectid
                  left join v_sx_bmys_exp_t_projecttype p2
                    on p1.projtypeid = p2.projtypeid
                    and p.nd=p2.nd
                  left join v_sx_bmys_efm_t_division d
                    on d.divid = p.divid
                    and p.nd=d.nd
                 where p.divid = p1.divid
                   and d.isuse = 1
                   and p.projectid = p1.projectid
                   and p.acctcode_jj not like '*%' --acctcode_jj 以*开头的表示这个年度的汇总
                   and p.currentyear = substr(riqi, 0, 4) --currentyear为#表示所有年度汇总，
                   and p1.projflag_proj = 6 and p.nd=substr(riqi, 0, 4) ) rr unpivot(money FOR zjlybm IN( --列转行
                                                                            --ce002,
                                                                            ce003,
                                                                            ce004,
                                                                            ce005,
                                                                            ce006,
                                                                            ce007,
                                                                            ce008,
                                                                            ce009,
                                                                            -- ce010,
                                                                            ce011,
                                                                            --ce012, 
                                                                            ce013,
                                                                            --ce014,
                                                                            ce015,
                                                                            ce016,
                                                                            ce017,
                                                                            /* ce018,
                                                                            ce019,
                                                                            ce020,
                                                                            ce021,
                                                                            ce022,
                                                                            ce023,*/
                                                                            ce025,
                                                                            ce026,
                                                                            ce027)) x
          full join (select rrr.year,
                           rrr.startdate,
                           rrr.enddate,
                           rrr.divid,
                           rrr.acctcode,
                           rrr.jjkm6805,
                           rrr.xmlbbm,
                           rrr.xmid,
                           rrr.xmbm,
                           rrr.xmmc,
                           rrr.zjlybm,
                           sum(rrr.money) money
                      from (select *
                              from (select z.currentyear year,
                                           p1.startdate,
                                           p1.enddate,
                                           z.divid,
                                           p1.acctcode,
                                           z.jjkm6805,
                                           p1.projtypeid xmlbbm,
                                           p1.projectid xmid,
                                           p1.projectno xmbm,
                                           p1.projectname xmmc,
                                           p1.SFDFPXM, --------是否待分配项目
                                           p1.isbuycatalog sfcg,
                                           z1.refcode cgml,
                                           case
                                             when z.sfzfjzcg =
                                                  'D5F011451BAA492B9A6A650EBEE2BD64' then
                                              '2'
                                             else
                                              '1'
                                           end cglx,
                                           case
                                             when z.zfgmfwml is null then
                                              '0'
                                             else
                                              '1'
                                           end sfzfgmfw,
                                           z2.refcode zfgmfwbm,
                                           z2.refname zfgmfwmc,
                                           -- z.ysnhbxj,        -------------财政拨款合计
                                           z.jfbkbz           ce013, ------------一般公共预算（补助）收入
                                           z.NRYSGLDXZSYXSFSR ce016, ----------纳入预算管理的行政事业性收费收入
                                           z.YSNJJTZ          ce015, -----------预算内基建投资
                                           z.SJCXJFBZ         ce017, ------------省经常性经费补助
                                           z.ZFXJJYSBK        ce008, ------------政府性基金预算拨款
                                           z.SYDWZHHBDYSWZJSR ce011, --------------专户资金
                                           z.SYSRBHZHHBZJ     ce003, ----------------事业收入（不含专户核拨资金）
                                           z.SYDWJYSR         ce004, ----------------事业单位经营收入
                                           z.SJBZSRFCZZHHB    ce005, ----------------上级补助收入（非财政专户核拨）
                                           z.FSDWSJSRFCZZHHB  ce006, -----------附属单位上缴收入(非财政专户核)
                                           z.QTSR7500         ce007, ------------其他收入
                                           z.YSYJJMBSZCE      ce009, -------用事业基金弥补收支差额
                                           z.D_ZXJZ           ce025, ----------专项结转
                                           z.D_ZFXJJYSBKJZ    ce026, --政府性基金预算拨款结转
                                           z.d_qtjyjz         ce027 --其他结余、结转
                                      from v_sx_bmys_bgt_t_zfcgysb z
                                      left join v_sx_bmys_exp_t_projstore_out p
                                        on z.divid = p.divid
                                       and z.projectid = p.projectid
                                       and z.jjkm6805 = p.acctcode_jj
                                       and z.currentyear = p.currentyear
                                       and z.nd=p.nd
                                      left join v_sx_bmys_exp_t_project_out p1
                                        on z.divid = p1.divid
                                       and z.projectid = p1.projectid
                                       and z.nd=p1.nd
                                      left join v_sx_bmys_ref_t_dys_zfcgml z1
                                        on z1.refid = z.cgml0447
                                        and z.nd=z1.nd
                                      left join v_sx_bmys_ref_t_dys_zfgmfwml z2
                                        on z2.refid = z.zfgmfwml
                                        and z.nd=z2.nd
                                     where z.currentyear = substr(riqi, 0, 4)
                                     and z.nd=substr(riqi, 0, 4)
                                       and (p.currentyear = substr(riqi, 0, 4) or
                                           p.currentyear is null)
                                       and p1.projflag_proj = 6
                                       and (p.acctcode_jj not like '*%' or
                                           p.acctcode_jj is null)) rr unpivot(money FOR zjlybm IN(ce013, ------------一般公共预算（补助）收入
                                                                                                  ce016, ----------纳入预算管理的行政事业性收费收入
                                                                                                  ce015, -----------预算内基建投资
                                                                                                  ce017, ------------省经常性经费补助
                                                                                                  ce008, ------------政府性基金预算拨款
                                                                                                  ce011, --------------专户资金
                                                                                                  ce003, ----------------事业收入（不含专户核拨资金）
                                                                                                  ce004, ----------------事业单位经营收入
                                                                                                  ce005, ----------------上级补助收入（非财政专户核拨）
                                                                                                  ce006, -----------附属单位上缴收入(非财政专户核)
                                                                                                  ce007, ------------其他收入
                                                                                                  ce009, -------用事业基金弥补收支差额
                                                                                                  ce025, ----------专项结转
                                                                                                  ce026, --政府性基金预算拨款结转
                                                                                                  ce027 --其他结余、结转
                                                                                                  ))
                            
                            ) rrr
                     where rrr.money <> 0
                     group by rrr.year,
                              rrr.startdate,
                              rrr.enddate,
                              rrr.divid,
                              rrr.acctcode,
                              rrr.jjkm6805,
                              rrr.xmlbbm,
                              rrr.xmid,
                              rrr.xmbm,
                              rrr.xmmc,
                              rrr.zjlybm) y
            on x.divid = y.divid
           and x.acctcode = y.acctcode
           and x.acctcode_jj = y.jjkm6805
           and x.xmid = y.xmid
           and x.zjlybm = y.zjlybm
        
        ----------------
        ------------------------采购部分
        union all
        select *
          from (select '3306010101' xzqh,
                       z.currentyear year,
                       p1.startdate,
                       p1.enddate,
                       z.divid,
                       p1.acctcode,
                       z.jjkm6805,
                       p1.projtypeid xmlbbm,
                       p1.projectid xmid,
                       p1.projectno xmbm,
                       p1.projectname xmmc,
                       p1.SFDFPXM, --------是否待分配项目
                       p1.isbuycatalog sfcg,
                       z1.refcode cgml,
                       case
                         when z.sfzfjzcg = 'D5F011451BAA492B9A6A650EBEE2BD64' then
                          '2'
                         else
                          '1'
                       end cglx,
                       case
                         when z.zfgmfwml is null then
                          '0'
                         else
                          '1'
                       end sfzfgmfw,
                       z2.refcode zfgmfwbm,
                       z2.refname zfgmfwmc,
                       -- z.ysnhbxj,        -------------财政拨款合计
                       z.jfbkbz           ce013, ------------一般公共预算（补助）收入
                       z.NRYSGLDXZSYXSFSR ce016, ----------纳入预算管理的行政事业性收费收入
                       z.YSNJJTZ          ce015, -----------预算内基建投资
                       z.SJCXJFBZ         ce017, ------------省经常性经费补助
                       z.ZFXJJYSBK        ce008, ------------政府性基金预算拨款
                       z.SYDWZHHBDYSWZJSR ce011, --------------专户资金
                       z.SYSRBHZHHBZJ     ce003, ----------------事业收入（不含专户核拨资金）
                       z.SYDWJYSR         ce004, ----------------事业单位经营收入
                       z.SJBZSRFCZZHHB    ce005, ----------------上级补助收入（非财政专户核拨）
                       z.FSDWSJSRFCZZHHB  ce006, -----------附属单位上缴收入(非财政专户核)
                       z.QTSR7500         ce007, ------------其他收入
                       z.YSYJJMBSZCE      ce009, -------用事业基金弥补收支差额
                       z.D_ZXJZ           ce025, ----------专项结转
                       z.D_ZFXJJYSBKJZ    ce026, --政府性基金预算拨款结转
                       z.d_qtjyjz         ce027 --其他结余、结转
                  from v_sx_bmys_bgt_t_zfcgysb z
                  left join v_sx_bmys_exp_t_projstore_out p
                    on z.divid = p.divid
                   and z.projectid = p.projectid
                   and z.jjkm6805 = p.acctcode_jj
                   and z.currentyear = p.currentyear
                   and z.nd=p.nd
                  left join v_sx_bmys_exp_t_project_out p1
                    on z.divid = p1.divid
                   and z.projectid = p1.projectid
                   and z.nd=p1.nd
                  left join v_sx_bmys_ref_t_dys_zfcgml z1
                    on z1.refid = z.cgml0447
                    and z.nd=z1.nd
                  left join v_sx_bmys_ref_t_dys_zfgmfwml z2
                    on z2.refid = z.zfgmfwml
                    and z.nd=z2.nd
                 where z.currentyear = substr(riqi, 0, 4)
                 and z.nd=substr(riqi, 0, 4)
                   and (p.currentyear = substr(riqi, 0, 4) or p.currentyear is null)
                   and p1.projflag_proj = 6
                   and (p.acctcode_jj not like '*%' or p.acctcode_jj is null)) rr unpivot(money FOR zjlybm IN(ce013, ------------一般公共预算（补助）收入
                                                                                                              ce016, ----------纳入预算管理的行政事业性收费收入
                                                                                                              ce015, -----------预算内基建投资
                                                                                                              ce017, ------------省经常性经费补助
                                                                                                              ce008, ------------政府性基金预算拨款
                                                                                                              ce011, --------------专户资金
                                                                                                              ce003, ----------------事业收入（不含专户核拨资金）
                                                                                                              ce004, ----------------事业单位经营收入
                                                                                                              ce005, ----------------上级补助收入（非财政专户核拨）
                                                                                                              ce006, -----------附属单位上缴收入(非财政专户核)
                                                                                                              ce007, ------------其他收入
                                                                                                              ce009, -------用事业基金弥补收支差额
                                                                                                              ce025, ----------专项结转
                                                                                                              ce026, --政府性基金预算拨款结转
                                                                                                              ce027 --其他结余、结转
                                                                                                              ))
        
        ) aa
 where aa.money <> 0;
    commit;

end;

 procedure GET_CZFX_DM_YSDWFWJGZW(riqi varchar2) is

  begin
    delete from czfx_dm_ysdwfwjgzw where year=substr(riqi, 0, 4) ;
  insert into czfx_dm_ysdwfwjgzw
SELECT '3306010101' xzqh,
       substr(riqi, 0, 4) year,
       -----预算单位-------------------
        case
         when (select a.bmys
                 from czfx_dm_bmbqd a
                where a.bmb = 'CZFX_DM_YSDW') = 1 then
          (select case
                    when a1.dwbm is null then
                     '-1'
                    else
                     a1.dwbm
                  end
             from v_sx_bmys_efm_t_division t1
             left join CZFX_DM_YSDW a1
               on t1.divshowid = a1.dwbm
            where t1.divid = t.divid
            and t1.nd=substr(riqi, 0, 4))
         when (select a2.bmys
                 from czfx_dm_bmbqd a2
                where a2.bmb = 'CZFX_DM_YSDW') = 2 then
          (select case
                    when a3.bm is null then
                     '-1'
                    else
                     a3.bm
                  end
             from v_sx_bmys_efm_t_division t2
             left join (select *
                         from czfx_dm_dygx t1
                        where t1.bmb = 'CZFX_DM_YSDW'
                          and t1.dynf = substr(riqi, 0, 4)
                          and t1.dyxzqh = '3306010101'
                          and t1.dyly = 0) a3
               on t2.divshowid = a3.dybm
            where t2.divid = t.divid
            and t2.nd=substr(riqi, 0, 4))
         else
          '-1'
       end dwbm,
       ---------------------------
       ''dwmc,--(select d.divname from v_sx_bmys_efm_t_division d where t.divid=d.divid) dwmc,
       --DIVID,
       (select d1.refcode from v_sx_bmys_Ref_t_Djc_Fwgzwlx d1 where t.lx2269=d1.refid and d1.nd=substr(riqi, 0, 4)) lxbm,
       (select d1.refname from v_sx_bmys_Ref_t_Djc_Fwgzwlx d1 where t.lx2269=d1.refid and d1.nd=substr(riqi, 0, 4)) lxmc,
       --LX2269,
       FWJGZWZLDZ,
       CZR8302,
       FZRQ3018,
       ZSHM1599,
       FWYZY,
       (select d2.refcode from v_sx_bmys_ref_t_djc_jzjg d2 where t.jzjg1087=d2.refid and d2.nd=substr(riqi, 0, 4)) jzjgbm,
       (select d2.refname from v_sx_bmys_ref_t_djc_jzjg d2 where t.jzjg1087=d2.refid and d2.nd=substr(riqi, 0, 4)) jzjgmc,
       --JZJG1087,
       (select d3.refcode from v_sx_bmys_Ref_t_Djc_Fwjgzwsx d3 where t.fwjgzwsx=d3.refid and d3.nd=substr(riqi, 0, 4)) fwjgzwsxbm,
       (select d3.refname from v_sx_bmys_Ref_t_Djc_Fwjgzwsx d3 where t.fwjgzwsx=d3.refid and d3.nd=substr(riqi, 0, 4)) fwjgzwsxmc, 
       --FWJGZWSX,
       (select d4.refname from v_sx_bmys_ref_t_djc_sf d4 where t.sfpzzykd=d4.refid and d4.nd=substr(riqi, 0, 4)) SFPZZYKD,
       --SFPZZYKD,
       SYMJXJ,
       ZY3646,
       CZ5519,
       CJ2605,
       XZ3032,
       QT9157,
       CZCJNSRY,
       DFDW4533,
       BZ9453
  FROM v_sx_bmys_bas_t_fwjgzwqktjb T where t.nd=substr(riqi, 0, 4);

    commit;
end;

procedure GET_CZFX_DM_YSDWJDC(riqi varchar2) is

  begin
        delete from CZFX_DM_YSDWJDC where year=substr(riqi, 0, 4) ;
    insert into CZFX_DM_YSDWJDC
SELECT '33060101' xzqh,substr(riqi, 0, 4) year,
 -----预算单位-------------------
        case
         when (select a.bmys
                 from czfx_dm_bmbqd a
                where a.bmb = 'CZFX_DM_YSDW') = 1 then
          (select case
                    when a1.dwbm is null then
                     '-1'
                    else
                     a1.dwbm
                  end
             from v_sx_bmys_efm_t_division t1
             left join CZFX_DM_YSDW a1
               on t1.divshowid = a1.dwbm
            where t1.divid = t.divid
            and t1.nd=substr(riqi, 0, 4))
         when (select a2.bmys
                 from czfx_dm_bmbqd a2
                where a2.bmb = 'CZFX_DM_YSDW') = 2 then
          (select case
                    when a3.bm is null then
                     '-1'
                    else
                     a3.bm
                  end
             from v_sx_bmys_efm_t_division t2
             left join (select *
                         from czfx_dm_dygx t1
                        where t1.bmb = 'CZFX_DM_YSDW'
                          and t1.dynf = substr(riqi, 0, 4)
                          and t1.dyxzqh = '3306010101'
                          and t1.dyly = 0) a3
               on t2.divshowid = a3.dybm
            where t2.divid = t.divid
            and t2.nd=substr(riqi, 0, 4))
         else
          '-1'
       end dwbm,
       ---------------------------
       --(select d.divshowid from v_sx_bmys_efm_t_division d where t.divid=d.divid) dwbm,
       '' dwmc,--(select d.divname from v_sx_bmys_efm_t_division d where t.divid=d.divid) dwmc,
       --DIVID,
      /* CCID,
       ORDERID,
       NEEDUPDATE,
       ADDSTATUS,
       DATAFLAG,
       TIMESTP,*/
       CPCH0167,
       FDJH3375,
       CJH4598,
       PPJXH,
       (select d1.refname from v_sx_bmys_ref_t_djc_sf d1 where t.sfbzn=d1.refid and d1.nd=substr(riqi, 0, 4)) SFBZN,
       --SFBZN,
      (select d2.refcode from v_sx_bmys_ref_t_djc_ccytlx d2 where t.yt4702=d2.refid and d2.nd=substr(riqi, 0, 4)) ytbm,
       (select d2.refname from v_sx_bmys_ref_t_djc_ccytlx d2 where t.yt4702=d2.refid and d2.nd=substr(riqi, 0, 4)) ytmc,
       --YT4702,
       (select d3.refcode from v_sx_bmys_ref_t_djc_cllx d3 where t.cllx1622=d3.refid and d3.nd=substr(riqi, 0, 4)) cllxbm,
       (select d3.refname from v_sx_bmys_ref_t_djc_cllx d3 where t.cllx1622=d3.refid and d3.nd=substr(riqi, 0, 4)) cllxmc,
       --CLLX1622,
       EDZRZS,
       PQLS8029,
       GZRQ3391,
       YSYLCS06ND,
       DXSJ4198,
       BFSJ1025,
       HJ5348,
       YSN8212,
       YSW7630,
       ZC2131,
       JZ2444,
       SJKZS2008N,
       BXF6240,
       YHKZ4247,
       WXF8927,
       GLGQF,
       XCJLF,
       QTKZ7100,
 
       (select d4.refname from v_sx_bmys_ref_t_djc_sf d4 where t.sfbdwsy=d4.refid and d4.nd=substr(riqi, 0, 4)) SFBDWSY,
       --SFBDWSY,
       SYDWMC,
       BZ7286
       /*PDIVID,
       FILEROOTID,
       AUDITKEY,
       CREATEUSERID,
       AUDITLEVEL*/
  FROM v_sx_bmys_bas_t_jdccqkb T where t.nd=substr(riqi, 0, 4);
      commit;
end;

procedure GET_CZFX_DM_YSDWKZ(riqi varchar2) is

  begin
        delete from czfx_dm_ysdwkz where year=substr(riqi, 0, 4) ;
insert into czfx_dm_ysdwkz
select 
'3306010101' xzqh,
substr(riqi, 0, 4) year,
 -----预算单位-------------------
        case
         when (select a.bmys
                 from czfx_dm_bmbqd a
                where a.bmb = 'CZFX_DM_YSDW') = 1 then
          (select case
                    when a1.dwbm is null then
                     '-1'
                    else
                     a1.dwbm
                  end
             from v_sx_bmys_efm_t_division t1
             left join CZFX_DM_YSDW a1
               on t1.divshowid = a1.dwbm
            where t1.divid = t.divid and t1.nd=substr(riqi, 0, 4))
         when (select a2.bmys
                 from czfx_dm_bmbqd a2
                where a2.bmb = 'CZFX_DM_YSDW') = 2 then
          (select case
                    when a3.bm is null then
                     '-1'
                    else
                     a3.bm
                  end
             from v_sx_bmys_efm_t_division t2
             left join (select *
                         from czfx_dm_dygx t1
                        where t1.bmb = 'CZFX_DM_YSDW'
                          and t1.dynf = substr(riqi, 0, 4)
                          and t1.dyxzqh = '3306010101'
                          and t1.dyly = 0) a3
               on t2.divshowid = a3.dybm
            where t2.divid = t.divid and t2.nd=substr(riqi, 0, 4))
         else
          '-1'
       end dwbm,
       ---------------------------
--(select d.divshowid from v_sx_bmys_efm_t_division d where t.divid=d.divid) dwbm,
'' dwmc,--(select d.divname from v_sx_bmys_efm_t_division d where t.divid=d.divid) dwmc,
DWMCQC,
DWTYDM,
 -----------单位性质-------
       case
         when (select a.bmys
                 from czfx_dm_bmbqd a
                where a.bmb = 'CZFX_DM_DWXZ') = 1 then
          (select case
                    when t4.bm is null then
                     '-1'
                    else
                     t4.bm
                  end
             from v_sx_bmys_bas_t_ysdwjbxxb tt
             left join v_sx_bmys_ref_t_djc_dwxz t1
               on tt.dwxz2748 = t1.refid and tt.nd=t1.nd
             left join v_sx_bmys_efm_t_division t3
               on tt.divid = t3.divid and tt.nd=t3.nd
             left join CZFX_DM_DWXZ t4
               on t1.refcode = t4.bm
            where tt.divid = t.divid and tt.nd=substr(riqi, 0, 4))
         when (select a2.bmys
                 from czfx_dm_bmbqd a2
                where a2.bmb = 'CZFX_DM_DWXZ') = 2 then
          (select case
                    when t4.bm is null then
                     '-1'
                    else
                     t4.bm
                  end
             from v_sx_bmys_bas_t_ysdwjbxxb tt
             left join v_sx_bmys_ref_t_djc_dwxz t1
               on tt.dwxz2748 = t1.refid and tt.nd=t1.nd
             left join v_sx_bmys_efm_t_division t3
               on tt.divid = t3.divid and tt.nd=t3.nd
             left join (select *
                         from czfx_dm_dygx a
                        where a.bmb = 'CZFX_DM_DWXZ'
                          and a.dyly = 1
                          and a.dyxzqh = 0
                          and a.dynf = 0) t4
               on t1.refcode = t4.dybm
            where tt.divid = t.divid and tt.nd=substr(riqi, 0, 4))
         else
          '-1'
       end dwxz,
--(select d1.refcode from v_sx_bmys_ref_t_djc_dwxz d1 where t.dwxz2748=d1.refid) dwxzbm,
''dwxzmc,--(select d1.refname from v_sx_bmys_ref_t_djc_dwxz d1 where t.dwxz2748=d1.refid) dwxzmc,
--DWXZ2748,
-------单位性质级别-----------
 case
         when (select a.bmys
                 from czfx_dm_bmbqd a
                where a.bmb = 'CZFX_DM_DWXZJB') = 1 then
          (select case
                    when t4.bm is null then
                     '-1'
                    else
                     t4.bm
                  end
             from v_sx_bmys_bas_t_ysdwjbxxb tt
             left join v_sx_bmys_ref_t_djc_dwxzjb t1
               on tt.dwjb4956 = t1.refid and tt.nd=t1.nd
             left join v_sx_bmys_efm_t_division t3
               on tt.divid = t3.divid and tt.nd=t3.nd
             left join CZFX_DM_DWXZJB t4
               on t1.refcode = t4.bm
            where tt.divid = t.divid and tt.nd=substr(riqi, 0, 4))
         when (select a2.bmys
                 from czfx_dm_bmbqd a2
                where a2.bmb = 'CZFX_DM_DWXZJB') = 2 then
          (select case
                    when t4.bm is null then
                     '-1'
                    else
                     t4.bm
                  end
             from v_sx_bmys_bas_t_ysdwjbxxb tt
             left join v_sx_bmys_ref_t_djc_dwxzjb t1
               on tt.dwjb4956 = t1.refid and tt.nd=t1.nd
             left join v_sx_bmys_efm_t_division t3
               on tt.divid = t3.divid and tt.nd=t3.nd
             left join (select *
                         from czfx_dm_dygx a
                        where a.bmb = 'CZFX_DM_DWXZJB'
                          and a.dyly = 1
                          and a.dyxzqh = 0
                          and a.dynf = 0) t4
               on t1.refcode = t4.dybm
            where tt.divid = t.divid and tt.nd=substr(riqi, 0, 4))
         else
          '-1'
       end dwxzjb,
------------------------------
--(SELECT d2.refcode FROM v_sx_bmys_ref_t_djc_dwxzjb d2 where t.dwjb4956=d2.refid) dwjbbm,
(SELECT d2.refname FROM v_sx_bmys_ref_t_djc_dwxzjb d2 where t.dwjb4956=d2.refid and d2.nd=substr(riqi, 0, 4)) dwxzjbmc,
--DWJB4956,
-----------单位类别--------------------------
       case
         when (select a.bmys
                 from czfx_dm_bmbqd a
                where a.bmb = 'CZFX_DM_DWLB') = 1 then
          (select case
                    when t4.bm is null then
                     '-1'
                    else
                     t4.bm
                  end
             from v_sx_bmys_bas_t_ysdwjbxxb tt
             left join v_sx_bmys_ref_t_djc_dwlb t1
               on tt.dwlb2179 = t1.refid and tt.nd=t1.nd
             left join v_sx_bmys_efm_t_division t3
               on tt.divid = t3.divid and tt.nd=t3.nd
             left join CZFX_DM_DWLB t4
               on t1.refcode = t4.bm
            where tt.divid = t.divid and tt.nd=substr(riqi, 0, 4))
         when (select a2.bmys
                 from czfx_dm_bmbqd a2
                where a2.bmb = 'CZFX_DM_DWLB') = 2 then
          (select case
                    when t4.bm is null then
                     '-1'
                    else
                     t4.bm
                  end
             from v_sx_bmys_bas_t_ysdwjbxxb tt
             left join v_sx_bmys_ref_t_djc_dwlb t1
               on tt.dwlb2179 = t1.refid and tt.nd=t1.nd
             left join v_sx_bmys_efm_t_division t3
               on tt.divid = t3.divid and tt.nd=t3.nd
             left join (select *
                         from czfx_dm_dygx a
                        where a.bmb = 'CZFX_DM_DWLB'
                          and a.dyly = 1
                          and a.dyxzqh = 0
                          and a.dynf = 0) t4
               on t1.refcode = t4.dybm
            where tt.divid = t.divid and tt.nd=substr(riqi, 0, 4))
         else
          '-1'
       end dwlb,
       -------------------
--(SELECT d3.refcode FROM v_sx_bmys_ref_t_djc_dwlb d3 where t.dwlb2179=d3.refid) dwlbbm,
'' dwlbmc,--(SELECT d3.refname FROM v_sx_bmys_ref_t_djc_dwlb d3 where t.dwlb2179=d3.refid) dwlbmc,
--DWLB2179,
(SELECT d4.refcode FROM v_sx_bmys_ref_t_djc_zdzyxxlb d4 where t.zdzyxxlb=d4.refid and d4.nd=substr(riqi, 0, 4)) xxlbbm,
(SELECT d4.refname FROM v_sx_bmys_ref_t_djc_zdzyxxlb d4 where t.zdzyxxlb=d4.refid and d4.nd=substr(riqi, 0, 4)) xxlbmc,
--ZDZYXXLB,
CZXZJBZBL,
(SELECT d5.refcode FROM v_sx_bmys_ref_t_djc_bzbldc d5 where t.czbzbldc=d5.refid and d5.nd=substr(riqi, 0, 4)) CZBZBLDCBM,
(SELECT d5.refname FROM v_sx_bmys_ref_t_djc_bzbldc d5 where t.czbzbldc=d5.refid and d5.nd=substr(riqi, 0, 4)) CZBZBLDCMC,
--CZBZBLDC,
(SELECT d6.refcode FROM v_sx_bmys_ref_t_djc_sbjfkj d6 where t.dwxzsbjfkj=d6.refid and d6.nd=substr(riqi, 0, 4)) sbjflxbm,
(SELECT d6.refname FROM v_sx_bmys_ref_t_djc_sbjfkj d6 where t.dwxzsbjfkj=d6.refid and d6.nd=substr(riqi, 0, 4)) sbjflxmc,
--DWXZSBJFKJ,
DWCLSJ,
JGBZPZWH,
ZJHBSJ,
FRDB0231,
FRDBDH,
CWFZR,
CWFZRDH,
YSBZR,
YSBZRDH,
YSBZRSJ,
EMAILDZ,
DWDZ8535,
YZBM4004,
BZRSHJ,
XZBZ2487,
CYZGWYGLSYBZ,
CZBKSYBZ,
CZBZSYBZ,
JFZLSYBZ,
GQBZ6577,
SJLDBZBZ,
BBYXCBS,
CZGYRSHJ,
XZBZCZGY,
CYZGWYGLSYBZCZGY,
CZBKSYDWBZCZGY,
CZBZSYDWBZCZGY,
JFZLSYDWBZCZGY,
GQBZCZGY,
GQBZFQECZGY,
SYZZRSHJ,
ZSJTJJYS,
FSJFTJ,
ZCJ4979,
FCJ7563,
ZKJ4141,
FKJ1956,
KYJQTZW,
JXRY8867,
LTXRSHJ,
LXRS6284,
TXRS2,
LGTYRS,
YSBZRYS,
JJTZRS,
BZWCQPYRYJLSGRS,
CQXYRSLGYYS,
XSDSZNFRS,
YJS1467,
BKS2514,
QZBKSFS,
ZKS3773,
QZZKSFS,
GZS654,
ZDZYXSS,
QZWKS,
QZLKS,
CZS6646,
XXS1840,
TJS8453,
CJXSS,
JTGJDBS,
SYSXJ,
XJC4033,
XQC5Z20ZH,
DZXKC,
TZCL4730,
MTC4495,
HC9348,
C1402,
QTJTGJ,
ZJZJXST,
ZBDHB,
ZYZXT,
ZYZXNZJ,
WLSB2206,
XXJ7958,
FWQ8659,
TSDN0758,
BJBSDN,
FYJ4985,
DYJ3558,
SYYTJHSM,
TYY1513,
CZJ8144,
SXJHSM,
ZXJHSM,
KD7903,
ZYKD9147,
ZYKDGNLMJPFM,
GLDW0627,
DTB4787,
BGYF0212,
ZYBGYF,
JYBGYF,
FSYFJQT,
TSYWYF,
ZZFW7250,
CZFW7961,
XSSSYFMJ,
GDZCYZWY,
QZFWJZWYZWY,
ZCZE6111,
JBGZXJ,
ZWGZ0207,
JBGZ5059,
GWGZ1535,
XJGZ4930,
QTGZ5827,
JBTXJ,
JTBTGFDW,
SHXBTGFDW,
GZXJTGFDW,
TGJT7205,
JXJT1209,
QTJTBT,
JJ1545,
HSBZXJ,
WCBT9219,
QTHSBZ,
JXGZXJ,
JCXJXGZXJ,
SHBT0907,
GWJT0247,
GLBT4340,
JLXJXGZ,
D_LSXBT,
SHBZXJ,
YLBXF,
D_ZYNJ,
YLBXF02,
SYBXF,
SYBXJ,
GSBXJ,
BCYLBXF,
CJRJYBZJ,
QTBXJF,
LXFXJ,
GRLXF,
LXRYYLF,
LXHLF,
LXRYBT,
QTLXF,
TXFXJ,
GRTXF,
TXRYBT,
QTTXF,
TZYF6899,
ZFGJJ,
FT2011,
QT3634,
TXBT2967,
GWJTF,
YXWXNXJ,
NZKHJ,
YBZZZWGZ,
YBZZJBGZ,
YBZZSHXBT,
YBZZGWGZ,
YBZZXJGZ,
YBZZJCXJXGZ,
GBXXWKS,
GBXXLKS,
MBXXWKS,
MBXXLKS,
DWSBRS,
QZZFFZLGW,
D_JSJNXJ,
D_JSJNYL,
D_JSJNEL,
D_JSJNSL,
D_JSJNXJ02,
D_JSJNYL02,
D_JSJNEL02,
D_JSJNSL02,
QZJSJNLGW,
QZTSGZGW,
QZCKFWLGW,
QZPTFZLGW,
QZDWZP,
QZLWPQ,
QZQTFS,
sysdate
from v_sx_bmys_bas_t_ysdwjbxxb t where t.nd=substr(riqi, 0, 4);
      commit;
end;

procedure GET_CZFX_DM_YSDWRY(riqi varchar2) is

  begin
        delete from CZFX_DM_YSDWRY where year=substr(riqi, 0, 4) ;
insert into CZFX_DM_YSDWRY
SELECT '3306010101' xzqh,
substr(riqi, 0, 4) year,
-----预算单位-------------------
        case
         when (select a.bmys
                 from czfx_dm_bmbqd a
                where a.bmb = 'CZFX_DM_YSDW') = 1 then
          (select case
                    when a1.dwbm is null then
                     '-1'
                    else
                     a1.dwbm
                  end
             from v_sx_bmys_efm_t_division t1
             left join CZFX_DM_YSDW a1
               on t1.divshowid = a1.dwbm
            where t1.divid = t.divid and t1.nd=substr(riqi, 0, 4))
         when (select a2.bmys
                 from czfx_dm_bmbqd a2
                where a2.bmb = 'CZFX_DM_YSDW') = 2 then
          (select case
                    when a3.bm is null then
                     '-1'
                    else
                     a3.bm
                  end
             from v_sx_bmys_efm_t_division t2
             left join (select *
                         from czfx_dm_dygx t1
                        where t1.bmb = 'CZFX_DM_YSDW'
                          and t1.dynf = 2016
                          and t1.dyxzqh = '3306010101'
                          and t1.dyly = 0) a3
               on t2.divshowid = a3.dybm
            where t2.divid = t.divid and t2.nd=substr(riqi, 0, 4))
         else
          '-1'
       end dwbm,
       ---------------------------
--(select d.divshowid from v_sx_bmys_efm_t_division d where t.divid=d.divid) dwbm,
'' dwmc,--(select d.divname from v_sx_bmys_efm_t_division d where t.divid=d.divid) dwmc,
--DIVID,
SFZH1383,
XM2566,
(SELECT d1.refname FROM v_sx_bmys_ref_t_djc_xb d1 where t.xb4032=d1.refid and d1.nd=substr(riqi, 0, 4)) XB4032,
--XB4032,
(SELECT d2.refcode FROM v_sx_bmys_ref_t_djc_rylb d2 where t.rylb6344=d2.refid and d2.nd=substr(riqi, 0, 4)) rylbbm,
(SELECT d2.refname FROM v_sx_bmys_ref_t_djc_rylb d2 where t.rylb6344=d2.refid and d2.nd=substr(riqi, 0, 4)) rylbmc,
--RYLB6344,
(SELECT d3.refcode FROM v_sx_bmys_ref_t_djc_zzjzglx d3 where t.zzjzglx=d3.refid and d3.nd=substr(riqi, 0, 4)) zzjzglxbm,
(SELECT d3.refname FROM v_sx_bmys_ref_t_djc_zzjzglx d3 where t.zzjzglx=d3.refid and d3.nd=substr(riqi, 0, 4)) zzjzglxmc,
--ZZJZGLX,
(SELECT d4.refcode FROM v_sx_bmys_ref_t_djc_zzryly d4 where t.zzryly=d4.refid and d4.nd=substr(riqi, 0, 4)) zzrylybm,
(SELECT d4.refname FROM v_sx_bmys_ref_t_djc_zzryly d4 where t.zzryly=d4.refid and d4.nd=substr(riqi, 0, 4)) zzrylymc,
--ZZRYLY,
(SELECT d5.refcode FROM v_sx_bmys_ref_t_djc_rysf d5 where t.rysf7193=d5.refid and d5.nd=substr(riqi, 0, 4)) rysfbm,
(SELECT d5.refname FROM v_sx_bmys_ref_t_djc_rysf d5 where t.rysf7193=d5.refid and d5.nd=substr(riqi, 0, 4)) rysfmc,
--RYSF7193,
(SELECT d6.refcode FROM v_sx_bmys_ref_t_djc_zwzc d6 where t.zwzc2595=d6.refid and d6.nd=substr(riqi, 0, 4)) zwzcbm,
(SELECT d6.refname FROM v_sx_bmys_ref_t_djc_zwzc d6 where t.zwzc2595=d6.refid and d6.nd=substr(riqi, 0, 4)) zwzcmc,
--ZWZC2595,
SFWSSMZ,
CZYSNFDBL,
(SELECT d7.refcode FROM v_sx_bmys_ref_t_djc_xl d7 where t.xl3417=d7.refid and d7.nd=substr(riqi, 0, 4)) xlbm,
(SELECT d7.refname FROM v_sx_bmys_ref_t_djc_xl d7 where t.xl3417=d7.refid and d7.nd=substr(riqi, 0, 4)) xlmc,
--XL3417,
LSCKS,
CSRQ1904,
CJGZSJ,
GL4139,
LTSJ9700,
HJ4481,
XJ4446,
ZWGZ5635,
JBGZ3291,
GWGZ0143,
XJGZ9716,
QTGZ7601,
JBTXJ,
JTBTGXJ,
SHXBT,
GZXJT,
TGJT4370,
JXJT9410,
QTJTBT,
HSBZXJ,
WCBT8145,
QTHSBZ,
JXGZHJ,
JCXJXGZXJ,
SHBT8137,
D_QESYDWDZQGWJT,
GWJT9474,
GLBT1014,
JLXJXGZ,
D_LSXBT,
SHBZXJ,
YLBX3140,
D_ZYNJ,
YLBXF,
SYBXF,
SYBXF02,
GSBXJ,
BCYLBXF,
CJRJYBZJ,
QTBXJF,
LXFXJ,
GRLXF,
LXRYYLF,
LXHLF,
LXRYBT,
QTLXF,
TXFXJ,
GRTXF,
TXRYBT,
QTTXF,
TZYF8323,
ZFGJJ2,
'' FT8158,
QT9144,
TXBT5798,
GWJTF,
BZ4267,
--CREATEUSERID,
--AUDITLEVEL,
--AUDITKEY,
--FILEROOTID,
--PDIVID,
--D_XBBSJL,
--NZKHJ
sysdate
  FROM v_sx_bmys_bas_t_dryjbqkb T where t.nd=substr(riqi, 0, 4);
      commit;
end;

end pkg_bmys;
/

