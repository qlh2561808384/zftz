create procedure P_IMP_YSSR
is
V_ERR VARCHAR2(4000);
BEGIN
  ---------------插入金库数据---------------------------------
  DELETE FROM SRFX_YSSR WHERE ZWRQ_JK=TO_CHAR(SYSDATE-1,'YYYYMMDD');
  COMMIT;

  INSERT INTO SRFX_YSSR
  select finorgcode,finorgcode,finorgcode,
  BUDGETLEVELCODE ysjc_jk,TAXORGCODE jgdm_jk,BUDGETSUBJECTCODE kmdm_jk,BUDGETSUBJECTNAME kmmc_jk,reportdate zwrq_jk,
  DAYAMT rlj_jk,MONTHAMT ylj_jk,YEARAMT nlj_jk,F_ZS_GKZH(finorgcode),substr(reportdate,1,6) ny
  FROM sjck.DPTS_CSKY_BILLHEAD3128 a,sjck.DPTS_CSKY_NRBUDGETBILL3128 b
  WHERE a.msgid=b.msgid and reportdate=TO_CHAR(SYSDATE-1,'YYYYMMDD') and b.remark1='0'
  and TAXORGCODE  not like '0%';
  COMMIT;


EXCEPTION WHEN OTHERS THEN
    V_ERR:=SQLERRM||SQLCODE;
    INSERT INTO SRFX_RRO_LOG
  VALUES('ADMIN',SYSDATE,'P_IMP_YSSR',V_ERR);
  COMMIT;
  ROLLBACK;
END P_IMP_YSSR;
/

