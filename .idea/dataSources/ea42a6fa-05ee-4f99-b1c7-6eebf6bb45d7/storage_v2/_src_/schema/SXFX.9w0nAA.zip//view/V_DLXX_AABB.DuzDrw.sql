create view V_DLXX_AABB as
  select t.yybm,t.ssxzyh,t.xmzt lx,count(*) wq,sum(t.tdmj) zq,sum(t.jsy) nq,'AA' gnmk from v_tdcb_dlxx_xmzt t group by t.yybm,t.ssxzyh,t.xmzt
union all
select t.yybm,t.ssxzyh,t.zqqk lx,count(*) wq,sum(t.tdmj) zq,sum(t.jsy) nq,'BB' gnmk from v_tdcb_dlxx_xmzt t group by t.yybm,t.ssxzyh,t.zqqk
/

