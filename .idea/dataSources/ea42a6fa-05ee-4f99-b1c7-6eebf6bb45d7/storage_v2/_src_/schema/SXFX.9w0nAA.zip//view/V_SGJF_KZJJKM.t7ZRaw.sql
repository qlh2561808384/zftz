create view V_SGJF_KZJJKM as
  SELECT REGEXP_SUBSTR(value, '[^,]+', 1, LEVEL) km
                                  FROM (select t.value from jczl.parameters t where t.appguid = 5
                                                                                and t.name = 'not_overe_conomyguid')
                                  CONNECT BY PRIOR 1 = 1
                                         and LEVEL <= REGEXP_COUNT(value, ',') + 1
                                         AND PRIOR DBMS_RANDOM.VALUE IS NOT NULL
/

