create procedure p_zftz_qzdyh( --群组对用户
    qzid in number, --群组id，YHGL_GG_RYQZ表主键
    ywid in VARCHAR2, --业务id
    ssyybm in VARCHAR2, --所属应用编码
    sxlx in VARCHAR2) as

    qzidtem NUMBER(15);
    ywidtem VARCHAR2(20);
    qztype NUMBER(15); --分组划分类型(1单位，2角色，3指定用户,4按sql查询)
    fzlxsql VARCHAR2(3000);
/*fzlxsql1 VARCHAR2(3000);*/
    ssyybmtem VARCHAR2(15);
    sssxlx VARCHAR2(15);

begin
    qzidtem := qzid;
    ywidtem := ywid;

    select m.FZLX into qztype from yhgl_gg_ryqz m where m.GUID = qzidtem;
    delete from zftz_gg_ryqzyh y where y.ywid = ywidtem and y.ssyybm = ssyybm;
    ssyybmtem := ssyybm;
    sssxlx := sxlx;
    if qztype = 1 then --单位
        insert into zftz_gg_ryqzyh (GUID, QZID, YHID, YWID, SSYYBM, SXLX)
        select SEQ_zftz_gg_ryqzyh.Nextval, qzid, yy.guid, ywid, ssyybmtem, sssxlx
        from yhgl_gg_ryqzfb ryqzfb,
             yhgl_yw_yhyy yy
        where ryqzfb.qzid = qzidtem
          and ryqzfb.qzval = yy.szdwid;

    elsif qztype = 2 then --角色
        insert into zftz_gg_ryqzyh (GUID, QZID, YHID, YWID, SSYYBM, SXLX)
        select SEQ_zftz_gg_ryqzyh.Nextval, qzid, yy.guid, ywid, ssyybmtem, sssxlx
        from yhgl_gg_ryqzfb ryqzfb,
             yhgl_yw_yhyy yy
        where ryqzfb.qzid = qzidtem
          and ',' || yy.gwid || ',' like '%,' || ryqzfb.qzval || ',%';
    elsif qztype = 3 then --按指定人员id查询用户
        insert into zftz_gg_ryqzyh (GUID, QZID, YHID, YWID, SSYYBM, SXLX)
        select SEQ_zftz_gg_ryqzyh.Nextval, qzid, ryqzfb.qzval, ywid, ssyybmtem, sssxlx
        from yhgl_gg_ryqzfb ryqzfb
        where ryqzfb.qzid = qzidtem;
    elsif qztype = 4 then --按sql查询

        select m.fzlxsql into fzlxsql from yhgl_gg_ryqz m where m.GUID = qzidtem;
        fzlxsql := replace(fzlxsql, ':ywid', ywidtem);
        fzlxsql := ('insert into zftz_gg_ryqzyh (GUID,QZID,YHID,YWID,SSYYBM,SXLX) select SEQ_zftz_gg_ryqzyh.Nextval,' ||
                    qzid || ',a.guid,''' || ywid || ''',''' || ssyybmtem || ''',''' || sssxlx || ''' '
            || 'from ( ' || fzlxsql || ')a ');
        insert into TEST values (fzlxsql);

        commit;
        EXECUTE IMMEDIATE fzlxsql;

        /*   EXECUTE IMMEDIATE fzlxsql1;*/
        /*   commit;*/


        -- insert into zftz_gg_ryqzyh (GUID,QZID,YHID,YWID,SSYYBM)
        --   select SEQ_zftz_gg_ryqzyh.Nextval,qzid,a.guid,ywid,ssyybmtem
        -- from () a  ;

    end if;
end p_zftz_qzdyh;
/

