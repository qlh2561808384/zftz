create view V_DP_SG as
  select (
       select ee.name
        from jczl.economysection ee
        where ee.year = to_char(sysdate, 'yyyy')
          and ee.isbn_code = aa.isbn_code) jjkm,
       nvl(aa.money, 0)                    yss,
       nvl(bb.money1, 0)                   zfs,
       nvl(bb.money1 / aa.money * 100, 0) percentage
from (select e.isbn_code, sum(b.money) money
      from zjsb.budgetdetail b,
           zjsb.budget b1,
           (select t.guid, t.isbn_code
            from jczl.economysection t
            where t.year = to_char(sysdate, 'yyyy')
              and t.isbn_code in (SELECT REGEXP_SUBSTR(value, '[^,]+', 1, LEVEL) value
                                  FROM (select t.value from jczl.parameters t where t.appguid = 5
                                                                                and t.name = 'not_overe_conomyguid')
                                  CONNECT BY PRIOR 1 = 1
                                         and LEVEL <= REGEXP_COUNT(value, ',') + 1
                                         AND PRIOR DBMS_RANDOM.VALUE IS NOT NULL)) e,
           jczl.enterprise e1
      where b.economysectionguid = e.guid
        and b.budgetid = b1.budgetid
        and b1.enterpriseguid = e1.guid
        and b.year = to_char(sysdate, 'yyyy')
        and e1.isbn_code like '221%'
      group by e.isbn_code)aa
       left join (select isbn_code, sum(money1) money1
                  from (select e.isbn_code, b.totalmoney money1
                        from zfgl.billsdetail b,
                             (select t.guid, t.isbn_code
                              from jczl.economysection t
                              where t.year = to_char(sysdate, 'yyyy')
                                and t.isbn_code in (SELECT REGEXP_SUBSTR(value, '[^,]+', 1, LEVEL) value
                                                    FROM (select t.value from jczl.parameters t where t.appguid = 5
                                                                                                  and t.name = 'not_overe_conomyguid')
                                                    CONNECT BY PRIOR 1 = 1
                                                           and LEVEL <= REGEXP_COUNT(value, ',') + 1
                                                           AND PRIOR DBMS_RANDOM.VALUE IS NOT NULL)) e,
                             jczl.enterprise e1
                        where b.economyguid = e.guid
                          and b.enterpriseguid = e1.guid
                          and b.status <> 0
                          and b.year = to_char(sysdate, 'yyyy')
                          and e1.isbn_code like '221%'
                        union all
                        select e.isbn_code, b.sanctionmoney money1
                        from zjsb.gplandetail b,
                             (select t.guid, t.isbn_code
                              from jczl.economysection t
                              where t.year = to_char(sysdate, 'yyyy')
                                and t.isbn_code in (SELECT REGEXP_SUBSTR(value, '[^,]+', 1, LEVEL) value
                                                    FROM (select t.value from jczl.parameters t where t.appguid = 5
                                                                                                  and t.name = 'not_overe_conomyguid')
                                                    CONNECT BY PRIOR 1 = 1
                                                           and LEVEL <= REGEXP_COUNT(value, ',') + 1
                                                           AND PRIOR DBMS_RANDOM.VALUE IS NOT NULL)) e,
                             jczl.enterprise e1
                        where b.ecosecguid = e.guid
                          and b.enterpriseguid = e1.guid
                          and b.lsname <> -1
                          and exists(select *
                                     from zjsb.budget b1
                                     where b1.year = to_char(sysdate, 'yyyy')and b1.signed = 1
                                       and b.budgetid = b1.budgetid)
                          and b.year = to_char(sysdate, 'yyyy')
                          and e1.isbn_code like '221%')
                  group by isbn_code) bb on aa.isbn_code = bb.isbn_code
order by aa.isbn_code
/

