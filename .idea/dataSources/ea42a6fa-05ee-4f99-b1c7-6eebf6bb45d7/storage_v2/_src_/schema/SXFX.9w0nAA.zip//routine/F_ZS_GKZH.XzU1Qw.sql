create function F_ZS_GKZH
(V_IN_SKGKDM VARCHAR2
) 
return varchar2 is 
FunctionResult varchar2(11);
begin
  SELECT (SELECT GK_DM from SRFX_DM_SKGKDYGK WHERE SKGK_DM=V_IN_SKGKDM)
    INTO FunctionResult
    FROM DUAL;
  return(FunctionResult);
end F_ZS_GKZH;
/

