create procedure P_SJCJ_CJRWSGXF(rw_id in VARCHAR2, --任务ID
                                            sfcg  out VARCHAR2) is
  /*   0 下发失败，请联系系统管理员
  1 下发成功
  2 无周期任务，无需下发
  3 下发失败，请先配置当前采集批次
  4 下发失败，请先配置采集对象
  */

  ---------------------------------------------------
  --  v_num    number(38);
  v_num     number(38);
  num_sjcj  number(38);
  num_sjcj2 number(38);
  t_dqcjpc  varchar2(100);
  --  t_id       varchar2(10);
  t_lcid    number(10);
  t_cjzqid  varchar2(10);
  t_xqrq    VARCHAR2(20);
  xd_xqrq   VARCHAR2(20);
  xd_pxh    NUMBER(10);
  xd_tbzt   VARCHAR2(15);
  xd_jgsj   VARCHAR2(50);
  sz_jgsj   number(10);
  xd_sl     number(10);
  xd_pcyear VARCHAR2(10);
  --xd_id       number(10);
  xd_ksrq    VARCHAR2(20);
  xd_jerq    VARCHAR2(20);
  xd_sjrid   VARCHAR2(20);
  xd_sjr     VARCHAR2(20);
  xd_zt      VARCHAR2(20);
  zb_id      NUMBER(10);
  xd_jgid    NUMBER(38);
  xd_jzrq    VARCHAR2(20);
  xd_cjdxzid NUMBER(10);
  xd_guid    NUMBER(38);
  xd_mc      VARCHAR2(300);
  dxz_jgid   NUMBER(38);
begin
  --判断是否无周期
  select count(*)
    into sfcg
    from sjcj_dm_cjrwk t1, sjcj_dm_cjzq t2
   where t1.cjzqid = t2.id
     and t2.bm = '999'
     and t1.id = rw_id;
  if sfcg = 1 then
    sfcg := 2;
  else
    if sfcg = 0 then
      --判断当前采集批次是否为空
      select count(*)
        into sfcg
        from sjcj_dm_cjrwk t
       where t.id = rw_id
         and t.dqcjpc is null;
      if sfcg = 1 then
        sfcg := 3;
      else
        if sfcg = 0 then
          --是否存在采集对象
          select count(*)
            into sfcg
            from sjcj_cjdxpz t
           where t.cjrwid = rw_id;
          if sfcg = 0 then
             sfcg := 4;
             else
          if sfcg > 0 then
            sfcg := 1;
            select dqcjpc, lcid, cjzqid, xqrq
              into t_dqcjpc, t_lcid, t_cjzqid, t_xqrq
              from SJCJ_DM_CJRWK t
             where t.zt = '1'
               and t.id = rw_id
               and not exists (select *
                      from sjcj_dm_cjzq
                     where bm = '999'
                       and id = t.cjzqid)
               and t.dqcjpc is not null
               and t.ksrq is not null
               and t.xqrq is not null;
            select pxh, year
              into xd_pxh, xd_pcyear
              from SJCJ_DM_CJP
             where id = t_dqcjpc;
            select tbzt
              into xd_tbzt
              from SJCJ_HJB
             where sslcid = t_lcid
               and rownum = 1
             order by guid;
            select jgsj, to_number(substr(jgsj, 1, length(jgsj) - 1))
              into xd_jgsj, sz_jgsj
              from sjcj_dm_cjzq
             where id = t_cjzqid;
          
            --通过间隔时间计算下个批次开始时间
            if substr(xd_jgsj, length(xd_jgsj), 1) = '月' --jgsj最后一个字符是月
             then
              xd_xqrq := to_char(add_months(to_date(t_xqrq, 'yyyy-mm-dd'),
                                            sz_jgsj),
                                 'yyyy-mm-dd'); --xqrq+那么的月
            elsif substr(xd_jgsj, length(xd_jgsj), 1) = '天' --jgsj最后一个字符是天
             then
              xd_xqrq := to_char(to_date(t_xqrq, 'yyyy-mm-dd') + sz_jgsj,
                                 'yyyy-mm-dd');
            end if;
          
            --计算批次号
            select count(*)
              into xd_sl
              from sjcj_rw_zb t
             where t.cjrwid = rw_id
               and t.cjpcid = t_dqcjpc;
            if xd_sl = 0 then
              t_dqcjpc := t_dqcjpc;
            else
              select aa.id
                into t_dqcjpc
                from (select *
                        from SJCJ_DM_CJP t
                       where ((t.pxh > xd_pxh and t.year = xd_pcyear) or
                             t.year > xd_pcyear)
                         and zqid = t_cjzqid
                       order by t.year, t.pxh) aa
               where rownum = 1;
            end if;
          
            --更新采集任务库
            update sjcj_dm_cjrwk
               set dqcjpc = t_dqcjpc, ksrq = t_xqrq, xqrq = xd_xqrq
             where id = rw_id;
            select ksrq,
                   to_char(to_date(ksrq, 'yyyy-mm-dd') + cxts, 'yyyy-mm-dd'),
                   sjrid,
                   sjr,
                   zt
              into xd_ksrq, xd_jerq, xd_sjrid, xd_sjr, xd_zt
              from SJCJ_DM_CJRWK
             where id = rw_id;
            --插入采集任务主表
            insert into SJCJ_RW_ZB
              (id, cjrwid, cjpcid, xfsj, ksrq, jzrq, xfrid, xfr, sfbf, zt)
            values
              (SEQ_SJCJ_RW_ZB.nextval,
               rw_id,
               t_dqcjpc,
               to_char(sysdate, 'yyyy-mm-dd'),
               xd_ksrq,
               xd_jerq,
               xd_sjrid,
               xd_sjr,
               '0',
               xd_zt);
          
            --获得新批次任务信息
            select id, ksrq, jzrq
              into zb_id, xd_ksrq, xd_jzrq
              from SJCJ_RW_ZB
             where cjrwid = rw_id
               and cjpcid = t_dqcjpc;
            --查询任务对单位关系进行下发
            select count(*)
              into num_sjcj
              from sjcj_cjdxpz
             where cjrwid = rw_id
               and cjdxzid = '-1';
          
            if num_sjcj = 1 then
              select jgid
                into xd_jgid
                from sjcj_cjdxpz
               where cjrwid = rw_id
                 and cjdxzid = '-1';
              if xd_jgid = 0 then
                EXECUTE IMMEDIATE 'truncate table temp_cjrwplxf';
                insert into temp_cjrwplxf
                  (zf1, bz)
                  select guid, '1'
                    from yhgl_dm_dw
                   where sfdj = '1'
                     and yybm = 'SJCJ';
              
                select count(*) into v_num from temp_cjrwplxf;
                while v_num > 0 loop
                  select zf1
                    into xd_guid
                    from temp_cjrwplxf
                   where bz = '1'
                     and rownum <= 1; --group by sfdj,yybm
                  update temp_cjrwplxf
                     set bz = '0'
                   where bz = '1'
                     and rownum <= 1;
                  select mc
                    into xd_mc
                    from YHGL_DM_DW
                   where yybm = 'SJCJ'
                     and guid = xd_guid;
                  select count(*)
                    into num_sjcj2
                    from SJCJ_RW_MX
                   where cjpcid = zb_id
                     and jgid = xd_guid;
                  if num_sjcj2 = 0 then
                    insert into SJCJ_RW_MX
                      (id, cjpcid, jgid, jgmc, ksrq, jzrq, sfbf, zt)
                    values
                      (SEQ_SJCJ_RW_MX.nextval,
                       zb_id,
                       xd_guid,
                       xd_mc,
                       xd_ksrq,
                       xd_jzrq,
                       '0',
                       xd_tbzt);
                  
                  end if;
                  v_num := v_num - 1;
                end loop;
                EXECUTE IMMEDIATE 'truncate table temp_cjrwplxf';
              else
                xd_guid := xd_jgid;
                select mc
                  into xd_mc
                  from YHGL_DM_DW
                 where yybm = 'SJCJ'
                   and guid = xd_guid;
                select count(*)
                  into num_sjcj2
                  from SJCJ_RW_MX
                 where cjpcid = zb_id
                   and jgid = xd_guid;
                if num_sjcj2 = 0 then
                  insert into SJCJ_RW_MX
                    (id, cjpcid, jgid, jgmc, ksrq, jzrq, sfbf, zt)
                  values
                    (SEQ_SJCJ_RW_MX.nextval,
                     zb_id,
                     xd_guid,
                     xd_mc,
                     xd_ksrq,
                     xd_jzrq,
                     '0',
                     xd_tbzt);
                end if;
              end if;
            
            elsif num_sjcj > 1 then
              insert into temp_cjrwplxf
                select jgid, '1'
                  from sjcj_cjdxpz
                 where cjrwid = rw_id
                   and cjdxzid = '-1';
              select count(*) into v_num from temp_cjrwplxf where bz = '1';
              while v_num > 0 loop
                select zf1
                  into xd_guid
                  from temp_cjrwplxf
                 where bz = '1'
                   and rownum <= 1;
                update temp_cjrwplxf
                   set bz = '0'
                 where bz = '1'
                   and rownum <= 1;
                select mc
                  into xd_mc
                  from YHGL_DM_DW
                 where yybm = 'SJCJ'
                   and guid = xd_guid;
                select count(*)
                  into num_sjcj2
                  from SJCJ_RW_MX m
                 where cjpcid = zb_id
                   and jgid = xd_guid;
                if num_sjcj2 = 0 then
                  insert into SJCJ_RW_MX
                    (id, cjpcid, jgid, jgmc, ksrq, jzrq, sfbf, zt)
                  values
                    (SEQ_SJCJ_RW_MX.nextval,
                     zb_id,
                     xd_guid,
                     xd_mc,
                     xd_ksrq,
                     xd_jzrq,
                     '0',
                     xd_tbzt);
                end if;
                v_num := v_num - 1;
              end loop;
              EXECUTE IMMEDIATE 'truncate table temp_cjrwplxf';
            end if;
          
            --查询任务对单位组关系进行下发
            select count(*)
              into v_num
              from sjcj_cjdxpz
             where cjrwid = rw_id
               and jgid = '-1';
            if v_num > 0 then
              select cjdxzid
                into xd_cjdxzid
                from sjcj_cjdxpz
               where cjrwid = rw_id
                 and jgid = '-1';
              select count(*)
                into num_sjcj
                from sjcj_dm_cjdxzmx
               where cjdxzid = xd_cjdxzid;
              if num_sjcj = 1 then
              
                select jgid
                  into dxz_jgid
                  from sjcj_dm_cjdxzmx
                 where cjdxzid = xd_cjdxzid;
                if dxz_jgid = 0 then
                  EXECUTE IMMEDIATE 'truncate table temp_cjrwplxf';
                  insert into temp_cjrwplxf
                    (zf1, bz)
                    select guid, '1'
                      from yhgl_dm_dw
                     where sfdj = '1'
                       and yybm = 'SJCJ';
                
                  select count(*) into v_num from temp_cjrwplxf;
                  while v_num > 0 loop
                    select zf1
                      into dxz_jgid
                      from temp_cjrwplxf
                     where bz = '1'
                       and rownum <= 1; --group by sfdj,yybm
                    update temp_cjrwplxf
                       set bz = '0'
                     where bz = '1'
                       and rownum <= 1;
                    xd_guid := dxz_jgid;
                    select mc
                      into xd_mc
                      from YHGL_DM_DW
                     where yybm = 'SJCJ'
                       and guid = xd_guid;
                    select count(*)
                      into num_sjcj2
                      from SJCJ_RW_MX
                     where cjpcid = zb_id
                       and jgid = xd_guid;
                    if num_sjcj2 = 0 then
                      insert into SJCJ_RW_MX
                        (id, cjpcid, jgid, jgmc, ksrq, jzrq, sfbf, zt)
                      values
                        (SEQ_SJCJ_RW_MX.nextval,
                         zb_id,
                         xd_guid,
                         xd_mc,
                         xd_ksrq,
                         xd_jzrq,
                         '0',
                         xd_tbzt);
                    end if;
                    v_num := v_num - 1;
                  end loop;
                  EXECUTE IMMEDIATE 'truncate table temp_cjrwplxf';
                else
                  xd_guid := dxz_jgid;
                  select mc
                    into xd_mc
                    from YHGL_DM_DW
                   where yybm = 'SJCJ'
                     and guid = xd_guid;
                  select count(*)
                    into num_sjcj2
                    from SJCJ_RW_MX
                   where cjpcid = zb_id
                     and jgid = xd_guid;
                  if num_sjcj2 = 0 then
                    insert into SJCJ_RW_MX
                      (id, cjpcid, jgid, jgmc, ksrq, jzrq, sfbf, zt)
                    values
                      (SEQ_SJCJ_RW_MX.nextval,
                       zb_id,
                       xd_guid,
                       xd_mc,
                       xd_ksrq,
                       xd_jzrq,
                       '0',
                       xd_tbzt);
                  end if;
                end if;
              
              elsif num_sjcj > 1 then
                insert into temp_cjrwplxf
                  (zf1, bz)
                  select jgid, '1'
                    from sjcj_dm_cjdxzmx
                   where cjdxzid = xd_cjdxzid;
                select count(*) into v_num from temp_cjrwplxf;
                while v_num > 0 loop
                  select zf1
                    into dxz_jgid
                    from temp_cjrwplxf
                   where bz = '1'
                     and rownum <= 1;
                  update temp_cjrwplxf
                     set bz = '0'
                   where bz = '1'
                     and rownum <= 1;
                  xd_guid := dxz_jgid;
                  select mc
                    into xd_mc
                    from YHGL_DM_DW
                   where yybm = 'SJCJ'
                     and guid = xd_guid;
                  select count(*)
                    into num_sjcj2
                    from SJCJ_RW_MX m
                   where cjpcid = zb_id
                     and jgid = xd_guid;
                  if num_sjcj2 = 0 then
                    insert into SJCJ_RW_MX
                      (id, cjpcid, jgid, jgmc, ksrq, jzrq, sfbf, zt)
                    values
                      (SEQ_SJCJ_RW_MX.nextval,
                       zb_id,
                       xd_guid,
                       xd_mc,
                       xd_ksrq,
                       xd_jzrq,
                       '0',
                       xd_tbzt);
                  end if;
                  v_num := v_num - 1;
                end loop;
                EXECUTE IMMEDIATE 'truncate table temp_cjrwplxf';
                select count(*)
                  into sfcg
                  from sjcj_rw_zb t
                 where t.cjrwid = rw_id
                   and t.cjpcid = t_dqcjpc;
              end if;
            end if;
          end if;
        end if;
      end if;
    end if;
  end if;
    end if;

  ------------------------------------------------------
  Dbms_output.put_line(sfcg);
end P_SJCJ_CJRWSGXF;
/

