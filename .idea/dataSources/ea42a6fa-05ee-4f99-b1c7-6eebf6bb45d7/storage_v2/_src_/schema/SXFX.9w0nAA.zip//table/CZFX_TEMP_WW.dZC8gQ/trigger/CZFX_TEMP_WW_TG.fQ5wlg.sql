create trigger CZFX_TEMP_WW_TG
  before insert or update
  on CZFX_TEMP_WW
  for each row
  begin
  select sysdate into:new.w_updatedate from dual;
end;
/

