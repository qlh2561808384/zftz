create package pkg_yhgl_yy1 is

  TYPE TYP_DATA IS RECORD(
	CZLX     VARCHAR2(500), --操作类型
  GUIDS    VARCHAR2(500), --用户GUID
  YHLX     VARCHAR2(500), --用户类型
  ZJHM     VARCHAR2(500), --身份证号
  XM       VARCHAR2(500), --姓名
  BGDH     VARCHAR2(500), --办公电话
  YDHM     VARCHAR2(500), --手机号码
  LXDZ     VARCHAR2(500), --联系地址
  RYLX     VARCHAR2(500), --人员类型
  ZC       VARCHAR2(500), --职称
  ZW       VARCHAR2(500), --职务
  YHSZDW   VARCHAR2(500), --用户所属单位
  DLM      VARCHAR2(500), --登录名
  ZT       VARCHAR2(500), --状态
  RYXZ     VARCHAR2(500), --人员性质
  SSGKCS   VARCHAR2(500), --所属归口科室
  REGICODE VARCHAR2(500), --行政区划
  EMAIL    VARCHAR2(500), --邮箱地址
  -- 变量定义用户对应用
  GUIDSS   VARCHAR2(500), --用户应用GUID
  YHID     VARCHAR2(500), --对用用户guid
  YYID     VARCHAR2(500), --对应应用guid
  GWID     VARCHAR2(500), --岗位guid
  CJYHID   VARCHAR2(500), --创建人id
  ZTS       VARCHAR2(500), --状态
  SZDWID   VARCHAR2(500), --账号所属单位
  YYBM     VARCHAR2(500), --应用编码
  SSGKCSS   VARCHAR2(500), --所属归口科室
  REGICODES VARCHAR2(500), --行政区划
	ERR       VARCHAR2(2000) --错误
	);
  --接收并解析xml文本
  FUNCTION P_PARSE_XML(CLOB_IN CLOB) RETURN TYP_DATA;

  --处理业务
	PROCEDURE GETP_YHGL_YY
		(v_xmls in  VARCHAR2, --输入xml
     v_yhzh out VARCHAR2, --返回的用户账号
     v_yhmm out VARCHAR2  --返回的用户密码
		 );

end pkg_yhgl_yy1;
/

