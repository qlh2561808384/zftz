create view V_DN_MH_ORG as
  select t1."C_ID",t1."C_CREATEBY",t1."C_CREATETIME",t1."C_DELETED",t1."C_UPDATEBY",t1."C_UPDATETIME",t1."C_UUID",t1."C_CASCADE_ID",t1."C_ICON_CLS",t1."C_IS_AUTO_EXPEND",t1."C_IS_LEAF",t1."C_LEVEL",t1."C_ORG_CODE",t1."C_ORGNAME",t1."C_ORGORUNIT",t1."C_ORGTYPE",t1."C_ORGTYPE1",t1."C_ORGTYPE2",t1."C_PARENT_ID",t1."C_SITE",t1."C_SORT_NO",t1."C_STATUS",t."name" org_id_ from V_DN_MH_ORGANIZATION@SJFXPT t,mv_cos_organization_org t1
where t.org_id_=t1.c_id
/

