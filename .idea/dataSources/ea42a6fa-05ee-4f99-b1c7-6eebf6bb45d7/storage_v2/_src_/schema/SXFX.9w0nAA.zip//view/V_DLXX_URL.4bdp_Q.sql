create view V_DLXX_URL as
  select  t."LX",t."XH",t."MC",t."URL",t."DXLX" , 'TDCB' YYBM  from tdcb_dlxxurl t
/

