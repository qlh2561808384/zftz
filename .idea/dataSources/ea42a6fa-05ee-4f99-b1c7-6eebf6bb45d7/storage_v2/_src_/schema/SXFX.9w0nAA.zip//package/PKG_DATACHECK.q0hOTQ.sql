create PACKAGE PKG_DATACHECK AS
TYPE  T_CURSOR IS REF CURSOR;


PROCEDURE  GET_MAINQUERY(
        P_YEAR     IN NUMBER,
        P_ID   IN NUMBER,
        CUR_SELECT OUT  T_CURSOR,
        P_BODY OUT  T_CURSOR
        ) ;  -- 错误描述

PROCEDURE GET_CHECK_DYB_YLJNLJ(
        P_YEAR     IN NUMBER,
        P_ID   IN NUMBER,
        P_BODY        OUT  T_CURSOR    -- 返回的数据集游标
        );    -- 错误描述

END PKG_DATACHECK;
/

