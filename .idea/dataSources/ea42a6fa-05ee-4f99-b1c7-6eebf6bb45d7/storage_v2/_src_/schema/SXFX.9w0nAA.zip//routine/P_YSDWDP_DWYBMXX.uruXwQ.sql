create procedure P_YSDWDP_DWYBMXX(dwbmCursor out sys_refcursor, -- 调用返回结果集
                                             V_ISBIN_CODE in varchar2,
                                             V_ACCOUNTID in varchar2
                                             ) is
ISBIN_CODE varchar2(100);
countZero number(2);
countZero2 number(2);
dwbmType varchar2(20);
begin
  --用于判断当前身份用户是否存在
  select count(1)
  into countZero2
  from mv_cos_org_account  t,
       mv_cos_organization_org t1,
       jczl.enterprise t3
  where t.c_oid = t1.c_id
   and t1.C_ORG_CODE = t3.isbn_code
   and t3.year = to_char(sysdate,'yyyy')
   and  t.c_id = V_ACCOUNTID;--'56155639'
   
   if countZero2 = 0 then
     open dwbmCursor for
      select '编码：空' bm,'名称：空' mc,'法人：空' dwxjsl_or_fr 
      from dual;
    else
      
      --用于判断用户类型（单位 or 部门001）
      select t1.C_ORG_CODE
      into ISBIN_CODE
      from mv_cos_org_account  t,
       mv_cos_organization_org t1,
       jczl.enterprise t3
      where t.c_oid = t1.c_id
       and t1.C_ORG_CODE = t3.isbn_code
       and t3.year = to_char(sysdate,'yyyy')
       and  t.c_id = V_ACCOUNTID;--'56155639'
   
      --用于判断单位信息是否存在
      select count(e.isbn_code) 
      into  countZero 
      from jczl.enterprise e where e.year=to_char(sysdate,'yyyy') and e.isbn_code = V_ISBIN_CODE;
  
      if ISBIN_CODE like '%001' then
         select dwlx.lx 
         into dwbmType
         from
         (select case when mc='ISBN_CODE' then '单位' else '部门' end lx,bm 
           from 
            (select e.isbn_code,
                   case when e.isbn_code like '%001' then e1.isbn_code else '' end fjbm
             from jczl.enterprise e,jczl.enterprise e1
             where e.year = to_char(sysdate,'yyyy') and e.enabled = 1 and e.parent_guid=e1.guid
               and exists (select t1.C_ORG_CODE bm, t1.C_ORGNAME mc, t.c_identify, t3.frdbname
              from mv_cos_org_account  t,
                   mv_cos_organization_org t1,
                   jczl.enterprise t3
              where t.c_oid = t1.c_id
               and t1.C_ORG_CODE = t3.isbn_code
               and t3.year = to_char(sysdate,'yyyy')
               and  t.c_id= V_ACCOUNTID 
               and t1.C_ORG_CODE = e.isbn_code)
            ) rr unpivot(bm FOR mc IN (isbn_code,fjbm))
            where bm = V_ISBIN_CODE
           ) dwlx;
           
        if dwbmType = '单位' then 
          open dwbmCursor for
          select e.isbn_code bm,e.name mc,'法人：'||e.frdbname dwxjsl_or_fr 
          from jczl.enterprise e where e.year=to_char(sysdate,'yyyy') and e.isbn_code = V_ISBIN_CODE;
        else 
          open dwbmCursor for
          --部门信息卡片
          select 
          --ee1.parent_guid 部门编码,
          ee2.isbn_code bm,
          ee2.name mc,
          '下级单位数量：'||ee1.dwtotals dwxjsl_or_fr 
          from
          (
          select e.parent_guid,count(*) dwtotals
          from 
          jczl.enterprise e 
          where e.parent_guid=
          (
          select t.guid from jczl.enterprise t where t.enabled=1 and t.year=to_char(sysdate,'yyyy') and t.isbn_code = V_ISBIN_CODE
          )
          and e.enabled=1 and e.year=to_char(sysdate,'yyyy') 
          group by e.parent_guid
          ) ee1 left join
          (
          select e.guid,e.name,e.isbn_code from jczl.enterprise e 
          where e.guid=
          (
          select t.guid from jczl.enterprise t where t.enabled=1 and t.year=to_char(sysdate,'yyyy') and t.isbn_code = V_ISBIN_CODE
          )
          ) ee2
          on ee1.parent_guid=ee2.guid; 
        end if;
      
      else 
        if countZero = 0  then
        open dwbmCursor for
          select '编码：空' bm,'名称：空' mc,'法人：空' dwxjsl_or_fr 
          from dual;
        else
          open dwbmCursor for
          select e.isbn_code bm,e.name mc,'法人：'||e.frdbname dwxjsl_or_fr 
          from jczl.enterprise e where e.year=to_char(sysdate,'yyyy') and e.isbn_code = V_ISBIN_CODE;
        end if;
      end if;
    end if;
end P_YSDWDP_DWYBMXX;
/

