create materialized view V_ZFTZ_XMYSGL_ZJDW
refresh force on demand
  as
    select id_zftz_xm,year,zjlybm,sum(money) money from--取资金申拨和用款计划两部分
(select t1.id_zftz_xm,
       g.year,
       g.budgetid,
       4 zjlybm,
       g.sanctionmoney money
  from zjsb.gplandetail@jcgc g, zjsb.gplan@jcgc g1, ZFTZ_XMYSDYZBMX t,zftz_xmysgl t1
 where g.lsname <> -1
   and g.year = g1.year
   and g.gplanid = g1.gplanid
   and g1.signed <> 3
   and g.lsname = 2
   and g.budgetid = t.zbid
   and t.id_zftz_xmysgl=t1.id
   union all
select t1.id_zftz_xm ,
       p.year,
       p.budgetid,
       to_number(substr(p.resourcecategoryincode,0,1)),
       p.money
  from zfgl.plan@jcgc p, ZFTZ_XMYSDYZBMX t,zftz_xmysgl t1
 where t.zbid = p.budgetid
   and t.zjlybm = p.resourcecategoryincode and t.id_zftz_xmysgl=t1.id
   union all
   select t1.id_zftz_xm,to_number(substr(t.dzrq,0,4)) year,-99,t1.zjly,t.dzje from ZFTZ_XMZJDW t,zftz_xmysgl t1
where t.id_zftz_xmysgl=t1.id) group by id_zftz_xm,year,zjlybm
/

