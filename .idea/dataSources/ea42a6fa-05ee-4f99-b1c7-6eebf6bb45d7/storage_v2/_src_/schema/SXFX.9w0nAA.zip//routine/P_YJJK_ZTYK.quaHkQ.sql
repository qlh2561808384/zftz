create procedure P_YJJK_ZTYK(yjgzbm in VARCHAR, --预警规则编码
                                        jzfw   in VARCHAR, --加载范围
                                        TSDXLX in VARCHAR, --推送对象类型
                                        TSDXID in NUMBER, --推送对象
                                        result out sys_refcursor) as
  pch NUMBER;
begin
  --1，生成批次
  SELECT seq_yjjk_yw_yjsj_pch.nextval into pch from dual;

  open result for
    select (select YJFLBM from yjjk_dm_yjgz yjgz where yjgz.bm = yjgzbm) YJFLBM,
           yjgzbm YJGZBM,
           p.planid YWBM,
           '异常数据_系统管理员_不存在指标的计划' YWMC,
           '1000' LYFS,
           to_char(sysdate, 'yyyy-mm-dd hh24:mi:ss') YJSJ,
           '系统检测到不存在指标ID的在途用款计划，planid=' || p.planid MS,
           '2' as tsdxlx,
           '3849' as tsdxid,
           '0' ZT,
           pch PCH
      from ykjh.plan p
     where p.year = to_char(sysdate, 'yyyy')
       and not exists
     (select 1 from ykjh.budget b where b.budgetid = p.budgetid);

end P_YJJK_ZTYK;
/

