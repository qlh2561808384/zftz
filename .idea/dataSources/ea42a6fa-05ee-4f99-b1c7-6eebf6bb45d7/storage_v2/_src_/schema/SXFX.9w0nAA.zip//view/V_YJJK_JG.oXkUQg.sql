create view V_YJJK_JG as
  select 'YHGL' yybm,--1代表归口
       to_char(t1.entid)||'_1' id,
       t1.isbn_code,
       t1.entname,
       --t1.deptid,
       case
         when t2.c_parent_id = 56150342 then
          t1.deptid
         else
          to_char(t2.c_parent_id)
       end||'_1' pid,
        '330600' regicode
  from mv_gg_enterdivision t1, mv_cos_organization_org t2
 where t1.entid = t2.c_id
 union all
select 'YHGL',to_char(t.entid)||'_1' id,t.isbn_code,t.entname,t.deptid||'_1' pid,'330600' from mv_gg_enterdivision t where t.entid=0
union all
select 'YHGL', t1.deptid||'_1', to_char(t1.bm), t1.mc, '33060101' pid,'330600' regicode
  from v_jczl_division t1
union all
select 'YHGL', '33060101', 'sxsbj', '绍兴市本级', '0' pid,'330600' regicode
  from dual
union all
select t01.yybm,
       to_char(t01.c_id) guid,
       t02.c_org_code bm,
       t02.c_org_code || t02.c_orgname mc,
       case
         when t02.c_parent_id = 1 then
          '33060101'
         else
          to_char(t02.c_parent_id)
       end pid,
        '330600' regicode
  from xtgl_dm_dwdy t01,
       (select t.*, connect_by_isleaf sfdj
          from mv_cos_organization_org t
         start with t.c_id = 56150342
        connect by prior t.c_id = t.c_parent_id) t02
 where t01.c_id = t02.c_id
   and t01.yybm = 'YHGL'
/

