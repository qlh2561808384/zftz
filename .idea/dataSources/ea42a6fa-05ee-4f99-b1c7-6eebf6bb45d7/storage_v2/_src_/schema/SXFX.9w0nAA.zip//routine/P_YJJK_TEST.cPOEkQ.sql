create procedure P_YJJK_TEST
(
  yjgzbm in VARCHAR,  --预警规则编码
  jzfw   in VARCHAR,  --加载范围
	TSDXLX in VARCHAR,  --推送对象类型
  TSDXID in NUMBER,  --推送对象
  result out sys_refcursor
) as pch NUMBER;
begin

  --1，生成批次
  SELECT seq_yjjk_yw_yjsj_pch.nextval into pch from dual ;

  open result for select (select YJFLBM from yjjk_dm_yjgz yjgz where yjgz.bm= yjgzbm ) YJFLBM,
                           yjgzbm as YJGZBM,  yhyy.guid YWBM, yhyy.guid YWMC, '1000' LYFS,
                           to_char(sysdate,'yyyy-mm-dd hh24:mi:ss') YJSJ, 'id为' || yhyy.guid || '的数据对应的用户为空，是脏数据' MS,
                           TSDXLX as tsdxlx,TSDXID as tsdxid, '0' ZT, pch as PCH
                  from yhgl_yw_yhyy yhyy
                         where not exists
                         (select 1 from yhgl_yw_yh yh where yhyy.yhid = yh.guid);

end;
/

