create function GETBM(N_BMB  VARCHAR2,
                                 N_YBM  VARCHAR2,
                                 N_YEAR NUMBER,
                                 N_DYLY varchar2,
                                 N_DYXZQH varchar2
                                 ) return varchar2 is
  N_BM     varchar(30);
  v_COUNT NUMBER(4);
  N_ISJCGC CHAR(1);
  v_sqlsmt VARCHAR(3000);
begin
   select COUNT(*) INTO v_COUNT from czfx_dm_bmbqd where bmb = N_BMB;
IF (v_COUNT=0) THEN
  return('-1');--表名错误 
  end if;
  select JCGC INTO N_ISJCGC from czfx_dm_bmbqd where bmb = N_BMB;
    IF (N_ISJCGC = 1) then  
     v_sqlsmt := 'select count(*) from ' ||
                  N_BMB || ' where bm=' || N_YBM;
      execute immediate v_sqlsmt
        into v_COUNT;  
    if (v_count=0) then return('-1') ; --在编码表里无法找到对应值
    end if; 
      v_sqlsmt := 'select case when bm is null then ''-1'' else bm end from ' ||
                  N_BMB || ' where bm=' || N_YBM;
      execute immediate v_sqlsmt
        into N_bm;
        if (N_BM is null or N_BM='') then N_BM:='-1' ; end if;
        
       elsif (N_ISJCGC = 2) then  
        v_sqlsmt :=' select count(*)  from czfx_dm_dygx where dyly='''||N_DYLY||''' and BMB='''||N_BMB|| ''' and (dynf=0 or dynf='||N_YEAR||') and (dyxzqh=0 or dyxzqh='''||N_DYXZQH||''') and dybm='''||N_YBM||'''';
        execute immediate v_sqlsmt
        into v_COUNT;  
            if (v_count=0) then return('-1') ; --在对应关系表里无法找到对应值
              end if;
           v_sqlsmt := ' select  case when bm is null then ''-1'' else bm end  from czfx_dm_dygx where dyly='''||N_DYLY||''' and BMB='''||N_BMB|| ''' and (dynf=0 or dynf='||N_YEAR||') and (dyxzqh=0 or dyxzqh='''||N_DYXZQH||''') and dybm='''||N_YBM||'''';
        execute immediate v_sqlsmt    into N_bm;
        if (N_BM is null or N_BM='') then N_BM:='-1' ; end if;
    END IF;
    return(N_BM);
  
end GETBM;
/

