create materialized view VIEW_YTHDBJH
refresh force on demand
  as
    select  *  from  view_ythdbjh1
/

