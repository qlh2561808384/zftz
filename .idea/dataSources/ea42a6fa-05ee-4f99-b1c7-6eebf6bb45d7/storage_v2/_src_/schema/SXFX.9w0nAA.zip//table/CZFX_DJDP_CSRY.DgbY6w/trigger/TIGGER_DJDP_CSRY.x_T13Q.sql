create trigger TIGGER_DJDP_CSRY
  before insert
  on CZFX_DJDP_CSRY
  for each row
  when (NEW.bh IS NULL)
  BEGIN
    SELECT SEQ_DJDP_CSRY.Nextval INTO:NEW.bh FROM DUAL;
END;
/

