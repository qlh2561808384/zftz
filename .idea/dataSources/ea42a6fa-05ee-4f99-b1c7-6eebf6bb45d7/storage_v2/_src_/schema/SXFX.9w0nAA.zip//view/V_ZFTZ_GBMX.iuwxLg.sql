create view V_ZFTZ_GBMX as
  select t.id_zftz_xm,t.id_zftz_htba,t.bgdh,t.bgnr,t.bgqrsj,t.sjzjyszj,t1.htje,t2.jatzje,t2.ztzje from ZFTZ_XMBGDBA t,
(select t.id_zftz_htba,sum(t.bchtje) htje from zftz_htbamx t group by t.id_zftz_htba)t1,
(select id_zftz_xm,sum(jatzje) jatzje,sum(ztzje) ztzje from (
select t.id_zftz_xm,
       nvl(t1.tze_jztz, 0) + nvl(t1.tze_aztz, 0) jatzje,
       nvl(t1.tze_jztz, 0) + nvl(t1.tze_aztz, 0) + nvl(t1.tze_sbtz, 0) +
       nvl(t1.tze_qttz, 0) ztzje
  from zftz_xmgs t, zftz_xmgsmx t1
 where t.id = t1.id_zftz_xmgs
/* union all
 select t.id_zftz_xm,
       case when t1.tzefl in (1,2) then t1.tzje else 0 end jatzje,
       t1.tzje ztzje
  from ZFTZ_XMGS_TZ t, zftz_xmgs_tzmx t1
 where t.id = t1.id_zftz_xmgs_tz*/ ) group by id_zftz_xm) t2
where t.id_zftz_htba=t1.id_zftz_htba and t.id_zftz_xm=t2.id_zftz_xm
/

