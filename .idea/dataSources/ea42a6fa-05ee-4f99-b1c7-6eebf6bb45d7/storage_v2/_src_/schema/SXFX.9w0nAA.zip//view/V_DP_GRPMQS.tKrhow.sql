create view V_DP_GRPMQS as
  select "KHZQ","DXID","DXMC","ZF","PM","BJSL" from (
 select khzq,DXID,DXMC,to_char(ZF,'fm9990.00') ZF,PM,BJSL from
(
SELECT  khzq,DXID,DXMC,ZF,RANK() OVER(ORDER BY  ZF DESC) AS PM
      ,(SELECT VAL FROM LCGL.KH_GG_ZBTJ WHERE ZBDM='1001' AND KHZQ=X.KHZQ AND DXID=X.DXID) BJSL
 FROM
(select khzq,B.DXID,B.DXMC,sum(val)-LEAST(sum(decode(zbdm,'YWL',a.VAL,0)),sum(decode(zbdm,'TQBJL',a.VAL,0))) ZF
  from LCGL.KH_GG_KHJG a,LCGL.KH_GG_KHDX B
  where B.DYLX IN('12','22','32') and khzq=   case when to_number(to_char(sysdate,'dd'))<=10
       then to_number(to_char(add_months(sysdate,-2),'yyyymm'))
       else to_number(to_char(add_months(sysdate,-1),'yyyymm')) end
    AND B.DXID=A.DXID
  group by khzq,B.DXID,B.DXMC
) X
order by  PM ,nvl(bjsl,0)desc
) where rownum<=  10
order by PM  ,nvl(bjsl,0)desc) aa
/

