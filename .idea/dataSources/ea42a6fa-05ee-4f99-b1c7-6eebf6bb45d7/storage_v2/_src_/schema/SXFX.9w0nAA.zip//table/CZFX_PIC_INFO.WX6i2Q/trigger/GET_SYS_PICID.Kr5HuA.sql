create trigger GET_SYS_PICID
  before insert
  on CZFX_PIC_INFO
  for each row
  declare
  NEXT_ID number;
begin
  select SEQ_SYS_PIC.NEXTVAL into NEXT_ID from dual;
  :NEW.pic_id:=NEXT_ID;
end get_sys_picid;
/

