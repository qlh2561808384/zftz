create procedure p_dn_ci_compute(v_App         in VARCHAR2,
                                            v_CI          in VARCHAR2,
                                            v_CF          in VARCHAR,
                                            i_Count_Field OUT number,
                                            v_Err         OUT VARCHAR2,
                                            v_Log         OUT VARCHAR2)
  authid current_user is
 
 v_t1_fields VARCHAR2(200) DEFAULT '';

  v_t1_create VARCHAR2(500) DEFAULT '';

  v_where_result VARCHAR2(500) DEFAULT '';
  v_str_result   VARCHAR2(500) DEFAULT '';

  v_from           VARCHAR2(1024) DEFAULT '';
  i_debug          number(1) DEFAULT 1;
  v_para_name      VARCHAR2(50) DEFAULT '';
  cur_paras        SYS_REFCURSOR;
  t1_create        clob;
  v_id_code        VARCHAR2(50);
  v_default_value  VARCHAR2(100);
  i_count          number(6);
  i_index          number(2);
  v_field_name     VARCHAR2(50) DEFAULT '';
  v_execute_type   number(1) DEFAULT 0;
  v_procedure_type number(1) DEFAULT 0;
  v_sql            VARCHAR2(1024);
  sel_zd_sql       VARCHAR2(300);
  t1_into          clob;
  t2_create        clob;
  v_guid           VARCHAR2(50) DEFAULT '';
  v_where          VARCHAR2(500) DEFAULT '';
  cur_result       SYS_REFCURSOR;
  cur_pro          SYS_REFCURSOR;
  sum_sql          clob;
  pro_sql          varchar2(300);
  param_guid       VARCHAR2(50);
  param_where      VARCHAR2(500);
  table_count      number(1);
  t1_tablename     varchar2(40);
  t2_tablename     varchar2(40);

  v_branch_selected NUMBER(1);
  v_leaf_field      VARCHAR2(50);
  v_ok              integer;
  param_group       varchar2(2000);
  v_group           varchar2(2000);
BEGIN
  v_Log := '';

  v_Err := '';

  IF i_debug = 1 THEN
    v_Log := v_Log || '{"step":"开始事务"}';
  END IF;

  BEGIN
    if v_CF is not null then
      DELETE FROM dn_cc_jsx_zd_jg
       WHERE ZDMC = v_CF
         AND CSZH_GUID IN (SELECT GUID
                             FROM dn_cc_jsx_cs_zh
                            WHERE YYMC = v_App
                              AND JSXMC = v_CI);
    else
      DELETE FROM dn_cc_jsx_zd_jg
       WHERE CSZH_GUID IN (SELECT GUID
                             FROM dn_cc_jsx_cs_zh
                            WHERE YYMC = v_App
                              AND JSXMC = v_CI);
    end if;
    IF i_debug = 1 THEN
      v_Log := v_Log || ',{"step":"清空了现有结果数据"}';
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      v_Err := '严重错误：清空结果数据失败';
      IF v_Err is not null THEN
        Rollback;
        return;
      END IF;
  END;

  BEGIN

    open cur_paras FOR
      SELECT CSMC
        FROM dn_dy_jsx_cs
       WHERE YYMC = v_App
         AND JSXMC = v_CI
       ORDER BY CSSX;

    i_count := 0;
    loop
      fetch cur_paras
        into v_para_name;
      exit when cur_paras%NOTFOUND OR cur_paras%NOTFOUND IS NULL;
      IF v_t1_create is null THEN
        v_t1_create := v_para_name;
        v_t1_fields := v_para_name;
      ELSE
        v_t1_create := v_t1_create || ',' || v_para_name;
        v_t1_fields := v_t1_fields || ',' || v_para_name;
      END IF;
      v_t1_create := CONCAT(v_t1_create, ' VARCHAR2(50)');
      i_count     := i_count + 1;
    end loop;
    close cur_paras;
    IF i_count = 0 THEN
      v_Err := 'Err:dn_dy_jsx_cs表没有检索到数据';
      return;
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      v_Err := '严重错误：无法打开dn_dy_jsx_cs表';
      IF v_Err is not null THEN
        Rollback;
        return;
      END IF;
  END;

  BEGIN
    t1_tablename := 'T1' || ceil(dbms_random.value(1, 10000000)) ||
                    dbms_random.string('$', 3);
    t2_tablename := 'T2' || ceil(dbms_random.value(1, 10000000)) ||
                    dbms_random.string('$', 3);
    t1_create    := 'CREATE global TEMPORARY TABLE ' || t1_tablename || '(' ||
                    v_t1_create || ') on commit delete rows';
    IF i_debug = 1 THEN
      v_Log := v_Log || ',{"step":"创建临时表'|| t1_tablename  || '，有几个全局参数就会有几个字段，sql:' ||
               replace(t1_create, '"', '''') || '"}';
    END IF;
    execute immediate t1_create;
    execute immediate ('CREATE global TEMPORARY TABLE ' || t2_tablename ||
                      ' (for_where VARCHAR2(1024),for_Str VARCHAR2(1024)) on commit delete rows');
  EXCEPTION
    WHEN OTHERS THEN
      v_Err := '严重错误：无法创建临时表' || t1_tablename || '或者' || t2_tablename || ':' ||
               sqlerrm;

      IF v_Err is not null THEN
        v_Err := v_Err || CHR(13) || CHR(10) || 'SQL is:' || CHR(13) ||
                 CHR(10) || t1_create || CHR(13) || CHR(10) ||
                 'CREATE global TEMPORARY TABLE ' || t2_tablename ||
                 ' (for_where VARCHAR2(1024),for_Str VARCHAR2(1024)) on commit delete rows';
        select count(1)
          into table_count
          from user_tables t
         where t.TABLE_NAME = upper(t1_tablename);
        if table_count > 0 then
          EXECUTE IMMEDIATE ('drop table ' || t1_tablename);
        end if;
        select count(1)
          into table_count
          from user_tables t
         where t.TABLE_NAME = upper(t2_tablename);
        if table_count > 0 then
          EXECUTE IMMEDIATE ('drop table ' || t2_tablename);
        end if;
        Rollback;
        return;
      END IF;
  END;

  BEGIN
    open cur_paras FOR
      SELECT dn_dy_qjcs.CSMC,
             dn_dy_qjcs.CSMRZ,
             dn_dy_qjcs.ZDSQL,
             dn_dy_qjcs.BMZD,
             dn_dy_qjcs.SFXZZGJD,
             dn_dy_qjcs.YZJDZD
      FROM
             dn_dy_qjcs
      INNER JOIN 
            dn_dy_jsx_cs
      ON
            dn_dy_qjcs.CSMC = dn_dy_jsx_cs.CSMC AND dn_dy_qjcs.YYMC = dn_dy_jsx_cs.YYMC
      WHERE
            dn_dy_jsx_cs.YYMC = v_App AND dn_dy_jsx_cs.JSXMC = v_Ci
      ORDER BY dn_dy_jsx_cs.CSSX;

    i_count := 0;
    loop
      fetch cur_paras
        INTO v_para_name, v_default_value, v_sql, v_id_code, v_branch_selected, v_leaf_field;
      exit when cur_paras%NOTFOUND OR cur_paras%NOTFOUND IS NULL;
      IF v_sql IS NULL AND v_default_value IS NOT NULL THEN
        v_sql     := 'SELECT ''' || replace(v_default_value, '''', '''''') || ''' res_value' ||
                     ' from dual';
        v_id_code := 'res_value';
      END IF;

      IF v_branch_selected = 0 AND v_leaf_field IS NOT NULL THEN
        v_sql := 'SELECT' || CHR(13) || CHR(10) || v_id_code || CHR(13) ||
                 CHR(10) || 'FROM' || CHR(13) || CHR(10) || '(' || v_sql ||
                 ') inner_' || v_id_code || CHR(13) || CHR(10) || 'WHERE' ||
                 CHR(13) || CHR(10) || v_leaf_field || ' = ''1''';
      END IF;

      IF v_from is null THEN
        v_from := '(SELECT ' || v_id_code || ' FROM(' || CHR(13) || CHR(10) ||
                  v_sql || ') inner_' || v_id_code || CHR(13) || CHR(10) || ') ' ||
                  v_para_name;

        v_where_result := '''' || v_para_name || '='' || '''''''' || ' ||
                          v_para_name || ' || ''''''''';

        v_str_result := '''' || v_para_name || '='' || ' || v_para_name ||
                        ' || ' || ''';''';
      ELSE
        v_from         := v_from || CHR(13) || CHR(10) || ',' || CHR(13) ||
                          CHR(10) || '(SELECT ' || v_id_code || ' FROM(' ||
                          CHR(13) || CHR(10) || v_sql || ') inner_' ||
                          v_para_name || CHR(13) || CHR(10) || ') ' ||
                          v_para_name;
        v_where_result := v_where_result || ' || '' AND '' || ' || '''' ||
                          v_para_name || '='' || '''''''' || ' ||
                          v_para_name || ' || ''''''''';
        v_str_result   := v_str_result || ' || ' || '''' || v_para_name ||
                          '='' || ' || v_para_name || ' || ' || ''';''';
      END IF;
      i_count := i_count + 1;
    end loop;
    close cur_paras;
    IF i_count = 1 THEN
      v_Log := v_Log || ',{"step":"打开交叉查询成功"}';
    END IF;

    IF i_count = 0 THEN
      v_Err := 'Err:交叉查询没有检索到数据';
      select count(1)
        into table_count
        from user_tables t
       where t.TABLE_NAME = upper(t1_tablename);
      if table_count > 0 then
        EXECUTE IMMEDIATE ('drop table ' || t1_tablename);
      end if;
      select count(1)
        into table_count
        from user_tables t
       where t.TABLE_NAME = upper(t2_tablename);
      if table_count > 0 then
        EXECUTE IMMEDIATE ('drop table ' || t2_tablename);
      end if;
      Rollback;
      return;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      v_Err := '严重错误：无法打开交叉查询' || sqlerrm;

      IF v_Err is not null THEN
        Rollback;
        return;
      END IF;
  END;

  BEGIN
    t1_into := 'INSERT INTO ' || t1_tablename || ' (' || v_t1_fields || ')' ||
               CHR(13) || CHR(10) || ' SELECT * FROM ' || CHR(13) ||
               CHR(10) || v_from;

    execute immediate t1_into;
    IF i_debug = 1 THEN
      v_Log := v_Log  || ',{"step":"'|| t1_tablename || '表的作用是进行多个参数组合。插入表成功,sql:' ||replace(t1_into,'"','''') || '"}';
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      v_Err := '严重错误：把交叉查询结果插入到临时表' || t1_tablename || '失败:' || sqlcode ||
               sqlerrm;
      IF v_Err is not null THEN
  select count(1)
  into table_count
  from user_tables t
  where t.TABLE_NAME = upper(t1_tablename);
  if table_count > 0 then
    EXECUTE IMMEDIATE ('drop table ' || t1_tablename);
  end if;
  select count(1)
    into table_count
    from user_tables t
   where t.TABLE_NAME = upper(t2_tablename);
  if table_count > 0 then
    EXECUTE IMMEDIATE ('drop table ' || t2_tablename);
  end if;
        Rollback;
        return;
      END IF;
  END;

  BEGIN
    t2_create := 'INSERT INTO ' || t2_tablename ||
                 ' (for_where,for_str) SELECT' || CHR(13) || CHR(10) ||
                 (v_where_result) || ' for_where,' || CHR(13) || CHR(10) ||
                 (v_str_result) || ' for_str FROM ' || t1_tablename;
    IF i_debug = 1 THEN
      v_Log := v_Log   || ',{"step":"'|| t2_tablename || '表的作用是存储多个参数组合对应的sql where条件和组合串。插入表成功,sql:' ||replace(t2_create,'"','''') || '"}';
    END IF;
    execute immediate t2_create;
  EXCEPTION
    WHEN OTHERS THEN
      v_Err := '严重错误：设置临时表' || t2_tablename || '内容失败:' || sqlcode ||
               sqlerrm;

      IF v_Err is not null THEN
        select count(1)
          into table_count
          from user_tables t
         where t.TABLE_NAME = upper(t1_tablename);
        if table_count > 0 then
          EXECUTE IMMEDIATE ('drop table ' || t1_tablename);
        end if;
        select count(1)
          into table_count
          from user_tables t
         where t.TABLE_NAME = upper(t2_tablename);
        if table_count > 0 then
          EXECUTE IMMEDIATE ('drop table ' || t2_tablename);
        end if;
        Rollback;
        return;
      END IF;
  END;

  BEGIN
    open cur_paras FOR 'SELECT * FROM ' || t2_tablename;
    i_count := 0;
    IF i_debug = 1 THEN
      v_Log := v_Log || ',{"step":"打开' || t2_tablename || '表成功，开始针对'||t2_tablename||'的记录进行轮询，轮询次数代表参数的组合数量（日志仅记录第1个参数组合）..."}';
    END IF;
    loop
      fetch cur_paras
        into v_where_result, v_str_result;
      exit when cur_paras%NOTFOUND OR cur_paras%NOTFOUND IS NULL;

      SELECT COUNT(*)
        INTO i_index
        FROM dn_cc_jsx_cs_zh
       WHERE YYMC = v_App
         AND JSXMC = v_CI
         AND CSZHNR = v_str_result;
      IF i_index = 0 THEN
        INSERT INTO dn_cc_jsx_cs_zh
          (GUID, YYMC, JSXMC, CSZHNR, CSZHTJ)
        VALUES
          (sys_guid(), v_App, v_Ci, v_str_result, v_where_result);
      END IF;
      i_count := i_count + 1;
    end loop;
    close cur_paras;
    execute immediate ('drop table ' || t2_tablename);
    EXECUTE IMMEDIATE ('drop table ' || t1_tablename);
    IF i_count = 0 THEN
      v_Err := 'p_dn_ci_compute Err:open t2 is succeed,but not data!';
      select count(1)
        into table_count
        from user_tables t
       where t.TABLE_NAME = upper(t1_tablename);
      if table_count > 0 then
        EXECUTE IMMEDIATE ('drop table ' || t1_tablename);
      end if;
      select count(1)
        into table_count
        from user_tables t
       where t.TABLE_NAME = upper(t2_tablename);
      if table_count > 0 then
        EXECUTE IMMEDIATE ('drop table ' || t2_tablename);
      end if;
      Rollback;
      return;
    END IF;

    IF i_debug = 1 THEN
      v_Log := v_Log || ',{"step":"' || t2_tablename || '表轮询成功结束，共检查和维护了' ||
               i_count || '个参数组合"}';
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      v_Err := '严重错误：打开临时表' || t2_tablename || '失败' || sqlerrm;

      IF v_Err is not null THEN
        Rollback;
        select count(1)
          into table_count
          from user_tables t
         where t.TABLE_NAME = upper(t1_tablename);
        if table_count > 0 then
          EXECUTE IMMEDIATE ('drop table ' || t1_tablename);
        end if;
        select count(1)
          into table_count
          from user_tables t
         where t.TABLE_NAME = upper(t2_tablename);
        if table_count > 0 then
          EXECUTE IMMEDIATE ('drop table ' || t2_tablename);
        end if;
        return;
      END IF;
  END;

  BEGIN
    sel_zd_sql := 'SELECT ZDMC,ZXLX,JSSQL,LXLX FROM dn_dy_jsx_zd WHERE YYMC =''' ||
                  v_App || ''' AND JSXMC =''' || v_CI || '''';
    if v_CF is not null then
      sel_zd_sql := sel_zd_sql || ' And  ZDMC =''' || v_CF || '''';
    end if;
    open cur_paras for sel_zd_sql;
    i_Count_Field := 0;
    IF i_debug = 1 THEN
      v_Log := v_Log || ',{"step":"开始字段轮询计算..."}';
    END IF;
    loop
      fetch cur_paras
        INTO v_field_name, v_execute_type, v_sql, v_procedure_type;
      exit when cur_paras%NOTFOUND OR cur_paras%NOTFOUND IS NULL;
      IF v_sql IS NULL THEN
        v_Err := '严重错误：找不到' || v_CI || '.' || v_field_name ||
                 '对应的SQL或存储过程定义信息';
        CLOSE cur_paras;
        Rollback;
        return;
      END IF;
      i_Count_Field := i_Count_Field + 1;
      IF v_execute_type = 2 THEN

        IF v_procedure_type = 1 THEN

          BEGIN
            open cur_pro FOR
              SELECT GUID, CSZHTJ, CSZHNR
                FROM dn_cc_jsx_cs_zh
               WHERE YYMC = v_App
                 AND JSXMC = v_CI;

            pro_sql := 'call ' || v_sql || '(' || '''' || v_App || ''',' || '''' || v_CI ||
                       ''',' || '''' || v_field_name || ''',' || '''' ||
                       param_guid || ''',' || '''' || param_where || '''' || ')';

            IF i_debug = 1 THEN
              v_Log := v_Log || ',{"step":"尝试为 [' || v_CI || '.' || v_field_name || '] 进行参数组合轮询并逐个启动存储过程：' || replace(pro_sql,'"','''') || '"}';
            END IF;

            loop
              FETCH cur_pro
                INTO param_guid, param_where, param_group;
              exit when cur_pro%NOTFOUND OR cur_pro%NOTFOUND IS NULL;
              v_ok := DATANEW_FIND_UNUSE_P_COMBINE(param_group, v_App, v_CI);
              if v_ok = 1 then
                pro_sql := 'call ' || v_sql || '(' || '''' || v_App ||
                           ''',' || '''' || v_CI || ''',' || '''' ||
                           v_field_name || ''',' || '''' || param_guid ||
                           ''',' || '''' ||
                           replace(param_where, '''', '''''') || '''' || ')';
                execute immediate pro_sql;
              end if;
            end loop;
            close cur_pro;
          EXCEPTION
            WHEN OTHERS THEN
              v_Err := '严重错误：进行参数组合轮询并逐个启动存储过程失败，Sql:' || CHR(13) ||
                       CHR(10) || pro_sql;

              IF v_Err is not null THEN
                Rollback;
                return;
              END IF;
          END;
        ELSE
          begin

            pro_sql := 'call ' || v_sql || '(' || '''' || v_App || ''',' || '''' || v_CI ||
                       ''',' || '''' || v_field_name || '''' || ')';
            IF i_debug = 1 THEN
              v_Log := v_Log || ',{"step":"' || i_Count_Field || ' 为 [' || v_CI || '.' || v_field_name || '] 启动自身具备参数轮询能力的存储过程：' || replace(pro_sql,'"','''') || '"}';
            END IF;
            execute immediate pro_sql;
          EXCEPTION
            WHEN OTHERS THEN
              v_Err := '严重错误：存储过程自行进行轮询参数组合失败，Sql:' || CHR(13) || CHR(10) ||
                       pro_sql;

              IF v_Err is not null THEN
                Rollback;
                return;
              END IF;
          end;
        END IF;
      ELSE

        BEGIN
          open cur_result FOR
            SELECT GUID, CSZHTJ, CSZHNR
              FROM dn_cc_jsx_cs_zh
             WHERE YYMC = v_App
               AND JSXMC = v_CI;

          loop
            FETCH cur_result
              INTO v_guid, v_where, v_group;
            exit when cur_result%NOTFOUND OR cur_result%NOTFOUND IS NULL;
            v_ok := DATANEW_FIND_UNUSE_P_COMBINE(v_group, v_App, v_CI);
            if v_ok = 1 then
              sum_sql := 'INSERT INTO dn_cc_jsx_zd_jg(GUID,CSZH_GUID,ZDMC,ZDJG) VALUES(' ||
                         CHR(13) || CHR(10) || '''' || sys_guid() || '''' || ',' ||
                         CHR(13) || CHR(10) || '''' || v_guid || ''',' ||
                         CHR(13) || CHR(10) || '''' || v_field_name || '''' || ',' ||
                         CHR(13) || CHR(10) || '(SELECT SUM(' ||
                         v_field_name || ') FROM ' || CHR(13) || CHR(10) || '(' ||
                         CHR(13) || CHR(10) || v_sql || ') sub1 ' ||
                         CHR(13) || CHR(10) || 'WHERE ' || CHR(13) ||
                         CHR(10) || v_where || CHR(13) || CHR(10) || '))';
              execute immediate sum_sql;
            end if;
          end loop;
          close cur_result;
          IF i_debug = 1 THEN
            v_Log := v_Log || ',{"step":"尝试为' || v_CI || '.' || v_field_name || '启动SQL：' || replace(sum_sql,'"','''') || '"}';
          END IF;
        EXCEPTION
          WHEN OTHERS THEN
            v_Err := '严重错误：打开参数组合表或插入结果值失败:' || sqlerrm;

            IF v_Err is not null THEN
              RollBack;
              return;
            END IF;
        END;
      End if;
    end loop;
    close cur_paras;
    IF i_Count_Field = 0 THEN
      v_Err := '严重错误：检索不到计算项的字段';
      ROLLBACK;
      return;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      v_Err := '严重错误：打开字段表失败';

      IF v_Err is not null THEN
        Rollback;
        return;
      END IF;
  END;
  COMMIT;

  IF i_debug = 1 THEN
    v_Log := CONCAT(v_Log, ',{"step":"成功递交事务"}');
  END IF;
EXCEPTION
  WHEN OTHERS THEN
    v_Err := v_Err || '预加工失败';

    IF v_Err is not null THEN
      Rollback;
      return;
    END IF;
END;
/

