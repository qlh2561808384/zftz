create view V_TDCB_XZQH as
  select aa.bm,case when aa.bm='33060101' then '绍兴市本级' else aa.mc end mc,aa.fjbm,aa.yxbz,aa.lev
  from (select t.*, level lev
          from (select * from czfx_dm_xzqh where bm <> -1) t
         start with t.fjbm = 0
        connect by prior t.bm = t.fjbm) aa
 where aa.lev <> 4
/

