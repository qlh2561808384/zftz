create view V_ZFTZ_JC_DWZB as
  select b.year,
       b.budgetid,
       b.id,
       f.isbn_code || ' ' || f.name gnkmmc,--功能科目名称
       r.in_code,
       r.name zjly,--资金来源
       b.money je,
       o.C_ID jsdw, --建设单位id
       e.isbn_code ecode,--单位编码
       e.name ename, --单位名称
       b.signed --是否可申拨
  from zjsb.budget@jcgc             b,
       mv_cos_organization_org o,
       jczl.enterprise@jcgc         e,
       jczl.functionsection@jcgc    f,
       jczl.resourcecategory@jcgc   r
 where b.enterpriseguid = e.guid
   and b.year = e.year
   and e.isbn_code = o.C_ORG_CODE
   and b.year = f.year
   and b.functionguid = f.guid
   and b.resourceguid = r.guid
   and b.year = r.year
   and b.programtypecode = 3
  -- and b.year = 2018
/

