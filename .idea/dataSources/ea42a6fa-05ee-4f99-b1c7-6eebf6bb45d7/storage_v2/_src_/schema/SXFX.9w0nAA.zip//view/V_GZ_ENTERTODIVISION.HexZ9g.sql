create view V_GZ_ENTERTODIVISION as
  select "ISBN_CODE","ENTID","ENTNAME","DIVGUID","DIVNAME","DEPTID" from v_entertodivision
/

