create package p_zfcg_yy is
  type cur is ref cursor;

  procedure GETP_YHGL_YY(xmls in varchar2,yhzh out varchar2,yhmm out varchar2);


end p_zfcg_yy;
/

