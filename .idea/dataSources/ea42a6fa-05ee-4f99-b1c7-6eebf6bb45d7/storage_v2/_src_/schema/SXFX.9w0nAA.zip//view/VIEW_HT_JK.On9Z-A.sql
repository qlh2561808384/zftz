create view VIEW_HT_JK as
  select '33060101' ssxzqh,"CHTBH","CDKBM","CDKMC","CSRDW",round(nvl(iydzmj,0)/666.6666,2) ITDMJ,"CCRFSNAME",'' INUMBER,'' IFKJE,'' DFKDATE,"CCRFS", round(nvl(izje,0)/10000,2) htje, ddate qdrq from land.view_ht_jk@tbview
/

