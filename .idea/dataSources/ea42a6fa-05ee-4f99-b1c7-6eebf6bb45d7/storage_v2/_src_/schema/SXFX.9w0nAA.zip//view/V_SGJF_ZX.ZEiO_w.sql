create view V_SGJF_ZX as
  select dwbm,isbn_code, sum(money1) money1
                  from (select e1.isbn_code dwbm,e.isbn_code, b.totalmoney money1
                        from zfgl.billsdetail b,
                             (select t.guid, t.isbn_code
                              from jczl.economysection t
                              where t.year = to_char(sysdate, 'yyyy') 
                                and t.isbn_code in (select km from V_SGJF_KZJJKM)) e,
                             jczl.enterprise e1
                        where b.economyguid = e.guid
                          and b.enterpriseguid = e1.guid
                          and b.status <> 0
                          and b.year = to_char(sysdate, 'yyyy') 
                          --and e1.isbn_code like '221%'
                        union all
                        select e1.isbn_code dwbm,e.isbn_code, b.sanctionmoney money1
                        from zjsb.gplandetail b,
                             (select t.guid, t.isbn_code
                              from jczl.economysection t
                              where t.year = to_char(sysdate, 'yyyy')
                                and t.isbn_code in (select km from V_SGJF_KZJJKM)) e,
                             jczl.enterprise e1
                        where b.ecosecguid = e.guid
                          and b.enterpriseguid = e1.guid
                          and b.lsname <> -1
                          and exists(select *
                                     from zjsb.budget b1
                                     where b1.year = to_char(sysdate, 'yyyy')  and b1.signed = 1
                                       and b.budgetid = b1.budgetid)
                          and b.year = to_char(sysdate, 'yyyy') 
                          --and e1.isbn_code like '221%'
                          )
                  group by dwbm,isbn_code
/

