create view V_DP_SRDB as
  select aa.zbmc,aa.se  from (
 select y.zbmc, x.se
  from (select ZB_DM, to_char(SUM(QKJSE / 100000000), 'fm999990.00') SE
          from srfx.ZS_CZ_FQYTJ
         where HZLX = 'Y'
           AND NY =201801
            /*case
                 when to_number(to_char(sysdate, 'dd')) <= 10 then
                  to_number(to_char(add_months(sysdate, -2), 'yyyymm'))
                 else
                  to_number(to_char(add_months(sysdate, -1), 'yyyymm'))
               end*/
           AND ZB_DM IN ('101', '102', '10302')
         group by ZB_DM) X,
       srfx.GG_PZ_TJZB y
 where x.zb_dm = y.zb_dm
   and zbtype = 'SR'
 order by y.ZB_Dm DESC) aa
/

