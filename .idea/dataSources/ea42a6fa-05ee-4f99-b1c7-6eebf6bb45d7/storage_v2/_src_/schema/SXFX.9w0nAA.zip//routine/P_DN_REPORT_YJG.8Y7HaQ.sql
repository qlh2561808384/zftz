create procedure P_DN_REPORT_YJG(out_cur out sys_refcursor, -- 调用返回结果集
                                                   n_ms    in number, -- 调用模式，其中：0-获取结构；1-预加工
                                                   v_yyid  in VARCHAR2, -- 知识库中的应用ID
                                                   v_jszmc in VARCHAR2, -- 计算值唯一名称
                                                   v_cszh  in VARCHAR2 -- 参数组合串（外部轮询时传递），格式如：NIAN=2018;YUE=7;DQ=311200;
                                                   ) is
  V_OK     BOOLEAN;
  rsCursor SYS_REFCURSOR;
  csCursor SYS_REFCURSOR;
  zdsqlCursor SYS_REFCURSOR;
  v_cszhnr VARCHAR2(500);
  str_sql VARCHAR2(2000);
  --声明参数相关变量
  n_csmc VARCHAR2(100);
  n_zdsql VARCHAR2(1000);
  n_csmrz VARCHAR2(100);
  --声明参数数据集编码和名称变量
  n_mc VARCHAR2(500);
  n_bm VARCHAR2(500);
  
  n_insql VARCHAR2(4000);
  n_jszcnt number(2);
  n_jszcnt_tmp number(2);
  n_x number;
  n_y number;
begin
  if n_ms = 0 then
    -- 根据计算值名称获取结构 （每加工一个计算值都要把计算值名称拿来在此做if判断）
    if(v_jszmc = 'htwv_2018_09_11202750391') then--htwv_2018_09_12113251370
      open out_cur for
      select ZDMC from
      (
      select '年份' ZDMC from dual
      union all
      select '收支分类' ZDMC from dual
      union all
      select '金额' ZDMC from dual
      );
    else
    --根据计算值名称获取结构 TODO:暂从DN_TMP_JSZ_ZD表中配置获取
      open out_cur for
      select ZDMC
        from DN_TMP_JSZ_ZD
       where YYID = v_yyid
         and JSZMC = v_jszmc;
    end if;
  else
    V_OK := true;
    -- 查找计算值是否存在？TODO: 表DN_TMP_JSZ_ZD替换成DN_DY_JSZ
    select count(1)
      into n_jszcnt
      from DN_DY_JSZ
     where YYID = v_yyid
       and JSZMC = v_jszmc;
    
    select count(1)
      into n_jszcnt_tmp
      from DN_TMP_JSZ_ZD
     where YYID = v_yyid
       and JSZMC = v_jszmc;
    if n_jszcnt = 0 and n_jszcnt_tmp = 0 then
      V_OK := false;
    else
      -- 根据计算值进行预加工
      if v_cszh is not null then
        -- v_cszh不为空，代表外部轮询，只需预加工指定参数值的数据
        V_OK := F_DN_ZNFXBG_YJG_ZB_JSZ(v_yyid, v_jszmc, v_cszh);
      else
        -- v_cszh为空，代表内部轮询，需预加工所有参数组合的数据
        -- TODO:根据计算值参数DN_DY_JSZ_CS并结合全局参数DN_DY_QJCS的定义，遍历生成所有参数的组合串
        -- 注意：参数组合串的顺序，需严格按照DN_DY_JSZ_CS中的CSSX顺序构建
      
        -- 暂以从DN_TMP_JSZ_CS_ZH表中配置参数组合的方式进行预加工的遍历
        /*OPEN rsCursor for
          select CSZHNR
            from DN_TMP_JSZ_CS_ZH
           where YYID = v_yyid
             and JSZMC = v_jszmc;*/
             
        --根据应用id（v_yyid)和计算值名称（v_jszmc）获取计算值参数列表及sql语句、默认值 
        open csCursor for
        select cs.csmc,qjcs.zdsql,qjcs.csmrz
        from dn_dy_qjcs qjcs 
        left join dn_dy_jsz_cs cs on qjcs.yyid=cs.yyid and qjcs.csmc=cs.csmc
        where  cs.jszmc=v_jszmc and qjcs.yyid=v_yyid 
        order by cs.cssx;
        n_x:=1;
        
        --创建临时表（后来放弃直接在过程里创建临时表，在外部创建，语句如下）
/*        str_sql := 'create global temporary table temp_table_zhc(
                 col1 varchar2(100),
                 col2 varchar2(100)
             ) on commit preserve rows';
        execute immediate str_sql;*/
             
        loop
          fetch csCursor 
            into n_csmc,n_zdsql,n_csmrz;
          exit when csCursor%NOTFOUND;
          
          if n_zdsql is null then
            n_bm:=n_csmrz;
            str_sql:= 'insert into temp_table_zhc  (select '||n_x||','''||n_csmc||'='||n_bm||';'||'''  from dual)';
            execute immediate str_sql;
          else
            open zdsqlCursor for
            n_zdsql;
            loop
             fetch zdsqlCursor into n_bm,n_mc;
              exit when zdsqlCursor%NOTFOUND;
             str_sql:= 'insert into temp_table_zhc  (select '||n_x||','''||n_csmc||'='||n_bm||';'||'''  from dual)';
             execute immediate str_sql;
            end loop;
            close zdsqlCursor;
          end if;
          n_x:=n_x+1;
        end loop;
        close csCursor;
        n_y:=n_x-1;
         WHILE  n_y >0 loop
        n_insql:=n_insql||' (select col2 from temp_table_zhc where col1='||n_y||')t'||n_y;
        if(n_y<>1) then
        n_insql:= n_insql||',';
        end if;
        n_y:=n_y-1;
        end loop;
        n_y:=n_x-1;
        n_insql:=' from '|| n_insql;
        while n_y>0 loop
          if(n_y<>n_x-1) then
           n_insql:='||'||n_insql;
          end if;
          n_insql:='t'||n_y||'.col2'||n_insql;
          n_y:=n_y-1;
          end loop;
        n_insql:='select '|| n_insql;
        
        --返回参数组合
       -- open out_cur for n_insql;--测试返回参数组合
        open rsCursor for n_insql;
        loop
          fetch rsCursor
            into v_cszhnr;
          exit when rsCursor%NOTFOUND;
          V_OK := F_DN_ZNFXBG_YJG_ZB_JSZ(v_yyid, v_jszmc, v_cszhnr);
        end loop;
        close rsCursor;
 
      end if;
    end if;
  
    -- 返回预加工结果，其中：状态(zt)0-成功；1-失败（失败时填充错误信息cwxx字段内容）
    if V_OK = true then
      open out_cur for
        select 0 zt, '预加工完成！' cwxx from dual;
    else
      open out_cur for
        select 1 zt, '错误信息！！！' cwxx from dual;
    end if;
  
  end if;
end P_DN_REPORT_YJG;
/

