create view YHGL_DM_DW as
  select "YYBM","GUID","BM","MC","PID","LX","PXH","SFDJ" from (
select t01.yybm,
       t01.c_id guid,
       t02.c_org_code bm,
       t02.c_orgname mc,
       case when t02.c_parent_id=1 then 0 else t02.c_parent_id end pid,
       '2' lx,
       t02.c_sort_no pxh,
       t02.sfdj
  from xtgl_dm_dwdy t01, (select t.*,connect_by_isleaf sfdj  from mv_cos_organization_org t start with t.c_id=1480 connect by prior t.c_id=t.c_parent_id) t02
 where t01.c_id = t02.c_id
 union all
 select t01.yybm,
       t01.c_id guid,
       t02.c_org_code bm,
       t02.c_org_code||t02.c_orgname mc,
       case when t02.c_parent_id=1 then 0 else t02.c_parent_id end pid,
       '1' lx,
       t02.c_sort_no pxh,
       t02.sfdj
  from xtgl_dm_dwdy t01, (select t.*,connect_by_isleaf sfdj  from mv_cos_organization_org t start with t.c_id=56150342 connect by prior t.c_id=t.c_parent_id) t02
 where t01.c_id = t02.c_id) aa order by aa.lx desc,aa.bm
/

