create procedure P_YJJK_YW_YWJZ(yjgzbm in VARCHAR,  --预警规则编码
                                           jzfw   in VARCHAR,  --加载范围
                                           TSDXLX in VARCHAR,  --推送对象类型
                                           TSDXID in VARCHAR,   --通知分组id
                                           sendsms in VARCHAR,  --是否短信提醒(0:否 1:是)
                                           ssyybm in VARCHAR) as --所属应用编码


sendZt VARCHAR(2);
tempTsdxlx VARCHAR(2);
tempTsdxid VARCHAR(15);
begin

  sendZt:=sendsms;

  --IF dxid is not null THEN
  --白名单处理
  update yjjk_yw_yjsj_TEMP p set p.zt='1' where
        (p.tsdxlx='0' and exists(select 1 from yhgl_gg_ryqzyh v,
            (select b.USERID,t.guid tempguid from yjjk_yw_yjsj_TEMP t,YJJK_YW_BMD b
            where t.YJFLBM=b.YJFLBM and t.YJGZBM=b.YJGZBM and t.YWBM=b.YWBM and sysdate>b.STARTTIME
            and b.ENDTIME>sysdate) u
            where v.yhid=u.USERID and v.qzid=p.tsdxid and u.tempguid=p.guid))
        or (p.tsdxlx='1' and exists(select 1 from YHGL_YW_YHYY v,
            (select b.USERID,t.guid tempguid from yjjk_yw_yjsj_TEMP t,YJJK_YW_BMD b
            where t.YJFLBM=b.YJFLBM and t.YJGZBM=b.YJGZBM and t.YWBM=b.YWBM and sysdate>b.STARTTIME
            and b.ENDTIME>sysdate) u
            where v.GUID=u.USERID and v.SZDWID=p.tsdxid and u.tempguid=p.GUID ))
        or (p.tsdxlx='2' and exists(select 1 from YHGL_YW_YHYY v,
            (select b.USERID,t.guid tempguid from yjjk_yw_yjsj_TEMP t,YJJK_YW_BMD b
            where t.YJFLBM=b.YJFLBM and t.YJGZBM=b.YJGZBM and t.YWBM=b.YWBM and sysdate>b.STARTTIME
            and b.ENDTIME>sysdate) u
            where v.GUID=u.USERID and v.guid=p.tsdxid and u.tempguid=p.guid));

  --移交处理(只处理一次移交)
  --推送对象类型为群组
    update yjjk_yw_yjsj_TEMP p set p.tsdxid=(select distinct g.tsdxid from (select v.qzid guid,u.tsdxid from yhgl_gg_ryqzyh v,
                                                  (select b.cjyhid,b.tsdxid from yjjk_yw_yjsj_TEMP t,YJJK_YW_RWYJ b where
                                              (b.YJFLBM is null or t.YJFLBM=b.YJFLBM)
                                              and ((b.starttime is null and b.endtime is null)or(b.endtime>=sysdate and b.starttime is null and b.endtime is not null)or(sysdate>=b.starttime and b.starttime is not null and b.endtime is null)or
                                              (sysdate>=b.starttime and b.endtime>=sysdate and b.starttime is not null and b.endtime is not null))) u
                                              where v.yhid=u.cjyhid) g where g.guid=p.tsdxid and p.tsdxlx='0')
              where exists(select 1 from yhgl_gg_ryqzyh v,
                  (select b.cjyhid,t.guid tempguid from yjjk_yw_yjsj_TEMP t,YJJK_YW_RWYJ b where
                  (b.YJFLBM is null or t.YJFLBM=b.YJFLBM) and ((b.starttime is null and b.endtime is null)or (b.endtime>=sysdate and b.starttime is null and b.endtime is not null)or(sysdate>=b.starttime and b.starttime is not null and b.endtime is null)or
                  (sysdate>=b.starttime and b.endtime>=sysdate and b.starttime is not null and b.endtime is not null))) u
                  where v.yhid=u.cjyhid and v.qzid=p.tsdxid and u.tempguid=p.guid and p.tsdxlx='0');
   --推送对象类型为机构
     update yjjk_yw_yjsj_TEMP p set p.tsdxid=(select distinct g.tsdxid from (select v.szdwid,u.tsdxid from YHGL_YW_YHYY v,
                                              (select b.cjyhid,b.tsdxid from yjjk_yw_yjsj_TEMP t,YJJK_YW_RWYJ b where (b.YJFLBM is null or t.YJFLBM=b.YJFLBM)
                                              and ((b.starttime is null and b.endtime is null)or(b.endtime>=sysdate and b.starttime is null and b.endtime is not null)or(sysdate>=b.starttime and b.starttime is not null and b.endtime is null)or
                                              (sysdate>=b.starttime and b.endtime>=sysdate and b.starttime is not null and b.endtime is not null))) u
                                              where v.guid=u.cjyhid) g where g.szdwid=p.tsdxid and p.tsdxlx='1')
              where exists(select 1 from YHGL_YW_YHYY v,
                  (select b.cjyhid,t.guid tempguid from yjjk_yw_yjsj_TEMP t,YJJK_YW_RWYJ b where
                  (b.YJFLBM is null or t.YJFLBM=b.YJFLBM) and ((b.starttime is null and b.endtime is null)or (b.endtime>=sysdate and b.starttime is null and b.endtime is not null)or(sysdate>=b.starttime and b.starttime is not null and b.endtime is null)or
                  (sysdate>=b.starttime and b.endtime>=sysdate and b.starttime is not null and b.endtime is not null))) u
                  where v.guid=u.cjyhid and v.szdwid=p.tsdxid and u.tempguid=p.guid and p.tsdxlx='1');
   --推送对象类型为人员
     update yjjk_yw_yjsj_TEMP p set p.tsdxid=(select distinct g.tsdxid from (select v.guid,u.tsdxid from YHGL_YW_YHYY v,
                                              (select b.cjyhid,b.tsdxid from yjjk_yw_yjsj_TEMP t,YJJK_YW_RWYJ b where (b.YJFLBM is null or t.YJFLBM=b.YJFLBM)
                                              and ((b.starttime is null and b.endtime is null)or(b.endtime>=sysdate and b.starttime is null and b.endtime is not null)or(sysdate>=b.starttime and b.starttime is not null and b.endtime is null)or
                                              (sysdate>=b.starttime and b.endtime>=sysdate and b.starttime is not null and b.endtime is not null))) u
                                              where v.guid=u.cjyhid) g where g.guid=p.tsdxid and p.tsdxlx='2')
              where exists(select 1 from YHGL_YW_YHYY v,
                  (select b.cjyhid,t.guid tempguid from yjjk_yw_yjsj_TEMP t,YJJK_YW_RWYJ b where
                  (b.YJFLBM is null or t.YJFLBM=b.YJFLBM) and ((b.starttime is null and b.endtime is null)or (b.endtime>=sysdate and b.starttime is null and b.endtime is not null)or(sysdate>=b.starttime and b.starttime is not null and b.endtime is null)or
                  (sysdate>=b.starttime and b.endtime>=sysdate and b.starttime is not null and b.endtime is not null))) u
                  where v.guid=u.cjyhid and v.guid=p.tsdxid and u.tempguid=p.guid and p.tsdxlx='2');
  --END IF;

   --短信通知处理
      /*IF sendZt is not null AND sendZt='1' THEN
          select distinct(tp.TSDXLX),tp.TSDXID into tempTsdxlx,tempTsdxid from yjjk_yw_yjsj_TEMP  tp where not exists (select 1  from yjjk_yw_yjsj sj where  sj.LYFS ='1000' and  sj.yjgzbm =tp.yjgzbm and sj.YWBM = tp.YWBM and sj.zt='0');
          
          IF tempTsdxid is not null THEN
            IF tempTsdxlx='0' then  --群组
                insert into SMS.SMS_SEND (msgid,platid,receiver,msg,zt,createdate,sendcount) select sys_guid(),'4',phone.ydhm,tp.yjgzbm,'0',sysdate,0 from (select distinct(yjgzbm) from yjjk_yw_yjsj_TEMP) tp,
                      (select h.ydhm from V_YGHL_GG_QZDYH v,yhgl_yw_yhyy y,yhgl_yw_yh h where y.guid=v.userid and y.yhid=h.guid and v.guid=tempTsdxid) phone where 1=1;
            ELSIF tempTsdxlx='1' then --机构
                insert into SMS.SMS_SEND (msgid,platid,receiver,msg,zt,createdate,sendcount) select sys_guid(),'4',phone.ydhm,tp.yjgzbm,'0',sysdate,0 from (select distinct(yjgzbm) from yjjk_yw_yjsj_TEMP) tp,
                      (select yh.ydhm from yhgl_yw_yhyy yy,yhgl_yw_yh yh where yy.yhid=yh.guid and yy.szdwid=tempTsdxid) phone where 1=1;
            ELSIF tempTsdxlx='2' then --人
                insert into SMS.SMS_SEND (msgid,platid,receiver,msg,zt,createdate,sendcount) select sys_guid(),'4',phone.ydhm,tp.yjgzbm,'0',sysdate,0 from (select distinct(yjgzbm) from yjjk_yw_yjsj_TEMP) tp,
                      (select yh.ydhm from yhgl_yw_yhyy yy,yhgl_yw_yh yh where yy.yhid=yh.guid and yy.guid=tempTsdxid) phone where 1=1;
            END IF;
          END IF;

      END IF;*/


   --如果推送对象类型为群组并且满足生成预警数据的条件，则调用存储过程
     for cur in (select s.arr,l.tsdxid from (SELECT REGEXP_SUBSTR (TO_CHAR(t.guids), '[^,]+', 1,rownum) arr
                FROM (select to_char(WMSYS.wm_concat(tp.guid)) guids from yjjk_yw_yjsj_TEMP tp where tp.tsdxlx='0' and
                         not exists (select 1  from yjjk_yw_yjsj sj where  sj.LYFS ='1000' and  sj.yjgzbm =tp.yjgzbm and sj.YWBM = tp.YWBM and sj.zt='0')) t
                CONNECT BY ROWNUM <= LENGTH (TO_CHAR(t.guids)) - LENGTH (REPLACE (TO_CHAR(t.guids), ',', ''))+1) s,yjjk_yw_yjsj_TEMP l where s.arr=l.guid)
     LOOP
       if cur.arr is not null then
         begin
            P_YHGL_QZDYH(cur.tsdxid,cur.arr,ssyybm);
         end;
       end if;
     end LOOP;


  --3，自动消除预警 ，根据预警规则编码+业务数据唯一编码，
      --3.1 如果现有的数据有匹配的数据，则不做操作

      --3.2 如果现有的数据中没有匹配的数据，则插入到数据推送表中
      insert into  yjjk_yw_yjsj
      (guid, YJFLBM,YJGZBM, YWBM, YWMC,  LYFS, YJSJ, MS,TSDXLX, TSDXID, ZT, PCH, SFFC, CJSJ,SENDSMS,CJYHID)
      select guid, YJFLBM,YJGZBM, YWBM, YWMC,  LYFS, YJSJ, MS,TSDXLX, TSDXID, ZT, PCH, SFFC, CJSJ,SENDSMS,CJYHID
        from yjjk_yw_yjsj_TEMP  tp where
           not exists (select 1  from yjjk_yw_yjsj sj where  sj.LYFS ='1000' and  sj.yjgzbm =tp.yjgzbm and sj.YWBM = tp.YWBM and sj.zt='0');
      --3.3 如果此预警规则编码匹配到的数据，在新产生的数据推送中查不到，则自动消除。

      insert into  yjjk_yw_yjsjjl
      (GUID, YJSJID, SYHJID, MS,CLCZ,CLSJ,SFFC)
      select SEQ_YJJK_YW_YJSJJL.Nextval,sj.guid,
        (select max(guid) from yjjk_yw_yjsjjl jl where jl.yjsjid=sj.guid),
        '自动消除预警','21',sysdate,'0'
       from  yjjk_yw_yjsj sj
          where  sj.LYFS ='1000' and  sj.yjgzbm =yjgzbm
              and sj.zt='0' and not exists (
                 select 1 from  yjjk_yw_yjsj_TEMP temp  where sj.ywbm = temp.ywbm
              );
      update  yjjk_yw_yjsj sj  set sj.zt = '1'
          where  sj.LYFS ='1000' and  sj.yjgzbm =yjgzbm
              and sj.zt='0' and not exists (
                 select 1 from  yjjk_yw_yjsj_TEMP temp  where sj.ywbm = temp.ywbm
              );


      EXCEPTION
          WHEN NO_DATA_FOUND THEN
                   tempTsdxid:=NULL;

end;
/

