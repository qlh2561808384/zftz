create procedure TMP_TEST2
(
  yjgzbm in VARCHAR,  --预警规则编码
  jzfw   in VARCHAR,  --加载范围
  TSDXLX in VARCHAR,  --推送对象类型
  TSDXID in NUMBER,  --推送对象
  result out sys_refcursor
) as pch NUMBER;
begin
  --1，生成批次
  SELECT seq_yjjk_yw_yjsj_pch.nextval into pch from dual;

  open result for
   select 
   (select YJFLBM from yjjk_dm_yjgz yjgz where yjgz.bm= yjgzbm ) YJFLBM,
        yjgzbm YJGZBM,g.year||'-'||g.gplanid ywbm,g.divisionname YWMC,'1000' LYFS,TSDXID tsdxid, '0' ZT, pch PCH,
        to_char(sysdate, 'yyyy-mm-dd hh24:mi:ss') YJSJ,'支出不规范'||g.gplanid ms,TSDXLX as tsdxlx from zjsb.gplan g where g.year=2017
and  '2018'||substr(g.reportdate,6,2)||substr(g.reportdate,9,2)=to_char(sysdate,'yyyymmdd');
end TMP_TEST2;


/*select * from zjsb.gplan g where g.year=2017
and  '2018'||substr(g.reportdate,6,2)||substr(g.reportdate,9,2)=to_char(sysdate,'yyyymmdd')*/

