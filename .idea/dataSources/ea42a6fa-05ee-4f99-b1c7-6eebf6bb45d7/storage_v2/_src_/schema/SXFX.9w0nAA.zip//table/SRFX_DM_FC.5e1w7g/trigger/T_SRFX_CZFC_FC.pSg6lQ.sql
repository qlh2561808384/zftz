create trigger T_SRFX_CZFC_FC
  after insert
  on SRFX_DM_FC
  declare
  --a number;
begin
insert into srfx_dm_czfp
select distinct f.czfp_dm,f.czfpmc,t.sjczfpdm,'Y',1,'Y','','N','N','Y'
from srfx_dm_fc f,srfx_dm_fcfpdy t
where f.czfp_dm_fc=t.czfp_dm 
and f.czfp_dm in 
(
select czfp_dm from srfx_dm_fc
minus
select czfp_dm from srfx_dm_czfp
);
end t_srfx_czfc_fc;
/

