create view V_ZFTZ_ZGDW as
  select t.C_ID id,
       t.C_ORG_CODE bm,
       t.C_ORGNAME mc,
       0 fjbm,
       case
         when t.C_DELETED = 0 then
          'Y'
         else
          'N'
       end yxbz,
       '' bz
  from mv_cos_organization_org t
 where t.C_DELETED = 0
   and t.C_ORG_CODE like '%001'
   order by t.C_ORG_CODE
/

