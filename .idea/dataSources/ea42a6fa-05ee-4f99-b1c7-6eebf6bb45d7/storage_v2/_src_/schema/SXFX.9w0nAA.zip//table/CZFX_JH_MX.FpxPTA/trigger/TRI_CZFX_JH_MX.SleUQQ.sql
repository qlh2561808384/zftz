create trigger TRI_CZFX_JH_MX
  before insert
  on CZFX_JH_MX
  for each row
  begin
select SEQ_czfx_jh_mx.nextval into :new.bm from dual;
end ;
/

