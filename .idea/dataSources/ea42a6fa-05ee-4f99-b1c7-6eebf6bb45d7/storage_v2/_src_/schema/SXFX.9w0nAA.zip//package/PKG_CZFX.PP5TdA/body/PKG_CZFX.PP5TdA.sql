create package body pkg_CZFX is
  ------------------金财工程_指标明细---------------------------
  procedure GET_CZFX_JCGC_ZBMX(riqi varchar2) is

  begin
    /*  insert into TMP_XTW_CZFX (a,b,c,d)
    select substr(riqi,5,2),
    substr(riqi, 7, 2),
    substr(riqi, 7, 2),to_char(sysdate,'yyyymmdd') from dual;*/
    /*日期如果在每年的1月1日至1月3日之间，则先删除当年及上年的指标明细，再重新插入*/
    if substr(riqi, 5, 2) = '01' and substr(riqi, 7, 2) >= '01' and
       substr(riqi, 7, 2) <= '03' then
      delete from CZFX_JCGC_ZBMX
       where xzqh = '3306010101'
         and year in (substr(riqi, 0, 4), substr(riqi, 0, 4) - 1);
      insert into czfx_jcgc_zbmx
        select '3306010101' xzqh,
               b.year,
               case when  to_number(substr(replace(b1.inputdate,  '.', ''),1,4))>b.year then b.year||'12' when  to_number(substr(replace(b1.inputdate,'.', ''),1,4))<b.year then b.year||'01' else  substr(replace(b1.inputdate, '.', ''),0,6) end rzny,
               case when  to_number(substr(replace(b1.inputdate,  '.', ''),1,4))>b.year then b.year||'1231' when  to_number(substr(replace(b1.inputdate,'.', ''),1,4))<b.year then b.year||'0101' else  replace(b1.inputdate, '.', '') end rzrq,
               --replace(b1.inputdate, '.', '') rzrq,
               -------预算单位编码--------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_YSDW') = 1 then
                        (select case when
                  (select case
                            when a1.dwbm is null then
                             '-1'
                            else
                             a1.dwbm
                          end
                     from CZFX_DM_YSDW a1
                    where a1.dwbm = e.isbn_code)
                    is null then '-1' else
                    (select case
                            when a1.dwbm is null then
                             '-1'
                            else
                             a1.dwbm
                          end
                     from CZFX_DM_YSDW a1
                    where a1.dwbm = e.isbn_code)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_YSDW') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_YSDW'
                      and a3.dynf = b.year
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = e.isbn_code)
                       is null then '-1' else
                       (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_YSDW'
                      and a3.dynf = b.year
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = e.isbn_code)
                      end from dual)
                 else
                  '-1'
               end dwbm,
               -------------------------------
              -- '' dwmc, --预留 单位名称e.isbn_code
              -- '' zgdwbm, --预留 主管单位名称ee.isbn_code,
              --'' zgdwmc, --预留 主管单位名称ee.name,
              -- '' division, --预留 单位所属归口e.division
              --'' ssgkmc, --预留 单位所属归口名称d.name
               ------------单位性质----------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_DWXZ') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_DWXZ a1
                    where a1.bm = e.enterprisekind)
                    is null then '-1' else
                     (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_DWXZ a1
                    where a1.bm = e.enterprisekind)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_DWXZ') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_DWXZ'
                      and a3.dynf = b.year
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = e.enterprisekind)
                      is null then '-1' else
                       (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_DWXZ'
                      and a3.dynf = b.year
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = e.enterprisekind)
                      end from dual)
                 else
                  '-1'
               end dwxz,
               ----------支付类型-------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_ZFLX') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZFLX a1
                    where a1.bm = e.paytype)
                    is null then '-1' else
                     (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZFLX a1
                    where a1.bm = e.paytype)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_ZFLX') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZFLX'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e.paytype)
                      is null then '-1' else
                        (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZFLX'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e.paytype)
                      end from dual)
                 else
                  '-1'
               end zflx,
               -- '' dwlx, --预留 单位类型e.enterprisetype
               -------收支分类-------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_SZFL') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_SZFL a1
                    where a1.bm = F.SZTYPE)
                    is null then '-1' else
                      (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_SZFL a1
                    where a1.bm = F.SZTYPE)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_SZFL') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_SZFL'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = F.SZTYPE)
                      is null then '-1' else
                        (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_SZFL'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = F.SZTYPE)
                      end from dual)
                 else
                  '-1'
               end szfl,
               -----------功能科目-----------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_GNKM') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_GNKM a1
                    where a1.bm = f.isbn_code)
                    is null then '-1' else
                     (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_GNKM a1
                    where a1.bm = f.isbn_code)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_GNKM') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_GNKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = f.isbn_code)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_GNKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = f.isbn_code)
                      end from dual)
                 else
                  '-1'
               end gnkmbm,
               ----------------------------
               --f.code gnkmbm,
              -- '' gnkmmc, --预留 功能科目名称f.name,
               ---------政府经济科目----------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_ZFJJKM') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZFJJKM a1
                    where a1.bm = e2.isbn_code)
                    is null then '-1' else
                    (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZFJJKM a1
                    where a1.bm = e2.isbn_code)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_ZFJJKM') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZFJJKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e2.isbn_code)
                      is null then '-1' else
                       (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZFJJKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e2.isbn_code)
                      end from dual)
                 else
                  '-1'
               end zfjjkmbm,
               --------------------------------------
               -- e2.code zfjjkmbm,
              -- '' zfjjkmmc, --预留 政府经济科目名称e2.name,
               ----------部门经济科目---------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_BMJJKM') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_BMJJKM a1
                    where a1.bm = e1.isbn_code)
                    is null then '-1' else
                     (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_BMJJKM a1
                    where a1.bm = e1.isbn_code)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_BMJJKM') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_BMJJKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e1.isbn_code)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_BMJJKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e1.isbn_code)
                      end from dual)
                 else
                  '-1'
               end bmjjkmbm,
               --------------------------------
               --e1.code bmjjkmbm,
              -- '' bmjjkmmc, --预留 部门经济科目名称e1.name,

               --------项目类别---------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_XMLB') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_XMLB a1
                    where a1.bm = d.programtypecode)
                    is null then '-1' else
                           (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_XMLB a1
                    where a1.bm = d.programtypecode)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_XMLB') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_XMLB'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = d.programtypecode)
                      is null then '-1' else
                       (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_XMLB'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = d.programtypecode)
                      end from dual)
                 else
                  '-1'
               end xmlb,
               ------------------------------
               --d.programtypecode,
              -- '' xmlbmc, --预留 项目类别名称d.programtypename,
               p.guid,
               case
                 when p.isbn_code is null then
                  '-1'
                 else
                  p.isbn_code
               end xmbm,
               p.name,
               --------资金来源------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_ZJLY_JCGC') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZJLY_JCGC a1
                    where a1.bm = b1.resourceincode)
                    is null then '-1' else
                    (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZJLY_JCGC a1
                    where a1.bm = b1.resourceincode)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_ZJLY_JCGC') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZJLY_JCGC'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = b1.resourceincode)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZJLY_JCGC'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = b1.resourceincode)
                      end from dual)
                 else
                  '-1'
               end zjly,
               ---------------------
               --b1.resourceincode,
               b1.dwqkwh,
               ------指标所属归口----------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_GKCS') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_GKCS a1
                    where a1.bm = b1.divisionguid)
                    is null then '-1' else
                    (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_GKCS a1
                    where a1.bm = b1.divisionguid)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_GKCS') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_GKCS'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = b1.divisionguid)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_GKCS'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = b1.divisionguid)
                      end from dual)
                 else
                  '-1'
               end zbssgk,
               ----------------------------
               --b1.divisionguid,
               b1.budgetyear,
               b1.budgetcategoryguid,
               -------指标类型--------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_ZBLX') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZBLX a1
                    where a1.bm = b1.budgetcategoryguid)
                    is null then '-1' else
                      (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZBLX a1
                    where a1.bm = b1.budgetcategoryguid)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_ZBLX') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZBLX'
                      and a3.dynf = b1.year
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = b1.budgetcategoryguid)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZBLX'
                      and a3.dynf = b1.year
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = b1.budgetcategoryguid)
                      end from dual)
                 else
                  '-1'
               end zblxbm,
               ----------------------
               '' zblxmc, --预留 指标类型名称bb.name
               b.budgetid,
               b.detailid,
               case
                 when e3.caigou is null then
                  0
                 else
                  e3.caigou
               end caigou,
               -------采购目录-------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_CGML') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_CGML a1
                    where a1.bm = e3.buycatalogcode)
                    is null then '-1' else
                    (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_CGML a1
                    where a1.bm = e3.buycatalogcode)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_CGML') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_CGML'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e3.buycatalogcode)
                      is null then '-1' else
                       (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_CGML'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e3.buycatalogcode)
                      end from dual)
                 else
                  '-1'
               end cgml,
               ----------------------
               -- e3.buycatalogcode,
               ----采购类型------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_CGLX') = 1 and e3.caigou = 1 and
                      e3.buytypecode is not null then
                      (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_CGLX a1
                    where a1.bm = e3.buytypecode)
                    is null then '-1' else
                     (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_CGLX a1
                    where a1.bm = e3.buytypecode)
                    end from dual)
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_CGLX') = 1 and e3.caigou = 1 and
                      e3.buytypecode is null then
                  '-1'
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_CGLX') = 2 and e3.caigou = 1 and
                      e3.buytypecode is not null then
                      (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            when (select a.jcgc
                                    from czfx_dm_bmbqd a
                                   where a.bmb = 'CZFX_DM_CGLX') = 2 and
                                 e3.caigou = 1 and e3.buytypecode is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_CGLX'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e3.buytypecode)
                      is null then '-1' else
                       (select case
                            when a3.bm is null then
                             '-1'
                            when (select a.jcgc
                                    from czfx_dm_bmbqd a
                                   where a.bmb = 'CZFX_DM_CGLX') = 2 and
                                 e3.caigou = 1 and e3.buytypecode is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_CGLX'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e3.buytypecode)
                    end from dual)
                 else
                  e3.buytypecode
               end cglx,
               -------------------------
               b.money,
               sysdate xgrq
        --count(*)
          from zjsb.budgetdetail b
          left join jczl.economysectiongov e2
            on b.ecogovguid = e2.guid
           and b.year = e2.year, zjsb.budget b1
          left join zbgl.enterpriseassignquota e3
            on b1.budgetid1 = e3.enterpriseid
          left join zbgl.detailassignquota d
            on e3.itemid = d.itemid
          left join jczl.enterprise e
            on b1.enterpriseguid = e.guid
          left join jczl.enterprise ee
            on e.parent_guid = ee.guid
          left join jczl.budgetcategory bb
            on b1.budgetcategoryguid = bb.guid, jczl.economysection e1,
         jczl.functionsection f, jczl.program p
         where b.budgetid = b1.budgetid
           and b.year = b1.year
           and b.resourceincode = b1.resourceincode
           and b.year = e.year
           and b.year = e1.year
           and b.year = f.year
           and b.economysectionguid = e1.guid
           and b1.functionguid = f.guid
           and b1.enterpriseguid = e.guid
           and b1.programguid = p.guid
           and b.year in (substr(riqi, 0, 4), substr(riqi, 0, 4) - 1);

    else
      delete from CZFX_JCGC_ZBMX
       where xzqh = '3306010101'
         and year = substr(riqi, 0, 4);
      insert into czfx_jcgc_zbmx
        select '3306010101' xzqh,
               b.year,
               case when  to_number(substr(replace(b1.inputdate,  '.', ''),1,4))>b.year then b.year||'12' when  to_number(substr(replace(b1.inputdate,'.', ''),1,4))<b.year then b.year||'01' else  substr(replace(b1.inputdate, '.', ''),0,6) end rzny,
               case when  to_number(substr(replace(b1.inputdate,  '.', ''),1,4))>b.year then b.year||'1231' when  to_number(substr(replace(b1.inputdate,'.', ''),1,4))<b.year then b.year||'0101' else  replace(b1.inputdate, '.', '') end rzrq,
              -- replace(b1.inputdate, '.', '') rzrq,
               -------预算单位编码--------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_YSDW') = 1 then
                        (select case when
                  (select case
                            when a1.dwbm is null then
                             '-1'
                            else
                             a1.dwbm
                          end
                     from CZFX_DM_YSDW a1
                    where a1.dwbm = e.isbn_code)
                    is null then '-1' else
                    (select case
                            when a1.dwbm is null then
                             '-1'
                            else
                             a1.dwbm
                          end
                     from CZFX_DM_YSDW a1
                    where a1.dwbm = e.isbn_code)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_YSDW') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_YSDW'
                      and a3.dynf = b.year
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = e.isbn_code)
                       is null then '-1' else
                       (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_YSDW'
                      and a3.dynf = b.year
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = e.isbn_code)
                      end from dual)
                 else
                  '-1'
               end dwbm,
               -------------------------------
              -- '' dwmc, --预留 单位名称e.isbn_code
              -- '' zgdwbm, --预留 主管单位名称ee.isbn_code,
              -- '' zgdwmc, --预留 主管单位名称ee.name,
              -- '' division, --预留 单位所属归口e.division
              -- '' ssgkmc, --预留 单位所属归口名称d.name
               ------------单位性质----------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_DWXZ') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_DWXZ a1
                    where a1.bm = e.enterprisekind)
                    is null then '-1' else
                     (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_DWXZ a1
                    where a1.bm = e.enterprisekind)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_DWXZ') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_DWXZ'
                      and a3.dynf = b.year
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = e.enterprisekind)
                      is null then '-1' else
                       (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_DWXZ'
                      and a3.dynf = b.year
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = e.enterprisekind)
                      end from dual)
                 else
                  '-1'
               end dwxz,
               ----------支付类型-------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_ZFLX') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZFLX a1
                    where a1.bm = e.paytype)
                    is null then '-1' else
                     (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZFLX a1
                    where a1.bm = e.paytype)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_ZFLX') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZFLX'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e.paytype)
                      is null then '-1' else
                        (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZFLX'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e.paytype)
                      end from dual)
                 else
                  '-1'
               end zflx,
               -- '' dwlx, --预留 单位类型e.enterprisetype
               -------收支分类-------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_SZFL') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_SZFL a1
                    where a1.bm = F.SZTYPE)
                    is null then '-1' else
                      (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_SZFL a1
                    where a1.bm = F.SZTYPE)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_SZFL') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_SZFL'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = F.SZTYPE)
                      is null then '-1' else
                        (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_SZFL'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = F.SZTYPE)
                      end from dual)
                 else
                  '-1'
               end szfl,
               -----------功能科目-----------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_GNKM') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_GNKM a1
                    where a1.bm = f.isbn_code)
                    is null then '-1' else
                     (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_GNKM a1
                    where a1.bm = f.isbn_code)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_GNKM') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_GNKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = f.isbn_code)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_GNKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = f.isbn_code)
                      end from dual)
                 else
                  '-1'
               end gnkmbm,
               ----------------------------
               --f.code gnkmbm,
              -- '' gnkmmc, --预留 功能科目名称f.name,
               ---------政府经济科目----------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_ZFJJKM') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZFJJKM a1
                    where a1.bm = e2.isbn_code)
                    is null then '-1' else
                    (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZFJJKM a1
                    where a1.bm = e2.isbn_code)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_ZFJJKM') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZFJJKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e2.isbn_code)
                      is null then '-1' else
                       (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZFJJKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e2.isbn_code)
                      end from dual)
                 else
                  '-1'
               end zfjjkmbm,
               --------------------------------------
               -- e2.code zfjjkmbm,
             --  '' zfjjkmmc, --预留 政府经济科目名称e2.name,
               ----------部门经济科目---------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_BMJJKM') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_BMJJKM a1
                    where a1.bm = e1.isbn_code)
                    is null then '-1' else
                     (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_BMJJKM a1
                    where a1.bm = e1.isbn_code)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_BMJJKM') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_BMJJKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e1.isbn_code)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_BMJJKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e1.isbn_code)
                      end from dual)
                 else
                  '-1'
               end bmjjkmbm,
               --------------------------------
               --e1.code bmjjkmbm,
              -- '' bmjjkmmc, --预留 部门经济科目名称e1.name,

               --------项目类别---------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_XMLB') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_XMLB a1
                    where a1.bm = d.programtypecode)
                    is null then '-1' else
                           (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_XMLB a1
                    where a1.bm = d.programtypecode)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_XMLB') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_XMLB'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = d.programtypecode)
                      is null then '-1' else
                       (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_XMLB'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = d.programtypecode)
                      end from dual)
                 else
                  '-1'
               end xmlb,
               ------------------------------
               --d.programtypecode,
              -- '' xmlbmc, --预留 项目类别名称d.programtypename,
               p.guid,
               case
                 when p.isbn_code is null then
                  '-1'
                 else
                  p.isbn_code
               end xmbm,
               p.name,
               --------资金来源------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_ZJLY_JCGC') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZJLY_JCGC a1
                    where a1.bm = b1.resourceincode)
                    is null then '-1' else
                    (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZJLY_JCGC a1
                    where a1.bm = b1.resourceincode)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_ZJLY_JCGC') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZJLY_JCGC'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = b1.resourceincode)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZJLY_JCGC'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = b1.resourceincode)
                      end from dual)
                 else
                  '-1'
               end zjly,
               ---------------------
               --b1.resourceincode,
               b1.dwqkwh,
               ------指标所属归口----------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_GKCS') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_GKCS a1
                    where a1.bm = b1.divisionguid)
                    is null then '-1' else
                    (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_GKCS a1
                    where a1.bm = b1.divisionguid)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_GKCS') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_GKCS'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = b1.divisionguid)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_GKCS'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = b1.divisionguid)
                      end from dual)
                 else
                  '-1'
               end zbssgk,
               ----------------------------
               --b1.divisionguid,
               b1.budgetyear,
               b1.budgetcategoryguid,
               -------指标类型--------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_ZBLX') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZBLX a1
                    where a1.bm = b1.budgetcategoryguid)
                    is null then '-1' else
                      (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZBLX a1
                    where a1.bm = b1.budgetcategoryguid)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_ZBLX') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZBLX'
                      and a3.dynf = b1.year
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = b1.budgetcategoryguid)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZBLX'
                      and a3.dynf = b1.year
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = b1.budgetcategoryguid)
                      end from dual)
                 else
                  '-1'
               end zblxbm,
               ----------------------
               '' zblxmc, --预留 指标类型名称bb.name
               b.budgetid,
               b.detailid,
               case
                 when e3.caigou is null then
                  0
                 else
                  e3.caigou
               end caigou,
               -------采购目录-------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_CGML') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_CGML a1
                    where a1.bm = e3.buycatalogcode)
                    is null then '-1' else
                    (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_CGML a1
                    where a1.bm = e3.buycatalogcode)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_CGML') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_CGML'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e3.buycatalogcode)
                      is null then '-1' else
                       (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_CGML'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e3.buycatalogcode)
                      end from dual)
                 else
                  '-1'
               end cgml,
               ----------------------
               -- e3.buycatalogcode,
               ----采购类型------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_CGLX') = 1 and e3.caigou = 1 and
                      e3.buytypecode is not null then
                      (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_CGLX a1
                    where a1.bm = e3.buytypecode)
                    is null then '-1' else
                     (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_CGLX a1
                    where a1.bm = e3.buytypecode)
                    end from dual)
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_CGLX') = 1 and e3.caigou = 1 and
                      e3.buytypecode is null then
                  '-1'
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_CGLX') = 2 and e3.caigou = 1 and
                      e3.buytypecode is not null then
                      (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            when (select a.jcgc
                                    from czfx_dm_bmbqd a
                                   where a.bmb = 'CZFX_DM_CGLX') = 2 and
                                 e3.caigou = 1 and e3.buytypecode is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_CGLX'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e3.buytypecode)
                      is null then '-1' else
                       (select case
                            when a3.bm is null then
                             '-1'
                            when (select a.jcgc
                                    from czfx_dm_bmbqd a
                                   where a.bmb = 'CZFX_DM_CGLX') = 2 and
                                 e3.caigou = 1 and e3.buytypecode is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_CGLX'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e3.buytypecode)
                    end from dual)
                 else
                  e3.buytypecode
               end cglx,
               -------------------------
               b.money,
               sysdate xgrq
        --count(*)
          from zjsb.budgetdetail b
          left join jczl.economysectiongov e2
            on b.ecogovguid = e2.guid
           and b.year = e2.year, zjsb.budget b1
          left join zbgl.enterpriseassignquota e3
            on b1.budgetid1 = e3.enterpriseid
          left join zbgl.detailassignquota d
            on e3.itemid = d.itemid
          left join jczl.enterprise e
            on b1.enterpriseguid = e.guid
          left join jczl.enterprise ee
            on e.parent_guid = ee.guid
          left join jczl.budgetcategory bb
            on b1.budgetcategoryguid = bb.guid, jczl.economysection e1,
         jczl.functionsection f, jczl.program p
         where b.budgetid = b1.budgetid
           and b.year = b1.year
           and b.resourceincode = b1.resourceincode
           and b.year = e.year
           and b.year = e1.year
           and b.year = f.year
           and b.economysectionguid = e1.guid
           and b1.functionguid = f.guid
           and b1.enterpriseguid = e.guid
           and b1.programguid = p.guid
           and b.year = substr(riqi, 0, 4);
    end if;
    update CZFX_JCGC_ZBMX t set t.cgml='' where t.sfcg=0 ;
    update CZFX_JCGC_ZBMX t set t.zbnd='-1' where t.zbnd is null ;
    commit;
  end;
  ------------------金财工程_用款计划---------------------------
  procedure GET_CZFX_JCGC_YKJH(riqi varchar2) is

  begin
    /*日期如果在每年的1月1日至1月3日之间，则先删除当年及上年的用款计划，再重新插入*/
    if substr(riqi, 5, 2) = '01' and substr(riqi, 7, 2) >= '01' and
       substr(riqi, 7, 2) <= '03' then
      delete from CZFX_JCGC_YKJH
       where xzqh = '3306010101'
         and year in (substr(riqi, 0, 4), substr(riqi, 0, 4) - 1);
      insert into CZFX_JCGC_YKJH
        select '3306010101' xzqh,
               p.year,
               case when to_number(substr( to_char(p.inputdate,'YYMMDD'),1,4))>p.year then p.year||'1231' when to_number(substr( to_char(p.inputdate,'YYMMDD'),1,4))<p.year then p.year||'0101' else to_char(p.inputdate,'YYMMDD') end inputdate,
               --to_char(p.inputdate,'YYMMDD') inputdate ,
               case when to_number(substr( to_char(p.inputdate,'YYMM'),1,4))>p.year then p.year||'12' when to_number(substr( to_char(p.inputdate,'YYMM'),1,4))<p.year then p.year||'01' else to_char(p.inputdate,'YYMM') end spny,
               p.year || lpad(p.month, 2, '0') ny,
               -------预算单位编码--------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_YSDW') = 1 then
                        (select case when
                  (select case
                            when a1.dwbm is null then
                             '-1'
                            else
                             a1.dwbm
                          end
                     from CZFX_DM_YSDW a1
                    where a1.dwbm = e.isbn_code)
                    is null then '-1' else
                      (select case
                            when a1.dwbm is null then
                             '-1'
                            else
                             a1.dwbm
                          end
                     from CZFX_DM_YSDW a1
                    where a1.dwbm = e.isbn_code)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_YSDW') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_YSDW'
                      and a3.dynf = p.year
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = e.isbn_code)
                      is null then '-1' else
                       (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_YSDW'
                      and a3.dynf = p.year
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = e.isbn_code)
                    end from dual)
                 else
                  '-1'
               end dwbm,
               -------------------------------
              -- '' dwmc, --预留 单位名称e.isbn_code
               e.isbn_code ydwbm,
              -- '' zgdwmc, --预留 主管单位名称ee.name,
              -- '' division, --预留 单位所属归口e.division
              --'' ssgkmc, --预留 单位所属归口名称d.name
               ------------单位性质----------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_DWXZ') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_DWXZ a1
                    where a1.bm = e.enterprisekind)
                    is null then '-1' else
                      (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_DWXZ a1
                    where a1.bm = e.enterprisekind)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_DWXZ') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_DWXZ'
                      and a3.dynf = b.year
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = e.enterprisekind)
                      is null then '-1' else
                       (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_DWXZ'
                      and a3.dynf = b.year
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = e.enterprisekind)
                    end from dual)
                 else
                  '-1'
               end dwxz,
               ----------支付类型-------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_ZFLX') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZFLX a1
                    where a1.bm = e.paytype)
                    is null then '-1' else
                              (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZFLX a1
                    where a1.bm = e.paytype)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_ZFLX') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZFLX'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e.paytype)
                      is null then '-1' else
                       (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZFLX'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e.paytype)
                    end from dual)
                 else
                  '-1'
               end zflx,
               -- '' dwlx, --预留 单位类型e.enterprisetype
               -------收支分类-------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_SZFL') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_SZFL a1
                    where a1.bm = F.SZTYPE)
                    is null then '-1' else
                      (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_SZFL a1
                    where a1.bm = F.SZTYPE)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_SZFL') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_SZFL'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = F.SZTYPE)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_SZFL'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = F.SZTYPE)
                    end from dual)
                 else
                  '-1'
               end szfl,
               -----------功能科目-----------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_GNKM') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_GNKM a1
                    where a1.bm = f.isbn_code)
                    is null then '-1' else
                     (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_GNKM a1
                    where a1.bm = f.isbn_code)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_GNKM') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_GNKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = f.isbn_code)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_GNKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = f.isbn_code)
                    end from dual)
                 else
                  '-1'
               end gnkmbm,
               ----------------------------
               --f.code gnkmbm,
             --  '' gnkmmc, --预留 功能科目名称f.name,
               ---------政府经济科目----------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_ZFJJKM') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZFJJKM a1
                    where a1.bm = e1.isbn_code)
                    is null then '-1' else
                      (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZFJJKM a1
                    where a1.bm = e1.isbn_code)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_ZFJJKM') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZFJJKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e1.isbn_code)
                      is null then '-1' else
                       (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZFJJKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e1.isbn_code)
                    end from dual)
                 else
                  '-1'
               end zfjjkmbm,
               --------------------------------------
               -- e2.code zfjjkmbm,
              -- '' zfjjkmmc, --预留 政府经济科目名称e2.name,
               ----------部门经济科目---------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_BMJJKM') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_BMJJKM a1
                    where a1.bm = e2.isbn_code)
                    is null then '-1' else
                    (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_BMJJKM a1
                    where a1.bm = e2.isbn_code)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_BMJJKM') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_BMJJKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e2.isbn_code)
                      is null then '-1' else
                       (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_BMJJKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e2.isbn_code)
                    end from dual)
                 else
                  '-1'
               end bmjjkmbm,
               --------------------------------
               --e1.code bmjjkmbm,
              -- '' bmjjkmmc, --预留 部门经济科目名称e1.name,

               --------项目类别---------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_XMLB') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_XMLB a1
                    where a1.bm = d.programtypecode)
                    is null then '-1' else
                     (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_XMLB a1
                    where a1.bm = d.programtypecode)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_XMLB') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_XMLB'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = d.programtypecode)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_XMLB'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = d.programtypecode)
                    end from dual)
                 else
                  '-1'
               end xmlb,
               ------------------------------
               --d.programtypecode,
               --'' xmlbmc, --预留 项目类别名称d.programtypename,
               pp.guid,
               case
                 when pp.isbn_code is null then
                  '-1'
                 else
                  pp.isbn_code
               end xmbm,
               pp.name,
               --------资金来源------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_ZJLY_JCGC') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZJLY_JCGC a1
                    where a1.bm = b.resourceincode)
                    is null then '-1' else
                    (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZJLY_JCGC a1
                    where a1.bm = b.resourceincode)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_ZJLY_JCGC') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZJLY_JCGC'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = b.resourceincode)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZJLY_JCGC'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = b.resourceincode)
                    end from dual)
                 else
                  '-1'
               end zjly,
               ---------------------
               b.dwqkwh,
               ------指标所属归口----------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_GKCS') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_GKCS a1
                    where a1.bm = b.divisionguid)
                    is null then '-1' else
                       (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_GKCS a1
                    where a1.bm = b.divisionguid)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_GKCS') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_GKCS'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = b.divisionguid)
                      is null then '-1' else
                         (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_GKCS'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = b.divisionguid)
                    end from dual)
                 else
                  '-1'
               end zbssgk,
               ----------------------------
               --b1.divisionguid,
               b.budgetyear,
               b.budgetcategoryguid,
               -------指标类型--------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_ZBLX') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZBLX a1
                    where a1.bm = b.budgetcategoryguid)
                    is null then '-1' else
                    (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZBLX a1
                    where a1.bm = b.budgetcategoryguid)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_ZBLX') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZBLX'
                      and a3.dynf = b.year
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = b.budgetcategoryguid)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZBLX'
                      and a3.dynf = b.year
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = b.budgetcategoryguid)
                    end from dual)
                 when b.budgetcategoryguid is null then
                  '-1'
                 else
                  '-1'
               end zblxbm,
               ----------------------
               '' zblxmc, --预留 指标类型名称bb.name
               p.budgetid,
               nvl(p.caigou, 0) caigou,
               -------采购目录-------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_CGML') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_CGML a1
                    where a1.bm = e3.buycatalogcode)
                    is null then '-1' else
                     (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_CGML a1
                    where a1.bm = e3.buycatalogcode)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_CGML') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_CGML'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e3.buycatalogcode)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_CGML'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e3.buycatalogcode)
                    end from dual)
                 else
                  '-1'
               end cgml,
               ----------------------
               -- e3.buycatalogcode,
               ----采购类型------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_CGLX') = 1 and e3.caigou = 1 and
                      e3.buytypecode is not null then
                      (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_CGLX a1
                    where a1.bm = e3.buytypecode)
                    is null then '-1' else
                     (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_CGLX a1
                    where a1.bm = e3.buytypecode)
                    end from dual)
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_CGLX') = 1 and e3.caigou = 1 and
                      e3.buytypecode is null then
                  '-1'
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_CGLX') = 2 and e3.caigou = 1 and
                      e3.buytypecode is not null then
                      (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            when (select a.jcgc
                                    from czfx_dm_bmbqd a
                                   where a.bmb = 'CZFX_DM_CGLX') = 2 and
                                 e3.caigou = 1 and e3.buytypecode is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_CGLX'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e3.buytypecode)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            when (select a.jcgc
                                    from czfx_dm_bmbqd a
                                   where a.bmb = 'CZFX_DM_CGLX') = 2 and
                                 e3.caigou = 1 and e3.buytypecode is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_CGLX'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e3.buytypecode)
                    end from dual)
                 else
                  e3.buytypecode
               end cglx,
               -------------------------
               p.planid,
               -----支付方式-----------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_ZFLX') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZFLX a1
                    where a1.bm = '1' || p.paymentstyleguid)
                    is null then '-1' else
                     (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZFLX a1
                    where a1.bm = '1' || p.paymentstyleguid)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_ZFLX') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZFLX'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = '1' || p.paymentstyleguid)
                      is null then '-1' else
                        (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZFLX'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = '1' || p.paymentstyleguid)
                    end from dual)
                 else
                  '-1'
               end zffs,
               ---------------------------
               --p.paymentstyleguid,
               '' dlyhbm,
               p.money,
               sysdate xgrq
        --count(*)
        --zfgl.plan 有的budgetid 在zjsb.budget中 不存在
          from zfgl.plan p
          left join zjsb.budget b
            on p.budgetid = b.budgetid
           and p.year = b.year
           and p.resourcecategoryincode = b.resourceincode
          left join zbgl.enterpriseassignquota e3
            on b.budgetid1 = e3.enterpriseid
          left join zbgl.detailassignquota d
            on e3.itemid = d.itemid
          left join jczl.program pp
            on p.programguid = pp.guid
          left join jczl.economysectiongov e1
            on p.ecogovguid = e1.guid
          left join jczl.budgetcategory bb
            on b.budgetcategoryguid = bb.guid left join jczl.enterprise e
            on e.guid=p.enterpriseguid
          left join jczl.enterprise ee
            on e.parent_guid = ee.guid, jczl.economysection e2,
         jczl.functionsection f
         where  p.economysectionguid = e2.guid
           and p.functionguid = f.guid
           and exists
         (select * from zjsb.budget x where x.year = p.year)
           and p.year in (substr(riqi, 0, 4), substr(riqi, 0, 4) - 1);
    else
      delete from CZFX_JCGC_YKJH
       where xzqh = '3306010101'
         and year = substr(riqi, 0, 4);
      insert into CZFX_JCGC_YKJH
        select '3306010101' xzqh,
               p.year,
               case when to_number(substr( to_char(p.inputdate,'YYMMDD'),1,4))>p.year then p.year||'1231' when to_number(substr( to_char(p.inputdate,'YYMMDD'),1,4))<p.year then p.year||'0101' else to_char(p.inputdate,'YYMMDD') end inputdate,
               --to_char(p.inputdate,'YYMMDD') inputdate,
               case when to_number(substr( to_char(p.inputdate,'YYMM'),1,4))>p.year then p.year||'12' when to_number(substr( to_char(p.inputdate,'YYMM'),1,4))<p.year then p.year||'01' else to_char(p.inputdate,'YYMM') end spny,
               p.year || lpad(p.month, 2, '0') ny,
               -------预算单位编码--------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_YSDW') = 1 then
                        (select case when
                  (select case
                            when a1.dwbm is null then
                             '-1'
                            else
                             a1.dwbm
                          end
                     from CZFX_DM_YSDW a1
                    where a1.dwbm = e.isbn_code)
                    is null then '-1' else
                      (select case
                            when a1.dwbm is null then
                             '-1'
                            else
                             a1.dwbm
                          end
                     from CZFX_DM_YSDW a1
                    where a1.dwbm = e.isbn_code)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_YSDW') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_YSDW'
                      and a3.dynf = p.year
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = e.isbn_code)
                      is null then '-1' else
                       (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_YSDW'
                      and a3.dynf = p.year
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = e.isbn_code)
                    end from dual)
                 else
                  '-1'
               end dwbm,
               -------------------------------
              -- '' dwmc, --预留 单位名称e.isbn_code
               e.isbn_code ydwbm,
               --'' zgdwmc, --预留 主管单位名称ee.name,
               --'' division, --预留 单位所属归口e.division
               --'' ssgkmc, --预留 单位所属归口名称d.name
               ------------单位性质----------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_DWXZ') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_DWXZ a1
                    where a1.bm = e.enterprisekind)
                    is null then '-1' else
                      (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_DWXZ a1
                    where a1.bm = e.enterprisekind)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_DWXZ') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_DWXZ'
                      and a3.dynf = b.year
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = e.enterprisekind)
                      is null then '-1' else
                       (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_DWXZ'
                      and a3.dynf = b.year
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = e.enterprisekind)
                    end from dual)
                 else
                  '-1'
               end dwxz,
               ----------支付类型-------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_ZFLX') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZFLX a1
                    where a1.bm = e.paytype)
                    is null then '-1' else
                              (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZFLX a1
                    where a1.bm = e.paytype)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_ZFLX') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZFLX'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e.paytype)
                      is null then '-1' else
                       (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZFLX'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e.paytype)
                    end from dual)
                 else
                  '-1'
               end zflx,
               -- '' dwlx, --预留 单位类型e.enterprisetype
               -------收支分类-------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_SZFL') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_SZFL a1
                    where a1.bm = F.SZTYPE)
                    is null then '-1' else
                      (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_SZFL a1
                    where a1.bm = F.SZTYPE)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_SZFL') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_SZFL'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = F.SZTYPE)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_SZFL'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = F.SZTYPE)
                    end from dual)
                 else
                  '-1'
               end szfl,
               -----------功能科目-----------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_GNKM') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_GNKM a1
                    where a1.bm = f.isbn_code)
                    is null then '-1' else
                     (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_GNKM a1
                    where a1.bm = f.isbn_code)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_GNKM') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_GNKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = f.isbn_code)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_GNKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = f.isbn_code)
                    end from dual)
                 else
                  '-1'
               end gnkmbm,
               ----------------------------
               --f.code gnkmbm,
               --'' gnkmmc, --预留 功能科目名称f.name,
               ---------政府经济科目----------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_ZFJJKM') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZFJJKM a1
                    where a1.bm = e1.isbn_code)
                    is null then '-1' else
                      (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZFJJKM a1
                    where a1.bm = e1.isbn_code)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_ZFJJKM') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZFJJKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e1.isbn_code)
                      is null then '-1' else
                       (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZFJJKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e1.isbn_code)
                    end from dual)
                 else
                  '-1'
               end zfjjkmbm,
               --------------------------------------
               -- e2.code zfjjkmbm,
              -- '' zfjjkmmc, --预留 政府经济科目名称e2.name,
               ----------部门经济科目---------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_BMJJKM') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_BMJJKM a1
                    where a1.bm = e2.isbn_code)
                    is null then '-1' else
                    (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_BMJJKM a1
                    where a1.bm = e2.isbn_code)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_BMJJKM') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_BMJJKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e2.isbn_code)
                      is null then '-1' else
                       (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_BMJJKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e2.isbn_code)
                    end from dual)
                 else
                  '-1'
               end bmjjkmbm,
               --------------------------------
               --e1.code bmjjkmbm,
               --'' bmjjkmmc, --预留 部门经济科目名称e1.name,

               --------项目类别---------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_XMLB') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_XMLB a1
                    where a1.bm = d.programtypecode)
                    is null then '-1' else
                     (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_XMLB a1
                    where a1.bm = d.programtypecode)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_XMLB') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_XMLB'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = d.programtypecode)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_XMLB'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = d.programtypecode)
                    end from dual)
                 else
                  '-1'
               end xmlb,
               ------------------------------
               --d.programtypecode,
               --'' xmlbmc, --预留 项目类别名称d.programtypename,
               pp.guid,
               case
                 when pp.isbn_code is null then
                  '-1'
                 else
                  pp.isbn_code
               end xmbm,
               pp.name,
               --------资金来源------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_ZJLY_JCGC') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZJLY_JCGC a1
                    where a1.bm = b.resourceincode)
                    is null then '-1' else
                    (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZJLY_JCGC a1
                    where a1.bm = b.resourceincode)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_ZJLY_JCGC') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZJLY_JCGC'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = b.resourceincode)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZJLY_JCGC'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = b.resourceincode)
                    end from dual)
                 else
                  '-1'
               end zjly,
               ---------------------
               b.dwqkwh,
               ------指标所属归口----------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_GKCS') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_GKCS a1
                    where a1.bm = b.divisionguid)
                    is null then '-1' else
                       (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_GKCS a1
                    where a1.bm = b.divisionguid)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_GKCS') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_GKCS'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = b.divisionguid)
                      is null then '-1' else
                         (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_GKCS'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = b.divisionguid)
                    end from dual)
                 else
                  '-1'
               end zbssgk,
               ----------------------------
               --b1.divisionguid,
               b.budgetyear,
               b.budgetcategoryguid,
               -------指标类型--------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_ZBLX') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZBLX a1
                    where a1.bm = b.budgetcategoryguid)
                    is null then '-1' else
                    (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZBLX a1
                    where a1.bm = b.budgetcategoryguid)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_ZBLX') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZBLX'
                      and a3.dynf = b.year
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = b.budgetcategoryguid)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZBLX'
                      and a3.dynf = b.year
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = b.budgetcategoryguid)
                    end from dual)
                 when b.budgetcategoryguid is null then
                  '-1'
                 else
                  '-1'
               end zblxbm,
               ----------------------
               '' zblxmc, --预留 指标类型名称bb.name
               p.budgetid,
               nvl(p.caigou, 0) caigou,
               -------采购目录-------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_CGML') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_CGML a1
                    where a1.bm = e3.buycatalogcode)
                    is null then '-1' else
                     (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_CGML a1
                    where a1.bm = e3.buycatalogcode)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_CGML') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_CGML'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e3.buycatalogcode)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_CGML'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e3.buycatalogcode)
                    end from dual)
                 else
                  '-1'
               end cgml,
               ----------------------
               -- e3.buycatalogcode,
               ----采购类型------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_CGLX') = 1 and e3.caigou = 1 and
                      e3.buytypecode is not null then
                      (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_CGLX a1
                    where a1.bm = e3.buytypecode)
                    is null then '-1' else
                     (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_CGLX a1
                    where a1.bm = e3.buytypecode)
                    end from dual)
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_CGLX') = 1 and e3.caigou = 1 and
                      e3.buytypecode is null then
                  '-1'
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_CGLX') = 2 and e3.caigou = 1 and
                      e3.buytypecode is not null then
                      (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            when (select a.jcgc
                                    from czfx_dm_bmbqd a
                                   where a.bmb = 'CZFX_DM_CGLX') = 2 and
                                 e3.caigou = 1 and e3.buytypecode is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_CGLX'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e3.buytypecode)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            when (select a.jcgc
                                    from czfx_dm_bmbqd a
                                   where a.bmb = 'CZFX_DM_CGLX') = 2 and
                                 e3.caigou = 1 and e3.buytypecode is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_CGLX'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e3.buytypecode)
                    end from dual)
                 else
                  e3.buytypecode
               end cglx,
               -------------------------
               p.planid,
               -----支付方式-----------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_ZFLX') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZFLX a1
                    where a1.bm = '1' || p.paymentstyleguid)
                    is null then '-1' else
                     (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZFLX a1
                    where a1.bm = '1' || p.paymentstyleguid)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_ZFLX') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZFLX'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = '1' || p.paymentstyleguid)
                      is null then '-1' else
                        (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZFLX'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = '1' || p.paymentstyleguid)
                    end from dual)
                 else
                  '-1'
               end zffs,
               ---------------------------
               --p.paymentstyleguid,
               '' dlyhbm,
               p.money,
               sysdate xgrq
        --count(*)
        --zfgl.plan 有的budgetid 在zjsb.budget中 不存在
          from zfgl.plan p
          left join zjsb.budget b
            on p.budgetid = b.budgetid
           and p.year = b.year
           and p.resourcecategoryincode = b.resourceincode
          left join zbgl.enterpriseassignquota e3
            on b.budgetid1 = e3.enterpriseid
          left join zbgl.detailassignquota d
            on e3.itemid = d.itemid
          left join jczl.program pp
            on p.programguid = pp.guid
          left join jczl.economysectiongov e1
            on p.ecogovguid = e1.guid
          left join jczl.budgetcategory bb
            on b.budgetcategoryguid = bb.guid left join jczl.enterprise e
            on e.guid=p.enterpriseguid
          left join jczl.enterprise ee
            on e.parent_guid = ee.guid, jczl.economysection e2,
         jczl.functionsection f
         where  p.economysectionguid = e2.guid
           and p.functionguid = f.guid
           and exists
         (select * from zjsb.budget x where x.year = p.year)
           and p.year = substr(riqi, 0, 4);
    end if;
    commit;

  end;
 ------------------金财工程_支付明细---------------------------
  procedure GET_CZFX_JCGC_ZFMX(riqi varchar2) is

  begin
    /*日期如果在每年的1月1日至1月3日之间，则先删除当年及上年的支付明细，再重新插入*/
    if substr(riqi, 5, 2) = '01' and substr(riqi, 7, 2) >= '01' and
       substr(riqi, 7, 2) <= '03' then
      delete from CZFX_JCGC_ZFMX
       where xzqh = '3306010101'
         and year in (substr(riqi, 0, 4), substr(riqi, 0, 4) - 1);
      insert into CZFX_JCGC_ZFMX
        select '3306010101' xzqh,
               p.year,
               b1.year || lpad(b1.month, 2, '0') || lpad(day, 2, '0') czrq,
               substr（p1.reportdate,0,6) qsny,
               p1.reportdate,
               -----------预算单位-----------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_YSDW') = 1 then
                        (select case when
                  (select case
                            when a1.dwbm is null then
                             '-1'
                            else
                             a1.dwbm
                          end
                     from CZFX_DM_YSDW a1
                    where a1.dwbm = e.isbn_code)
                   is null then '-1' else
                    (select case
                            when a1.dwbm is null then
                             '-1'
                            else
                             a1.dwbm
                          end
                     from CZFX_DM_YSDW a1
                    where a1.dwbm = e.isbn_code)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_YSDW') = 2 then
                  (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_YSDW'
                      and a3.dynf = p.year
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = e.isbn_code)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_YSDW'
                      and a3.dynf = p.year
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = e.isbn_code)
                    end from dual)
                 else
                  '-1'
               end dwbm,
               ------------------------------
              -- '' dwmc, --预留 单位名称e.isbn_code
               e.isbn_code ydwbm, --主管单位编码
               --'' zgdwmc, --预留 主管单位名称ee.name,
               --'' division, --预留 单位所属归口e.division
               --'' ssgkmc, --预留 单位所属归口名称d.name
               ------------单位性质----------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_DWXZ') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_DWXZ a1
                    where a1.bm = e.enterprisekind)
                    is null then '-1' else
                     (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_DWXZ a1
                    where a1.bm = e.enterprisekind)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_DWXZ') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_DWXZ'
                      and a3.dynf = p.year
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = e.enterprisekind)
                      is null then '-1' else
                       (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_DWXZ'
                      and a3.dynf = p.year
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = e.enterprisekind)
                      end from dual)
                 else
                  '-1'
               end dwxz,
               ------------支付方式----------
                 case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_ZFLX') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZFLX a1
                    where a1.bm = e.paytype)
                    is null then '-1' else
                     (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZFLX a1
                    where a1.bm = e.paytype)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_ZFLX') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZFLX'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e.paytype)
                      is null then '-1' else
                        (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZFLX'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e.paytype)
                      end from dual)
                 else
                  '-1'
               end zflx,
                      -------收支分类-------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_SZFL') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_SZFL a1
                    where a1.bm = F.SZTYPE)
                    is null then '-1' else
                      (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_SZFL a1
                    where a1.bm = F.SZTYPE)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_SZFL') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_SZFL'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = F.SZTYPE)
                      is null then '-1' else
                        (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_SZFL'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = F.SZTYPE)
                      end from dual)
                 else
                  '-1'
               end szfl,
               -----------功能科目-----------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_GNKM') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_GNKM a1
                    where a1.bm = f.isbn_code)
                    is null then '-1' else
                     (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_GNKM a1
                    where a1.bm = f.isbn_code)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_GNKM') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_GNKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = f.isbn_code)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_GNKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = f.isbn_code)
                      end from dual)
                 else
                  '-1'
               end gnkmbm,
               ----------------------------
               --f.code gnkmbm,
             --  '' gnkmmc, --预留 功能科目名称f.name,
              ---------政府经济科目----------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_ZFJJKM') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZFJJKM a1
                    where a1.bm = e1.isbn_code)
                    is null then '-1' else
                    (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZFJJKM a1
                    where a1.bm = e1.isbn_code)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_ZFJJKM') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZFJJKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e1.isbn_code)
                      is null then '-1' else
                       (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZFJJKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e1.isbn_code)
                      end from dual)
                 else
                  '-1'
               end zfjjkmbm,
               --------------------------------------
               -- e2.code zfjjkmbm,
              -- '' zfjjkmmc, --预留 政府经济科目名称e2.name,
               ----------部门经济科目---------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_BMJJKM') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_BMJJKM a1
                    where a1.bm = e2.isbn_code)
                    is null then '-1' else
                     (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_BMJJKM a1
                    where a1.bm = e2.isbn_code)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_BMJJKM') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_BMJJKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e2.isbn_code)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_BMJJKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e2.isbn_code)
                      end from dual)
                 else
                  '-1'
               end bmjjkmbm,
               --------------------------------
               --e1.code bmjjkmbm,
               --'' bmjjkmmc, --预留 部门经济科目名称e1.name,
               --------项目类别---------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_XMLB') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_XMLB a1
                    where a1.bm = d.programtypecode)
                    is null then '-1' else
                           (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_XMLB a1
                    where a1.bm = d.programtypecode)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_XMLB') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_XMLB'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = d.programtypecode)
                      is null then '-1' else
                       (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_XMLB'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = d.programtypecode)
                      end from dual)
                 else
                  '-1'
               end xmlb,
               ------------------------------
               --d.programtypecode,
              -- '' xmlbmc, --预留 项目类别名称d.programtypename,
               pp.guid xmid,
               case
                 when pp.isbn_code is null then
                  pp.name
                 else
                  pp.isbn_code
               end xmbm,
               pp.name xmmc,
               --------资金来源-------
                              case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_ZJLY_JCGC') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZJLY_JCGC a1
                    where a1.bm = p1.tzbm)
                    is null then '-1' else
                    (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZJLY_JCGC a1
                    where a1.bm = p1.tzbm)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_ZJLY_JCGC') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZJLY_JCGC'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = p1.tzbm)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZJLY_JCGC'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = p1.tzbm)
                      end from dual)
                 else
                  '-1'
               end zjly,
               bb.dwqkwh,
                ------指标所属归口----------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_GKCS') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_GKCS a1
                    where a1.bm = bb.divisionguid)
                    is null then '-1' else
                    (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_GKCS a1
                    where a1.bm = bb.divisionguid)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_GKCS') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_GKCS'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = bb.divisionguid)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_GKCS'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = bb.divisionguid)
                      end from dual)
                 else
                  '-1'
               end zbssgk,
               bb.budgetyear,
               bbb.guid,
               -------指标类型--------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_ZBLX') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZBLX a1
                    where a1.bm = bbb.guid)
                    is null then '-1' else
                      (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZBLX a1
                    where a1.bm = bbb.guid)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_ZBLX') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZBLX'
                      and a3.dynf = b1.year
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = bbb.guid)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZBLX'
                      and a3.dynf = p.year
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = bbb.guid)
                      end from dual)
                 else
                  '-1'
               end zblxbm,
               ----------------------
               '' zblxmc, --预留 指标类型名称bb.name
               b.gplanid,
               --bb.budgetid,
               nvl(e3.caigou, 0) sfcg,
                -------采购目录-------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_CGML') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_CGML a1
                    where a1.bm = e3.buycatalogcode)
                    is null then '-1' else
                    (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_CGML a1
                    where a1.bm = e3.buycatalogcode)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_CGML') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_CGML'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e3.buycatalogcode)
                      is null then '-1' else
                       (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_CGML'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e3.buycatalogcode)
                      end from dual)
                 else
                  '-1'
               end cgml,
               ----------------------
               -- e3.buycatalogcode,
               ----采购类型------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_CGLX') = 1 and e3.caigou = 1 and
                      e3.buytypecode is not null then
                      (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_CGLX a1
                    where a1.bm = e3.buytypecode)
                    is null then '-1' else
                     (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_CGLX a1
                    where a1.bm = e3.buytypecode)
                    end from dual)
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_CGLX') = 1 and e3.caigou = 1 and
                      e3.buytypecode is null then
                  '-1'
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_CGLX') = 2 and e3.caigou = 1 and
                      e3.buytypecode is not null then
                      (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            when (select a.jcgc
                                    from czfx_dm_bmbqd a
                                   where a.bmb = 'CZFX_DM_CGLX') = 2 and
                                 e3.caigou = 1 and e3.buytypecode is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_CGLX'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e3.buytypecode)
                      is null then '-1' else
                       (select case
                            when a3.bm is null then
                             '-1'
                            when (select a.jcgc
                                    from czfx_dm_bmbqd a
                                   where a.bmb = 'CZFX_DM_CGLX') = 2 and
                                 e3.caigou = 1 and e3.buytypecode is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_CGLX'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e3.buytypecode)
                    end from dual)
                 else
                  e3.buytypecode
               end cglx,
               -------------------------
                case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_ZFLX') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZFLX a1
                    where a1.bm = '1' ||  b.paymode)
                    is null then '-1' else
                     (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZFLX a1
                    where a1.bm = '1' ||  b.paymode)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_ZFLX') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZFLX'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = '1' ||  b.paymode)
                      is null then '-1' else
                        (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZFLX'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = '1' ||  b.paymode)
                    end from dual)
                 else
                  '-1'
               end zffs,
               b.billno,
               b.line,
               -------结算方式------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_JSFS') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_JSFS a1
                    where a1.bm = b1.settletype )
                    is null then '-1' else
                    (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_JSFS a1
                    where a1.bm = b1.settletype )
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_JSFS') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_JSFS'
                      and a3.dynf = p.year
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = b1.settletype )
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_JSFS'
                      and a3.dynf = p.year
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = b1.settletype )
                    end from dual)
                 else
                  '-1'
               end jsfs,
              ----------------------------
               b1.recname,
               b1.recbankno,
               b1.recbankname,
               b1.purpose,
               ---------代理银行--------
               case
                      when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_DLYH') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_DLYH a1
                    where a1.bm = b1.paybankcode )
                    is null then '-1' else
                    (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_DLYH a1
                    where a1.bm = b1.paybankcode )
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_DLYH') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_DLYH'
                      and a3.dynf = p.year
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = b1.paybankcode )
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_DLYH'
                      and a3.dynf = p.year
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = b1.paybankcode )
                    end from dual)
                 else
                  '-1'
               end paybankcode,
               --------------------------
               b.totalmoney,
               sysdate xgsj,
               '0'
        --count(*), sum(p.totalmoney)
          from zfgl.billsdetail b
            left join jczl.enterprise e
            on b.enterpriseguid=e.guid
            and b.year=e.year
            inner join (select distinct year,exchangecode,newbillno,reportid,bankcode from zfgl.payreportdetail) p
            on  p.year = b.year
           and e.isbn_code = p.exchangecode
           and p.newbillno = b.billno
           inner join zfgl.payreport p1
            on p.reportid = p1.reportid
           and p.bankcode = p1.bankcode
            and p.year = p1.year
            and p1.tzbm=b.tzbm
           left join zfgl.bills b1
            on b.year = b1.year
           and b.enterpriseguid = b1.enterpriseguid
           and b.billno = b1.billno
            left join jczl.economysectiongov e1
            on b.govecoguid = e1.guid
          left join zjsb.budget bb
            on b.gplanid = bb.budgetid
           and b.tzbm = bb.resourceincode
          left join zbgl.enterpriseassignquota e3
            on bb.budgetid1 = e3.enterpriseid
           and bb.year = e3.year
          left join zbgl.detailassignquota d
            on e3.itemid = d.itemid
          left join jczl.budgetcategory bbb
            on bb.budgetcategoryguid = bbb.guid
            left join jczl.enterprise ee
            on e.parent_guid = ee.guid
            left join jczl.functionsection f
            on p.year = f.year and trim(b.functionguid) = f.guid
            left join jczl.economysection e2
            on b.economyguid = e2.guid
            left join jczl.program pp
            on b.programguid = pp.guid
         where
            p.year in (substr(riqi, 0, 4), substr(riqi, 0, 4) - 1)
        ----------
        union all
        select '3306010101' xzqh,
               g.year,
               replace(g1.reportdate, '.', '') czrq,
               substr（replace(g1.pfdate, '.', ''),0,6) qsny,
               replace(g1.pfdate, '.', '') qsrq,
                -----------预算单位-----------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_YSDW') = 1 then
                        (select case when
                  (select case
                            when a1.dwbm is null then
                             '-1'
                            else
                             a1.dwbm
                          end
                     from CZFX_DM_YSDW a1
                    where a1.dwbm = e.isbn_code)
                   is null then '-1' else
                    (select case
                            when a1.dwbm is null then
                             '-1'
                            else
                             a1.dwbm
                          end
                     from CZFX_DM_YSDW a1
                    where a1.dwbm = e.isbn_code)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_YSDW') = 2 then
                  (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_YSDW'
                      and a3.dynf = g.year
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = e.isbn_code)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_YSDW'
                      and a3.dynf = g.year
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = e.isbn_code)
                    end from dual)
                 else
                  '-1'
               end dwbm,
               ------------------------------
               --'' dwmc, --预留 单位名称e.isbn_code
               e.isaccount ydwbm, --预留 主管单位名称ee.isbn_code,
              -- '' zgdwmc, --预留 主管单位名称ee.name,
              --'' division, --预留 单位所属归口e.division
              --'' ssgkmc, --预留 单位所属归口名称d.name
              case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_DWXZ') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_DWXZ a1
                    where a1.bm = e.enterprisekind)
                    is null then '-1' else
                     (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_DWXZ a1
                    where a1.bm = e.enterprisekind)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_DWXZ') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_DWXZ'
                      and a3.dynf = g.year
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = e.enterprisekind)
                      is null then '-1' else
                       (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_DWXZ'
                      and a3.dynf = g.year
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = e.enterprisekind)
                      end from dual)
                 else
                  '-1'
               end dwxz,
               ------------支付方式----------
                  case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_ZFLX') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZFLX a1
                    where a1.bm = e.paytype)
                    is null then '-1' else
                     (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZFLX a1
                    where a1.bm = e.paytype)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_ZFLX') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZFLX'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e.paytype)
                      is null then '-1' else
                        (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZFLX'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e.paytype)
                      end from dual)
                 else
                  '-1'
               end zflx,
               -------收支分类-------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_SZFL') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_SZFL a1
                    where a1.bm = F.SZTYPE)
                    is null then '-1' else
                      (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_SZFL a1
                    where a1.bm = F.SZTYPE)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_SZFL') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_SZFL'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = F.SZTYPE)
                      is null then '-1' else
                        (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_SZFL'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = F.SZTYPE)
                      end from dual)
                 else
                  '-1'
               end szfl,
               -----------功能科目-----------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_GNKM') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_GNKM a1
                    where a1.bm = f.isbn_code)
                    is null then '-1' else
                     (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_GNKM a1
                    where a1.bm = f.isbn_code)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_GNKM') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_GNKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = f.isbn_code)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_GNKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = f.isbn_code)
                      end from dual)
                 else
                  '-1'
               end gnkmbm,
               ----------------------------
               --f.code gnkmbm,
              -- '' gnkmmc, --预留 功能科目名称f.name,
               ---------政府经济科目----------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_ZFJJKM') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZFJJKM a1
                    where a1.bm = e1.isbn_code)
                    is null then '-1' else
                    (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZFJJKM a1
                    where a1.bm = e1.isbn_code)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_ZFJJKM') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZFJJKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e1.isbn_code)
                      is null then '-1' else
                       (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZFJJKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e1.isbn_code)
                      end from dual)
                 else
                  '-1'
               end zfjjkmbm,
               --------------------------------------
               -- e2.code zfjjkmbm,
               --'' zfjjkmmc, --预留 政府经济科目名称e2.name,
               ----------部门经济科目---------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_BMJJKM') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_BMJJKM a1
                    where a1.bm = e2.isbn_code)
                    is null then '-1' else
                     (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_BMJJKM a1
                    where a1.bm = e2.isbn_code)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_BMJJKM') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_BMJJKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e2.isbn_code)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_BMJJKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e2.isbn_code)
                      end from dual)
                 else
                  '-1'
               end bmjjkmbm,
               --------------------------------
               --e1.code bmjjkmbm,
               --'' bmjjkmmc, --预留 部门经济科目名称e1.name,
              --------项目类别---------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_XMLB') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_XMLB a1
                    where a1.bm = d.programtypecode)
                    is null then '-1' else
                           (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_XMLB a1
                    where a1.bm = d.programtypecode)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_XMLB') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_XMLB'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = d.programtypecode)
                      is null then '-1' else
                       (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_XMLB'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = d.programtypecode)
                      end from dual)
                 else
                  '-1'
               end xmlb,
               ------------------------------
               --d.programtypecode,
              -- '' xmlbmc, --预留 项目类别名称d.programtypename,
               pp.guid xmid,
               case
                 when pp.isbn_code is null then
                  pp.name
                 else
                  pp.isbn_code
               end xmbm,
               pp.name xmmc,
               --------资金来源-------
                              case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_ZJLY_JCGC') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZJLY_JCGC a1
                    where a1.bm = bb.resourceincode)
                    is null then '-1' else
                    (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZJLY_JCGC a1
                    where a1.bm = bb.resourceincode)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_ZJLY_JCGC') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZJLY_JCGC'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = bb.resourceincode)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZJLY_JCGC'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = bb.resourceincode)
                      end from dual)
                 else
                  '-1'
               end zjly,
               --------------------
               bb.dwqkwh,
 case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_GKCS') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_GKCS a1
                    where a1.bm = bb.divisionguid)
                    is null then '-1' else
                    (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_GKCS a1
                    where a1.bm = bb.divisionguid)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_GKCS') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_GKCS'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = bb.divisionguid)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_GKCS'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = bb.divisionguid)
                      end from dual)
                 else
                  '-1'
               end zbssgk,
               bb.budgetyear,
                  bbb.guid,
               -------指标类型--------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_ZBLX') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZBLX a1
                    where a1.bm = bbb.guid)
                    is null then '-1' else
                      (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZBLX a1
                    where a1.bm = bbb.guid)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_ZBLX') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZBLX'
                      and a3.dynf = g.year
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = bbb.guid)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZBLX'
                      and a3.dynf = g.year
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = bbb.guid)
                      end from dual)
                 else
                  '-1'
               end zblxbm,
               ----------------------
               '' zblxmc, --预留 指标类型名称bb.name
               g.budgetid,
               --bb.budgetid,
               nvl(e3.caigou, 0) sfcg,
              -------采购目录-------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_CGML') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_CGML a1
                    where a1.bm = e3.buycatalogcode)
                    is null then '-1' else
                    (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_CGML a1
                    where a1.bm = e3.buycatalogcode)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_CGML') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_CGML'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e3.buycatalogcode)
                      is null then '-1' else
                       (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_CGML'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e3.buycatalogcode)
                      end from dual)
                 else
                  '-1'
               end cgml,
----------------------
               -- e3.buycatalogcode,
               ----采购类型------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_CGLX') = 1 and e3.caigou = 1 and
                      e3.buytypecode is not null then
                      (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_CGLX a1
                    where a1.bm = e3.buytypecode)
                    is null then '-1' else
                     (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_CGLX a1
                    where a1.bm = e3.buytypecode)
                    end from dual)
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_CGLX') = 1 and e3.caigou = 1 and
                      e3.buytypecode is null then
                  '-1'
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_CGLX') = 2 and e3.caigou = 1 and
                      e3.buytypecode is not null then
                      (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            when (select a.jcgc
                                    from czfx_dm_bmbqd a
                                   where a.bmb = 'CZFX_DM_CGLX') = 2 and
                                 e3.caigou = 1 and e3.buytypecode is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_CGLX'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e3.buytypecode)
                      is null then '-1' else
                       (select case
                            when a3.bm is null then
                             '-1'
                            when (select a.jcgc
                                    from czfx_dm_bmbqd a
                                   where a.bmb = 'CZFX_DM_CGLX') = 2 and
                                 e3.caigou = 1 and e3.buytypecode is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_CGLX'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e3.buytypecode)
                    end from dual)
                 else
                  e3.buytypecode
               end cglx,
               -------------------------
               '0' paymode, --99表示申拨支出
               g.gplanid,
               g.id,
               '99' jsfs, --99表示申拨支出
               g.acceptname,
               g.acceptaccount,
               g.acceptbank,
               g.remark,
               '9999', --付款单位银行
               g.sanctionmoney,
               sysdate xgsj,
               '1'
        --count(*), sum(p.totalmoney)
          from zjsb.gplandetail g
          left join zjsb.gplan g1
            on g.year = g1.year
           and g.gplanid = g1.gplanid
          left join jczl.enterprise e
            on g.year = e.year
           and g.enterpriseguid = e.guid
          left join jczl.enterprise ee
            on e.parent_guid = ee.guid
          left join jczl.functionsection f
            on g.functionguid = f.guid
          left join jczl.economysectiongov e1
            on g.zfecosecguid = e1.guid
          left join jczl.economysection e2
            on g.ecosecguid = e2.guid
          left join zjsb.budget bb
            on g.budgetid = bb.budgetid
           and g.resourceincode = bb.resourceincode
          left join zbgl.enterpriseassignquota e3
            on bb.budgetid1 = e3.enterpriseid
          left join zbgl.detailassignquota d
            on e3.itemid = d.itemid
          left join jczl.program pp
            on g.programguid = pp.guid
          left join jczl.budgetcategory bbb
            on bb.budgetcategoryguid = bbb.guid
         where g1.signed = 1
           and g1.lsname <> -1
           and g1.allostate is not null
           and g.budgetid is not null
           and g.year in (substr(riqi, 0, 4), substr(riqi, 0, 4) - 1);
    else
      delete from CZFX_JCGC_ZFMX
       where xzqh = '3306010101'
         and year = substr(riqi, 0, 4);
      insert into CZFX_JCGC_ZFMX
        select '3306010101' xzqh,
               p.year,
               b1.year || lpad(b1.month, 2, '0') || lpad(day, 2, '0') czrq,
               substr(p1.reportdate,0,6) pfny,
               p1.reportdate,
               -----------预算单位-----------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_YSDW') = 1 then
                        (select case when
                  (select case
                            when a1.dwbm is null then
                             '-1'
                            else
                             a1.dwbm
                          end
                     from CZFX_DM_YSDW a1
                    where a1.dwbm = e.isbn_code)
                   is null then '-1' else
                    (select case
                            when a1.dwbm is null then
                             '-1'
                            else
                             a1.dwbm
                          end
                     from CZFX_DM_YSDW a1
                    where a1.dwbm = e.isbn_code)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_YSDW') = 2 then
                  (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_YSDW'
                      and a3.dynf = p.year
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = e.isbn_code)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_YSDW'
                      and a3.dynf = p.year
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = e.isbn_code)
                    end from dual)
                 else
                  '-1'
               end dwbm,
               ------------------------------
               --'' dwmc, --预留 单位名称e.isbn_code
               e.isbn_code ydwbm, --原单位编码
               --'' zgdwmc, --预留 主管单位名称ee.name,
               --'' division, --预留 单位所属归口e.division
               --'' ssgkmc, --预留 单位所属归口名称d.name
               ------------单位性质----------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_DWXZ') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_DWXZ a1
                    where a1.bm = e.enterprisekind)
                    is null then '-1' else
                     (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_DWXZ a1
                    where a1.bm = e.enterprisekind)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_DWXZ') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_DWXZ'
                      and a3.dynf = p.year
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = e.enterprisekind)
                      is null then '-1' else
                       (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_DWXZ'
                      and a3.dynf = p.year
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = e.enterprisekind)
                      end from dual)
                 else
                  '-1'
               end dwxz,
               ------------支付方式----------
                 case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_ZFLX') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZFLX a1
                    where a1.bm = e.paytype)
                    is null then '-1' else
                     (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZFLX a1
                    where a1.bm = e.paytype)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_ZFLX') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZFLX'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e.paytype)
                      is null then '-1' else
                        (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZFLX'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e.paytype)
                      end from dual)
                 else
                  '-1'
               end zflx,
                      -------收支分类-------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_SZFL') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_SZFL a1
                    where a1.bm = F.SZTYPE)
                    is null then '-1' else
                      (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_SZFL a1
                    where a1.bm = F.SZTYPE)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_SZFL') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_SZFL'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = F.SZTYPE)
                      is null then '-1' else
                        (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_SZFL'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = F.SZTYPE)
                      end from dual)
                 else
                  '-1'
               end szfl,
               -----------功能科目-----------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_GNKM') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_GNKM a1
                    where a1.bm = f.isbn_code)
                    is null then '-1' else
                     (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_GNKM a1
                    where a1.bm = f.isbn_code)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_GNKM') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_GNKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = f.isbn_code)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_GNKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = f.isbn_code)
                      end from dual)
                 else
                  '-1'
               end gnkmbm,
               ----------------------------
               --f.code gnkmbm,
              -- '' gnkmmc, --预留 功能科目名称f.name,
              ---------政府经济科目----------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_ZFJJKM') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZFJJKM a1
                    where a1.bm = e1.isbn_code)
                    is null then '-1' else
                    (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZFJJKM a1
                    where a1.bm = e1.isbn_code)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_ZFJJKM') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZFJJKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e1.isbn_code)
                      is null then '-1' else
                       (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZFJJKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e1.isbn_code)
                      end from dual)
                 else
                  '-1'
               end zfjjkmbm,
               --------------------------------------
               -- e2.code zfjjkmbm,
              -- '' zfjjkmmc, --预留 政府经济科目名称e2.name,
               ----------部门经济科目---------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_BMJJKM') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_BMJJKM a1
                    where a1.bm = e2.isbn_code)
                    is null then '-1' else
                     (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_BMJJKM a1
                    where a1.bm = e2.isbn_code)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_BMJJKM') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_BMJJKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e2.isbn_code)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_BMJJKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e2.isbn_code)
                      end from dual)
                 else
                  '-1'
               end bmjjkmbm,
               --------------------------------
               --e1.code bmjjkmbm,
              -- '' bmjjkmmc, --预留 部门经济科目名称e1.name,
               --------项目类别---------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_XMLB') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_XMLB a1
                    where a1.bm = d.programtypecode)
                    is null then '-1' else
                           (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_XMLB a1
                    where a1.bm = d.programtypecode)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_XMLB') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_XMLB'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = d.programtypecode)
                      is null then '-1' else
                       (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_XMLB'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = d.programtypecode)
                      end from dual)
                 else
                  '-1'
               end xmlb,
               ------------------------------
               --d.programtypecode,
              -- '' xmlbmc, --预留 项目类别名称d.programtypename,
               pp.guid xmid,
               case
                 when pp.isbn_code is null then
                  pp.name
                 else
                  pp.isbn_code
               end xmbm,
               pp.name xmmc,
               --------资金来源-------
                              case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_ZJLY_JCGC') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZJLY_JCGC a1
                    where a1.bm = p1.tzbm)
                    is null then '-1' else
                    (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZJLY_JCGC a1
                    where a1.bm = p1.tzbm)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_ZJLY_JCGC') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZJLY_JCGC'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = p1.tzbm)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZJLY_JCGC'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = p1.tzbm)
                      end from dual)
                 else
                  '-1'
               end zjly,
               bb.dwqkwh,
                ------指标所属归口----------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_GKCS') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_GKCS a1
                    where a1.bm = bb.divisionguid)
                    is null then '-1' else
                    (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_GKCS a1
                    where a1.bm = bb.divisionguid)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_GKCS') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_GKCS'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = bb.divisionguid)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_GKCS'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = bb.divisionguid)
                      end from dual)
                 else
                  '-1'
               end zbssgk,
               bb.budgetyear,
               bbb.guid,
               -------指标类型--------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_ZBLX') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZBLX a1
                    where a1.bm = bbb.guid)
                    is null then '-1' else
                      (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZBLX a1
                    where a1.bm = bbb.guid)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_ZBLX') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZBLX'
                      and a3.dynf = b1.year
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = bbb.guid)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZBLX'
                      and a3.dynf = p.year
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = bbb.guid)
                      end from dual)
                 else
                  '-1'
               end zblxbm,
               ----------------------
               '' zblxmc, --预留 指标类型名称bb.name
               b.gplanid,
               --bb.budgetid,
               nvl(e3.caigou, 0) sfcg,
                -------采购目录-------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_CGML') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_CGML a1
                    where a1.bm = e3.buycatalogcode)
                    is null then '-1' else
                    (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_CGML a1
                    where a1.bm = e3.buycatalogcode)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_CGML') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_CGML'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e3.buycatalogcode)
                      is null then '-1' else
                       (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_CGML'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e3.buycatalogcode)
                      end from dual)
                 else
                  '-1'
               end cgml,
               ----------------------
               -- e3.buycatalogcode,
               ----采购类型------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_CGLX') = 1 and e3.caigou = 1 and
                      e3.buytypecode is not null then
                      (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_CGLX a1
                    where a1.bm = e3.buytypecode)
                    is null then '-1' else
                     (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_CGLX a1
                    where a1.bm = e3.buytypecode)
                    end from dual)
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_CGLX') = 1 and e3.caigou = 1 and
                      e3.buytypecode is null then
                  '-1'
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_CGLX') = 2 and e3.caigou = 1 and
                      e3.buytypecode is not null then
                      (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            when (select a.jcgc
                                    from czfx_dm_bmbqd a
                                   where a.bmb = 'CZFX_DM_CGLX') = 2 and
                                 e3.caigou = 1 and e3.buytypecode is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_CGLX'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e3.buytypecode)
                      is null then '-1' else
                       (select case
                            when a3.bm is null then
                             '-1'
                            when (select a.jcgc
                                    from czfx_dm_bmbqd a
                                   where a.bmb = 'CZFX_DM_CGLX') = 2 and
                                 e3.caigou = 1 and e3.buytypecode is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_CGLX'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e3.buytypecode)
                    end from dual)
                 else
                  e3.buytypecode
               end cglx,
               -------------------------
                case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_ZFLX') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZFLX a1
                    where a1.bm = '1' ||  b.paymode)
                    is null then '-1' else
                     (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZFLX a1
                    where a1.bm = '1' ||  b.paymode)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_ZFLX') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZFLX'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = '1' ||  b.paymode)
                      is null then '-1' else
                        (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZFLX'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = '1' ||  b.paymode)
                    end from dual)
                 else
                  '-1'
               end zffs,
               b.billno,
               b.line,
               -------结算方式------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_JSFS') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_JSFS a1
                    where a1.bm = b1.settletype )
                    is null then '-1' else
                    (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_JSFS a1
                    where a1.bm = b1.settletype )
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_JSFS') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_JSFS'
                      and a3.dynf = p.year
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = b1.settletype )
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_JSFS'
                      and a3.dynf = p.year
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = b1.settletype )
                    end from dual)
                 else
                  '-1'
               end jsfs,
              ----------------------------
               b1.recname,
               b1.recbankno,
               b1.recbankname,
               b1.purpose,
               ---------代理银行--------
               case
                      when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_DLYH') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_DLYH a1
                    where a1.bm = b1.paybankcode )
                    is null then '-1' else
                    (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_DLYH a1
                    where a1.bm = b1.paybankcode )
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_DLYH') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_DLYH'
                      and a3.dynf = p.year
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = b1.paybankcode )
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_DLYH'
                      and a3.dynf = p.year
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = b1.paybankcode )
                    end from dual)
                 else
                  '-1'
               end paybankcode,
               --------------------------
               b.totalmoney,
               sysdate xgsj,
               '0'
        --count(*), sum(p.totalmoney)
          from zfgl.billsdetail b
            left join jczl.enterprise e
            on b.enterpriseguid=e.guid
            and b.year=e.year
            inner join (select distinct year,exchangecode,newbillno,reportid,bankcode from zfgl.payreportdetail ) p
            on  p.year = b.year
           and e.isbn_code = p.exchangecode
           and p.newbillno = b.billno
           left join zfgl.payreport p1
            on p.reportid = p1.reportid
           and p.bankcode = p1.bankcode
            and p.year = p1.year
            and p1.tzbm=b.tzbm
           left join zfgl.bills b1
            on b.year = b1.year
           and b.enterpriseguid = b1.enterpriseguid
           and b.billno = b1.billno
            left join jczl.economysectiongov e1
            on b.govecoguid = e1.guid
          left join zjsb.budget bb
            on b.gplanid = bb.budgetid
           and b.tzbm = bb.resourceincode
          left join zbgl.enterpriseassignquota e3
            on bb.budgetid1 = e3.enterpriseid
           and bb.year = e3.year
          left join zbgl.detailassignquota d
            on e3.itemid = d.itemid
          left join jczl.budgetcategory bbb
            on bb.budgetcategoryguid = bbb.guid
            left join jczl.enterprise ee
            on e.parent_guid = ee.guid
            left join jczl.functionsection f
            on p.year = f.year and trim(b.functionguid) = f.guid
            left join jczl.economysection e2
            on b.economyguid = e2.guid
            left join jczl.program pp
            on b.programguid = pp.guid
         where  p.year = substr(riqi, 0, 4)
        ----------
        union all

        select '3306010101' xzqh,
               g.year,
               replace(g1.reportdate, '.', '') czrq,
                substr( replace(g1.pfdate, '.', '') ,0,6) pfny,
               replace(g1.pfdate, '.', '') qsrq,
                -----------预算单位-----------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_YSDW') = 1 then
                        (select case when
                  (select case
                            when a1.dwbm is null then
                             '-1'
                            else
                             a1.dwbm
                          end
                     from CZFX_DM_YSDW a1
                    where a1.dwbm = e.isbn_code)
                   is null then '-1' else
                    (select case
                            when a1.dwbm is null then
                             '-1'
                            else
                             a1.dwbm
                          end
                     from CZFX_DM_YSDW a1
                    where a1.dwbm = e.isbn_code)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_YSDW') = 2 then
                  (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_YSDW'
                      and a3.dynf = g.year
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = e.isbn_code)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_YSDW'
                      and a3.dynf = g.year
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = e.isbn_code)
                    end from dual)
                 else
                  '-1'
               end dwbm,
               ------------------------------
               --'' dwmc, --预留 单位名称e.isbn_code
               e.isbn_code ydwbm, --原单位编码,
               --'' zgdwmc, --预留 主管单位名称ee.name,
               --'' division, --预留 单位所属归口e.division
               --'' ssgkmc, --预留 单位所属归口名称d.name
              case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_DWXZ') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_DWXZ a1
                    where a1.bm = e.enterprisekind)
                    is null then '-1' else
                     (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_DWXZ a1
                    where a1.bm = e.enterprisekind)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_DWXZ') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_DWXZ'
                      and a3.dynf = g.year
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = e.enterprisekind)
                      is null then '-1' else
                       (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_DWXZ'
                      and a3.dynf = g.year
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = e.enterprisekind)
                      end from dual)
                 else
                  '-1'
               end dwxz,
               ------------支付方式----------
                  case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_ZFLX') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZFLX a1
                    where a1.bm = e.paytype)
                    is null then '-1' else
                     (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZFLX a1
                    where a1.bm = e.paytype)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_ZFLX') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZFLX'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e.paytype)
                      is null then '-1' else
                        (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZFLX'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e.paytype)
                      end from dual)
                 else
                  '-1'
               end zflx,
               -------收支分类-------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_SZFL') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_SZFL a1
                    where a1.bm = F.SZTYPE)
                    is null then '-1' else
                      (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_SZFL a1
                    where a1.bm = F.SZTYPE)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_SZFL') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_SZFL'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = F.SZTYPE)
                      is null then '-1' else
                        (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_SZFL'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = F.SZTYPE)
                      end from dual)
                 else
                  '-1'
               end szfl,
               -----------功能科目-----------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_GNKM') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_GNKM a1
                    where a1.bm = f.isbn_code)
                    is null then '-1' else
                     (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_GNKM a1
                    where a1.bm = f.isbn_code)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_GNKM') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_GNKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = f.isbn_code)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_GNKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = f.isbn_code)
                      end from dual)
                 else
                  '-1'
               end gnkmbm,
               ----------------------------
               --f.code gnkmbm,
               --'' gnkmmc, --预留 功能科目名称f.name,
               ---------政府经济科目----------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_ZFJJKM') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZFJJKM a1
                    where a1.bm = e1.isbn_code)
                    is null then '-1' else
                    (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZFJJKM a1
                    where a1.bm = e1.isbn_code)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_ZFJJKM') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZFJJKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e1.isbn_code)
                      is null then '-1' else
                       (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZFJJKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e1.isbn_code)
                      end from dual)
                 else
                  '-1'
               end zfjjkmbm,
               --------------------------------------
               -- e2.code zfjjkmbm,
               --'' zfjjkmmc, --预留 政府经济科目名称e2.name,
               ----------部门经济科目---------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_BMJJKM') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_BMJJKM a1
                    where a1.bm = e2.isbn_code)
                    is null then '-1' else
                     (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_BMJJKM a1
                    where a1.bm = e2.isbn_code)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_BMJJKM') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_BMJJKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e2.isbn_code)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_BMJJKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e2.isbn_code)
                      end from dual)
                 else
                  '-1'
               end bmjjkmbm,
               --------------------------------
               --e1.code bmjjkmbm,
              -- '' bmjjkmmc, --预留 部门经济科目名称e1.name,
              --------项目类别---------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_XMLB') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_XMLB a1
                    where a1.bm = d.programtypecode)
                    is null then '-1' else
                           (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_XMLB a1
                    where a1.bm = d.programtypecode)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_XMLB') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_XMLB'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = d.programtypecode)
                      is null then '-1' else
                       (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_XMLB'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = d.programtypecode)
                      end from dual)
                 else
                  '-1'
               end xmlb,
               ------------------------------
               --d.programtypecode,
              -- '' xmlbmc, --预留 项目类别名称d.programtypename,
               pp.guid xmid,
               case
                 when pp.isbn_code is null then
                  pp.name
                 else
                  pp.isbn_code
               end xmbm,
               pp.name xmmc,
               --------资金来源-------
                              case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_ZJLY_JCGC') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZJLY_JCGC a1
                    where a1.bm = bb.resourceincode)
                    is null then '-1' else
                    (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZJLY_JCGC a1
                    where a1.bm = bb.resourceincode)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_ZJLY_JCGC') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZJLY_JCGC'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = bb.resourceincode)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZJLY_JCGC'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = bb.resourceincode)
                      end from dual)
                 else
                  '-1'
               end zjly,
               --------------------
               bb.dwqkwh,
 case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_GKCS') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_GKCS a1
                    where a1.bm = bb.divisionguid)
                    is null then '-1' else
                    (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_GKCS a1
                    where a1.bm = bb.divisionguid)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_GKCS') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_GKCS'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = bb.divisionguid)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_GKCS'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = bb.divisionguid)
                      end from dual)
                 else
                  '-1'
               end zbssgk,
               bb.budgetyear,
                  bbb.guid,
               -------指标类型--------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_ZBLX') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZBLX a1
                    where a1.bm = bbb.guid)
                    is null then '-1' else
                      (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZBLX a1
                    where a1.bm = bbb.guid)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_ZBLX') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZBLX'
                      and a3.dynf = g.year
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = bbb.guid)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZBLX'
                      and a3.dynf = g.year
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = bbb.guid)
                      end from dual)
                 else
                  '-1'
               end zblxbm,
               ----------------------
               '' zblxmc, --预留 指标类型名称bb.name
               g.budgetid,
               --bb.budgetid,
               nvl(e3.caigou, 0) sfcg,
              -------采购目录-------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_CGML') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_CGML a1
                    where a1.bm = e3.buycatalogcode)
                    is null then '-1' else
                    (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_CGML a1
                    where a1.bm = e3.buycatalogcode)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_CGML') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_CGML'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e3.buycatalogcode)
                      is null then '-1' else
                       (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_CGML'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e3.buycatalogcode)
                      end from dual)
                 else
                  '-1'
               end cgml,
----------------------
               -- e3.buycatalogcode,
               ----采购类型------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_CGLX') = 1 and e3.caigou = 1 and
                      e3.buytypecode is not null then
                      (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_CGLX a1
                    where a1.bm = e3.buytypecode)
                    is null then '-1' else
                     (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_CGLX a1
                    where a1.bm = e3.buytypecode)
                    end from dual)
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_CGLX') = 1 and e3.caigou = 1 and
                      e3.buytypecode is null then
                  '-1'
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_CGLX') = 2 and e3.caigou = 1 and
                      e3.buytypecode is not null then
                      (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            when (select a.jcgc
                                    from czfx_dm_bmbqd a
                                   where a.bmb = 'CZFX_DM_CGLX') = 2 and
                                 e3.caigou = 1 and e3.buytypecode is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_CGLX'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e3.buytypecode)
                      is null then '-1' else
                       (select case
                            when a3.bm is null then
                             '-1'
                            when (select a.jcgc
                                    from czfx_dm_bmbqd a
                                   where a.bmb = 'CZFX_DM_CGLX') = 2 and
                                 e3.caigou = 1 and e3.buytypecode is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_CGLX'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e3.buytypecode)
                    end from dual)
                 else
                  e3.buytypecode
               end cglx,
               -------------------------
               '0' paymode, --99表示申拨支出
               g.gplanid,
               g.id,
               '99' jsfs, --99表示申拨支出
               g.acceptname,
               g.acceptaccount,
               g.acceptbank,
               g.remark,
               '9999', --付款单位银行
               g.sanctionmoney,
               sysdate xgsj,
               '1'
        --count(*), sum(p.totalmoney)
          from zjsb.gplandetail g
          left join zjsb.gplan g1
            on g.year = g1.year
           and g.gplanid = g1.gplanid
          left join jczl.enterprise e
            on g.year = e.year
           and g.enterpriseguid = e.guid
          left join jczl.enterprise ee
            on e.parent_guid = ee.guid
          left join jczl.functionsection f
            on g.functionguid = f.guid
          left join jczl.economysectiongov e1
            on g.zfecosecguid = e1.guid
          left join jczl.economysection e2
            on g.ecosecguid = e2.guid
          left join zjsb.budget bb
            on g.budgetid = bb.budgetid
           and g.resourceincode = bb.resourceincode
          left join zbgl.enterpriseassignquota e3
            on bb.budgetid1 = e3.enterpriseid
          left join zbgl.detailassignquota d
            on e3.itemid = d.itemid
          left join jczl.program pp
            on g.programguid = pp.guid
          left join jczl.budgetcategory bbb
            on bb.budgetcategoryguid = bbb.guid
         where g1.signed = 1
           and g1.lsname <> -1
           and g1.allostate is not null
           and g.budgetid is not null
           and g.year = substr(riqi, 0, 4);
    end if;
    commit;
  end;

  procedure GET_CZFX_JCGC_ZBZXHZ(riqi varchar2) is
  begin
     delete from CZFX_JCGC_ZBZXHZ
       where xzqh = '3306010101'
         and ny in (substr(riqi, 0, 6));
          insert into CZFX_JCGC_ZBZXHZ
       select '3306010101' xzqh,
       substr(riqi, 0, 6) ny,
       -----------预算单位-----------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_YSDW') = 1 then
                        (select case when
                  (select case
                            when a1.dwbm is null then
                             '-1'
                            else
                             a1.dwbm
                          end
                     from CZFX_DM_YSDW a1
                    where a1.dwbm = e.isbn_code)
                   is null then '-1' else
                    (select case
                            when a1.dwbm is null then
                             '-1'
                            else
                             a1.dwbm
                          end
                     from CZFX_DM_YSDW a1
                    where a1.dwbm = e.isbn_code)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_YSDW') = 2 then
                  (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_YSDW'
                      and a3.dynf = b.year
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = e.isbn_code)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_YSDW'
                      and a3.dynf = b.year
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = e.isbn_code)
                    end from dual)
                 else
                  '-1'
               end dwbm,
               ------------------------------
               --'' dwmc, --预留 单位名称e.isbn_code
               e.isbn_code ydwbm, --预留 主管单位名称ee.isbn_code,
               --'' zgdwmc, --预留 主管单位名称ee.name,
                --'' division, --预留 单位所属归口e.division
              -- '' ssgkmc, --预留 单位所属归口名称d.name
               ------------------------------
               ------------单位性质----------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_DWXZ') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_DWXZ a1
                    where a1.bm = e.enterprisekind)
                    is null then '-1' else
                     (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_DWXZ a1
                    where a1.bm = e.enterprisekind)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_DWXZ') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_DWXZ'
                      and a3.dynf = p.year
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = e.enterprisekind)
                      is null then '-1' else
                       (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_DWXZ'
                      and a3.dynf = p.year
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = e.enterprisekind)
                      end from dual)
                 else
                  '-1'
               end dwxz,
               -------------支付方式----------
                 case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_ZFLX') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZFLX a1
                    where a1.bm = e.paytype)
                    is null then '-1' else
                     (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZFLX a1
                    where a1.bm = e.paytype)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_ZFLX') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZFLX'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e.paytype)
                      is null then '-1' else
                        (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZFLX'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e.paytype)
                      end from dual)
                 else
                  '-1'
               end zflx,
               -------收支分类-------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_SZFL') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_SZFL a1
                    where a1.bm = f.SZTYPE)
                    is null then '-1' else
                      (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_SZFL a1
                    where a1.bm = f.SZTYPE)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_SZFL') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_SZFL'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = f.SZTYPE)
                      is null then '-1' else
                        (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_SZFL'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = f.SZTYPE)
                      end from dual)
                 else
                  '-1'
               end szfl,
       -----------功能科目-----------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_GNKM') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_GNKM a1
                    where a1.bm = f.code)
                    is null then '-1' else
                     (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_GNKM a1
                    where a1.bm = f.code)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_GNKM') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_GNKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = f.code)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_GNKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = f.code)
                      end from dual)
                 else
                  '-1'
               end gnkmbm,
               ----------------------------
               --f.code gnkmbm,
              -- '' gnkmmc, --预留 功能科目名称f.name,
                --------项目类别---------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_XMLB') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_XMLB a1
                    where a1.bm = d.programtypecode)
                    is null then '-1' else
                           (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_XMLB a1
                    where a1.bm = d.programtypecode)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_XMLB') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_XMLB'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = d.programtypecode)
                      is null then '-1' else
                       (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_XMLB'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = d.programtypecode)
                      end from dual)
                 else
                  '-1'
               end xmlb,
               ------------------------------
               --d.programtypecode,
              -- '' xmlbmc, --预留 项目类别名称d.programtypename,
       p.guid,
       case
         when p.isbn_code is null then
          p.name
         else
          p.isbn_code
       end xmbm,
       p.name,
       --------资金来源-------
                              case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_ZJLY_JCGC') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZJLY_JCGC a1
                    where a1.bm = b.resourceincode)
                    is null then '-1' else
                    (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZJLY_JCGC a1
                    where a1.bm =b.resourceincode)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_ZJLY_JCGC') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZJLY_JCGC'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = b.resourceincode)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZJLY_JCGC'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = b.resourceincode)
                      end from dual)
                 else
                  '-1'
               end zjly,
               ------指标所属归口----------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_GKCS') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_GKCS a1
                    where a1.bm = b.divisionguid)
                    is null then '-1' else
                    (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_GKCS a1
                    where a1.bm = b.divisionguid)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_GKCS') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_GKCS'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = b.divisionguid)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_GKCS'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = b.divisionguid)
                      end from dual)
                 else
                  '-1'
               end zbssgk,
               ---------------------
       b.budgetyear,
bb.guid,
       -------指标类型--------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_ZBLX') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZBLX a1
                    where a1.bm = bb.guid)
                    is null then '-1' else
                      (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZBLX a1
                    where a1.bm = bb.guid)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_ZBLX') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZBLX'
                      and a3.dynf = b.year
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = bb.guid)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZBLX'
                      and a3.dynf = b.year
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = bb.guid)
                      end from dual)
                 else
                  '-1'
               end zblxbm,
               ----------------------
               '' zblxmc, --预留 指标类型名称bb.name
       nvl(e1.caigou, 0) sfcg,
       b.budgetid,
       b.money,
       nvl(aa.zxs_lj, 0) zxs_lj,
       nvl(bb.zxs_dy, 0) zxs_dy,
       sysdate xgrq
  from zjsb.budget b
  left join jczl.enterprise e
    on b.enterpriseguid = e.guid
  left join jczl.enterprise ee
    on e.parent_guid = ee.guid
  left join jczl.functionsection f
    on b.functionguid = f.guid
  left join zbgl.enterpriseassignquota e1
    on b.budgetid1 = e1.enterpriseid
  left join zbgl.detailassignquota d
    on e1.itemid = d.itemid
  left join jczl.program p
    on b.programguid = p.guid
  left join jczl.budgetcategory bb
    on b.budgetcategoryguid = bb.guid
----执行数当年累计
  left join (select a.budgetid, a.tzbm, sum(a.money) zxs_lj
               from (select p1.reportdate,
                            b.gplanid     budgetid,
                            p1.tzbm,
                            b.totalmoney  money
                       from (select distinct reportid,bankcode,exchangecode,newbillno,year from zfgl.payreportdetail) p
                       left join zfgl.payreport p1
                         on p.reportid = p1.reportid
                        and p.bankcode = p1.bankcode
                        and p.year = p1.year
                       left join jczl.enterprise e
                         on p.year = e.year
                        and p.exchangecode = e.isbn_code
                       inner join zfgl.billsdetail b
                         on p.year = b.year
                        and e.isbn_code = p.exchangecode
                        and e.guid = b.enterpriseguid
                        and p.newbillno = b.billno
                        and p1.tzbm=b.tzbm
                      where p.year = substr(riqi, 0, 4)
                        and substr(p1.reportdate, 0, 6) <= substr(riqi, 0, 6)
                     union all
                     select replace(g1.pfdate, '.', '') qsrq,
                            g.budgetid,
                            g.resourceincode,
                            g.sanctionmoney
                       from zjsb.gplandetail g
                       left join zjsb.gplan g1
                         on g.year = g1.year
                        and g.gplanid = g1.gplanid
                      where g1.signed = 1
                        and g1.lsname <> -1
                        and g1.allostate is not null
                        and g.budgetid is not null
                        and g.year = substr(riqi, 0, 4)
                        and substr(replace(g1.pfdate, '.', '') ，0, 6) <=
                            substr(riqi, 0, 6)) a where a.budgetid is not null  --排除指标为空
              group by a.budgetid, a.tzbm) aa
    on b.budgetid = aa.budgetid
   and b.resourceincode = aa.tzbm
-------当月支出
  left join (select substr(aa.reportdate, 0, 6) ny,
                    aa.budgetid,
                    aa.tzbm,
                    sum(aa.money) zxs_dy
               from (select p1.reportdate,
                            b.gplanid     budgetid,
                            p1.tzbm,
                            b.totalmoney  money
                       from (select distinct reportid,bankcode,exchangecode,newbillno,year from zfgl.payreportdetail) p
                       left join zfgl.payreport p1
                         on p.reportid = p1.reportid
                        and p.bankcode = p1.bankcode
                        and p.year = p1.year
                       left join jczl.enterprise e
                         on p.year = e.year
                        and p.exchangecode = e.isbn_code
                       left join zfgl.billsdetail b
                         on p.year = b.year
                        and e.isbn_code = p.exchangecode
                        and e.guid = b.enterpriseguid
                        and p.newbillno = b.billno
                        and p1.tzbm = b.tzbm
                      where substr(p1.reportdate, 0, 6) = substr(riqi, 0, 6)
                     union all
                     select replace(g1.pfdate, '.', '') qsrq,
                            g.budgetid,
                            g.resourceincode,
                            g.sanctionmoney
                       from zjsb.gplandetail g
                       left join zjsb.gplan g1
                         on g.year = g1.year
                        and g.gplanid = g1.gplanid
                      where g1.signed = 1
                        and g1.lsname <> -1
                        and g1.allostate is not null
                        and g.budgetid is not null
                        and g.year=substr(riqi, 0, 4)
                        and substr(replace(g1.pfdate, '.', '') ,0, 6) =
                            substr(riqi, 0, 6)) aa where aa.budgetid is not null  --排除指标为空
              group by substr(aa.reportdate, 0, 6), aa.budgetid, aa.tzbm) bb
    on b.budgetid = bb.budgetid
   and b.resourceincode = bb.tzbm
 where b.year = substr(riqi, 0, 4)
   and replace(b.inputdate, '.', '') <= substr(riqi, 0, 8);

   ----1-9号删除、插入去年12月的数据---
   if substr(riqi, 5, 2) = '01' and substr(riqi, 7, 2) >= '01' and
       substr(riqi, 7, 2) <= '09' then
  delete from CZFX_JCGC_ZBZXHZ
       where xzqh = '3306010101'
         and ny in (substr(riqi, 0, 4)-1||'12');
          insert into CZFX_JCGC_ZBZXHZ
       select '3306010101' xzqh,
      substr(riqi, 0, 4)-1||'12' ny,
       -----------预算单位-----------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_YSDW') = 1 then
                        (select case when
                  (select case
                            when a1.dwbm is null then
                             '-1'
                            else
                             a1.dwbm
                          end
                     from CZFX_DM_YSDW a1
                    where a1.dwbm = e.isbn_code)
                   is null then '-1' else
                    (select case
                            when a1.dwbm is null then
                             '-1'
                            else
                             a1.dwbm
                          end
                     from CZFX_DM_YSDW a1
                    where a1.dwbm = e.isbn_code)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_YSDW') = 2 then
                  (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_YSDW'
                      and a3.dynf = b.year
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = e.isbn_code)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_YSDW'
                      and a3.dynf = b.year
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = e.isbn_code)
                    end from dual)
                 else
                  '-1'
               end dwbm,
               ------------------------------
               --'' dwmc, --预留 单位名称e.isbn_code
               e.isbn_code ydwbm, --预留 主管单位名称ee.isbn_code,
               --'' zgdwmc, --预留 主管单位名称ee.name,
                --'' division, --预留 单位所属归口e.division
              -- '' ssgkmc, --预留 单位所属归口名称d.name
               ------------------------------
               ------------单位性质----------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_DWXZ') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_DWXZ a1
                    where a1.bm = e.enterprisekind)
                    is null then '-1' else
                     (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_DWXZ a1
                    where a1.bm = e.enterprisekind)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_DWXZ') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_DWXZ'
                      and a3.dynf = p.year
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = e.enterprisekind)
                      is null then '-1' else
                       (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_DWXZ'
                      and a3.dynf = p.year
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = e.enterprisekind)
                      end from dual)
                 else
                  '-1'
               end dwxz,
               -------------支付方式----------
                 case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_ZFLX') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZFLX a1
                    where a1.bm = e.paytype)
                    is null then '-1' else
                     (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZFLX a1
                    where a1.bm = e.paytype)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_ZFLX') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZFLX'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e.paytype)
                      is null then '-1' else
                        (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZFLX'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e.paytype)
                      end from dual)
                 else
                  '-1'
               end zflx,
               -------收支分类-------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_SZFL') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_SZFL a1
                    where a1.bm = f.SZTYPE)
                    is null then '-1' else
                      (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_SZFL a1
                    where a1.bm = f.SZTYPE)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_SZFL') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_SZFL'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = f.SZTYPE)
                      is null then '-1' else
                        (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_SZFL'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = f.SZTYPE)
                      end from dual)
                 else
                  '-1'
               end szfl,
       -----------功能科目-----------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_GNKM') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_GNKM a1
                    where a1.bm = f.code)
                    is null then '-1' else
                     (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_GNKM a1
                    where a1.bm = f.code)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_GNKM') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_GNKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = f.code)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_GNKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = f.code)
                      end from dual)
                 else
                  '-1'
               end gnkmbm,
               ----------------------------
               --f.code gnkmbm,
              -- '' gnkmmc, --预留 功能科目名称f.name,
                --------项目类别---------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_XMLB') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_XMLB a1
                    where a1.bm = d.programtypecode)
                    is null then '-1' else
                           (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_XMLB a1
                    where a1.bm = d.programtypecode)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_XMLB') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_XMLB'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = d.programtypecode)
                      is null then '-1' else
                       (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_XMLB'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = d.programtypecode)
                      end from dual)
                 else
                  '-1'
               end xmlb,
               ------------------------------
               --d.programtypecode,
              -- '' xmlbmc, --预留 项目类别名称d.programtypename,
       p.guid,
       case
         when p.isbn_code is null then
          p.name
         else
          p.isbn_code
       end xmbm,
       p.name,
       --------资金来源-------
                              case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_ZJLY_JCGC') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZJLY_JCGC a1
                    where a1.bm = b.resourceincode)
                    is null then '-1' else
                    (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZJLY_JCGC a1
                    where a1.bm =b.resourceincode)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_ZJLY_JCGC') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZJLY_JCGC'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = b.resourceincode)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZJLY_JCGC'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = b.resourceincode)
                      end from dual)
                 else
                  '-1'
               end zjly,
               ------指标所属归口----------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_GKCS') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_GKCS a1
                    where a1.bm = b.divisionguid)
                    is null then '-1' else
                    (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_GKCS a1
                    where a1.bm = b.divisionguid)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_GKCS') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_GKCS'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = b.divisionguid)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_GKCS'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = b.divisionguid)
                      end from dual)
                 else
                  '-1'
               end zbssgk,
               ---------------------
       b.budgetyear,
bb.guid,
       -------指标类型--------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_ZBLX') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZBLX a1
                    where a1.bm = bb.guid)
                    is null then '-1' else
                      (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZBLX a1
                    where a1.bm = bb.guid)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_ZBLX') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZBLX'
                      and a3.dynf = b.year
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = bb.guid)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZBLX'
                      and a3.dynf = b.year
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = bb.guid)
                      end from dual)
                 else
                  '-1'
               end zblxbm,
               ----------------------
               '' zblxmc, --预留 指标类型名称bb.name
       nvl(e1.caigou, 0) sfcg,
       b.budgetid,
       b.money,
       nvl(aa.zxs_lj, 0) zxs_lj,
       nvl(bb.zxs_dy, 0) zxs_dy,
       sysdate xgrq
  from zjsb.budget b
  left join jczl.enterprise e
    on b.enterpriseguid = e.guid
  left join jczl.enterprise ee
    on e.parent_guid = ee.guid
  left join jczl.functionsection f
    on b.functionguid = f.guid
  left join zbgl.enterpriseassignquota e1
    on b.budgetid1 = e1.enterpriseid
  left join zbgl.detailassignquota d
    on e1.itemid = d.itemid
  left join jczl.program p
    on b.programguid = p.guid
  left join jczl.budgetcategory bb
    on b.budgetcategoryguid = bb.guid
----执行数当年累计
  left join (select a.budgetid, a.tzbm, sum(a.money) zxs_lj
               from (select p1.reportdate,
                            b.gplanid     budgetid,
                            p1.tzbm,
                            b.totalmoney  money
                       from (select distinct reportid,bankcode,exchangecode,newbillno,year from zfgl.payreportdetail) p
                       left join zfgl.payreport p1
                         on p.reportid = p1.reportid
                        and p.bankcode = p1.bankcode
                        and p.year = p1.year
                       left join jczl.enterprise e
                         on p.year = e.year
                        and p.exchangecode = e.isbn_code
                       inner join zfgl.billsdetail b
                         on p.year = b.year
                        and e.isbn_code = p.exchangecode
                        and e.guid = b.enterpriseguid
                        and p.newbillno = b.billno
                        and p1.tzbm = b.tzbm
                      where p.year = substr(riqi, 0, 4)-1
                      --  and substr(p1.reportdate, 0, 6) <= substr(riqi, 0, 6)
                     union all
                     select replace(g1.pfdate, '.', '') qsrq,
                            g.budgetid,
                            g.resourceincode,
                            g.sanctionmoney
                       from zjsb.gplandetail g
                       left join zjsb.gplan g1
                         on g.year = g1.year
                        and g.gplanid = g1.gplanid
                      where g1.signed = 1
                        and g1.lsname <> -1
                        and g1.allostate is not null
                        and g.budgetid is not null
                        and g.year = substr(riqi, 0, 4)-1
                        /*and substr(replace(g1.pfdate, '.', '') ，0, 6) <=
                            substr(riqi, 0, 6)*/) a where a.budgetid is not null  --排除指标为空
              group by a.budgetid, a.tzbm) aa
    on b.budgetid = aa.budgetid
   and b.resourceincode = aa.tzbm
-------当月支出
  left join (select substr(aa.reportdate, 0, 6) ny,
                    aa.budgetid,
                    aa.tzbm,
                    sum(aa.money) zxs_dy
               from (select p1.reportdate,
                            b.gplanid     budgetid,
                            p1.tzbm,
                            b.totalmoney  money
                       from (select distinct reportid,bankcode,exchangecode,newbillno,year from zfgl.payreportdetail) p
                       left join zfgl.payreport p1
                         on p.reportid = p1.reportid
                        and p.bankcode = p1.bankcode
                        and p.year = p1.year
                       left join jczl.enterprise e
                         on p.year = e.year
                        and p.exchangecode = e.isbn_code
                       left join zfgl.billsdetail b
                         on p.year = b.year
                        and e.isbn_code = p.exchangecode
                        and e.guid = b.enterpriseguid
                        and p.newbillno = b.billno
                        and p1.tzbm = b.tzbm
                      where substr(p1.reportdate, 0, 6) = substr(riqi, 0, 4)-1||'12'
                     union all
                     select replace(g1.pfdate, '.', '') qsrq,
                            g.budgetid,
                            g.resourceincode,
                            g.sanctionmoney
                       from zjsb.gplandetail g
                       left join zjsb.gplan g1
                         on g.year = g1.year
                        and g.gplanid = g1.gplanid
                      where g1.signed = 1
                        and g1.lsname <> -1
                        and g1.allostate is not null
                        and g.budgetid is not null
                        and
                        g.year=substr(riqi, 0, 4)-1
                       and  substr(replace(g1.pfdate, '.', '') ,0, 6) >=
                            substr(riqi, 0, 4)-1||'12') aa where aa.budgetid is not null  --排除指标为空
              group by substr(aa.reportdate, 0, 6), aa.budgetid, aa.tzbm) bb
    on b.budgetid = bb.budgetid
   and b.resourceincode = bb.tzbm
 where b.year = substr(riqi, 0, 4)-1
 ;
  end if;
   ------------------------------------
commit;
end;

procedure GET_CZFX_JCGC_ZFZXHZ(riqi varchar2) is
  begin
     delete from CZFX_JCGC_ZFZXHZ
       where xzqh = '3306010101'
         and ny in (substr(riqi, 0, 6));
          insert into CZFX_JCGC_ZFZXHZ
          select aa.xzqh,
       aa.ny,
       -----------预算单位-----------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_YSDW') = 1 then
                        (select case when
                  (select case
                            when a1.dwbm is null then
                             '-1'
                            else
                             a1.dwbm
                          end
                     from CZFX_DM_YSDW a1
                    where a1.dwbm = aa.dwbm)
                   is null then '-1' else
                    (select case
                            when a1.dwbm is null then
                             '-1'
                            else
                             a1.dwbm
                          end
                     from CZFX_DM_YSDW a1
                    where a1.dwbm = aa.dwbm)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_YSDW') = 2 then
                  (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_YSDW'
                      and a3.dynf = substr(aa.ny,0,4)
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = aa.dwbm)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_YSDW'
                      and a3.dynf = substr(aa.ny,0,4)
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = aa.dwbm)
                    end from dual)
                 else
                  '-1'
               end dwbm,
               ------------------------------
       --aa.dwbm,
       --'' dwmc,--aa.dwmc,
       aa.dwbm ydwbm,--aa.zgdwbm,
       --'' zgdwmc,--aa.zgdwmc,
       --'' ssgkbm,--aa.ssgkbm,
       --'' ssgkmc,--case when (select d.name from jczl.division d where d.guid=aa.ssgkbm) is null then '未知' else (select d.name from jczl.division d where d.guid=aa.ssgkbm) end ssgkmc,
       ------------单位性质----------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_DWXZ') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_DWXZ a1
                    where a1.bm = aa.dwxz)
                    is null then '-1' else
                     (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_DWXZ a1
                    where a1.bm = aa.dwxz)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_DWXZ') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_DWXZ'
                      and a3.dynf = substr(aa.ny,0,4)
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = aa.dwxz)
                      is null then '-1' else
                       (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_DWXZ'
                      and a3.dynf = substr(aa.ny,0,4)
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = aa.dwxz)
                      end from dual)
                 else
                  '-1'
               end dwxz,
               --------------------
       --aa.dwxz,
       ------------支付方式----------
                 case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_ZFLX') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZFLX a1
                    where a1.bm = aa.zflx)
                    is null then '-1' else
                     (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZFLX a1
                    where a1.bm = aa.zflx)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_ZFLX') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZFLX'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = aa.zflx)
                      is null then '-1' else
                        (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZFLX'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = aa.zflx)
                      end from dual)
                 else
                  '-1'
               end zflx,
               ------------------
       --aa.zflx,
        ---------政府经济科目----------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_ZFJJKM') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZFJJKM a1
                    where a1.bm = aa.zfjjkmbm)
                    is null then '-1' else
                    (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZFJJKM a1
                    where a1.bm = aa.zfjjkmbm)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_ZFJJKM') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZFJJKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = aa.zfjjkmbm)
                      is null then '-1' else
                       (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZFJJKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = aa.zfjjkmbm)
                      end from dual)
                 else
                  '-1'
               end zfjjkmbm,
               --------------------------------------
       --aa.zfjjkmbm,
     --  '' zfjjkmmc,--aa.zfjjkmmc,
       ----------部门经济科目---------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_BMJJKM') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_BMJJKM a1
                    where a1.bm = aa.bmjjkmbm)
                    is null then '-1' else
                     (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_BMJJKM a1
                    where a1.bm = aa.bmjjkmbm)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_BMJJKM') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_BMJJKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = aa.bmjjkmbm)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_BMJJKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = aa.bmjjkmbm)
                      end from dual)
                 else
                  '-1'
               end bmjjkmbm,
               --------------------------------
       --aa.bmjjkmbm,
      -- ''bmjjkmmc,--aa.bmjjkmmc,
        --------资金来源-------
                              case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_ZJLY_JCGC') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZJLY_JCGC a1
                    where a1.bm = aa.tzbm)
                    is null then '-1' else
                    (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZJLY_JCGC a1
                    where a1.bm = aa.tzbm)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_ZJLY_JCGC') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZJLY_JCGC'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = aa.tzbm)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZJLY_JCGC'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = aa.tzbm)
                      end from dual)
                 else
                  '-1'
               end zjly,
               --------------------
       --aa.tzbm,
       aa.iscg,
       aa.zxs_lj,
       nvl(bb.zxs_dy, 0) zxs_dy,
       sysdate xgrq
         from (select '3306010101' xzqh,
               substr(riqi, 0, 6) ny,
               e.isbn_code dwbm,
               --e.name dwmc,
               ee.code zgdwbm,
               --ee.name zgdwmc,
               e.enterprisekind dwxz,
               e.paytype zflx,
               e.enterprisetype dwlx,
               e1.isbn_code zfjjkmbm,
               --e1.name zfjjkmmc,
               e2.isbn_code bmjjkmbm,
               --e2.name bmjjkmmc,
               b.tzbm,
               nvl(b.isbuy, 0) iscg,
               nvl(sum(b.totalmoney), 0) zxs_lj
          from zfgl.billsdetail b
          left join jczl.enterprise e
            on b.enterpriseguid = e.guid
          left join jczl.enterprise ee
            on e.parent_guid = ee.guid
          left join jczl.economysectiongov e1
            on b.govecoguid = e1.guid
          left join jczl.economysection e2
            on b.economyguid = e2.guid
         where b.year = substr(riqi, 0, 4)
           and exists
         (select *
                  from zfgl.payreportdetail p
                  left join zfgl.payreport p1
                    on p.year = p1.year
                   and p.reportid = p1.reportid
                   and p.bankcode = p1.bankcode
                 where b.year = p.year
                   and e.isbn_code = p.exchangecode
                   and b.billno = p.newbillno
                   and b.tzbm = p1.tzbm
                   and p.year = substr(riqi, 0, 4)
                   and substr(p1.reportdate, 0, 6) <= substr(riqi, 0, 6))
         group by e.isbn_code,
                  --e.name,
                  ee.code,
                  --ee.name,
                  case
                    when e.division is null then
                     '99'
                    else
                     e.division
                  end,
                  e.enterprisekind,
                  e.paytype,
                  e.enterprisetype,
                  e1.isbn_code,
                  --e1.name,
                  e2.isbn_code,
                  --e2.name,
                  b.tzbm,
                  nvl(b.isbuy, 0)
                  union all
                  ---申拨部分--------
                  select
                  '3306010101' xzqh,
               substr(riqi, 0, 6) ny,
               e.isbn_code dwbm,
               ee.code zgdwbm,
               e.enterprisekind dwxz,
               e.paytype zflx,
               e.enterprisetype dwlx,
               e1.isbn_code zfjjkmbm,
               e2.isbn_code bmjjkmbm,
               g.resourceincode ,
               to_char(nvl(e3.caigou, 0)) iscg,
               nvl(sum(g.sanction), 0) zxs_lj
                  from zjsb.gplandetail g
                  left join zjsb.gplan g1
                  on g.year = g1.year
           and g.gplanid = g1.gplanid
            left join jczl.enterprise e
            on g.enterpriseguid = e.guid
          left join jczl.enterprise ee
            on e.parent_guid = ee.guid
          left join jczl.economysectiongov e1
            on g.zfecosecguid = e1.guid
          left join jczl.economysection e2
            on g.ecosecguid = e2.guid
          left join zjsb.budget bb
            on g.budgetid = bb.budgetid
           and g.resourceincode = bb.resourceincode
          left join zbgl.enterpriseassignquota e3
            on bb.budgetid1 = e3.enterpriseid
            where g1.signed = 1
           and g1.lsname <> -1
           and g1.allostate is not null
           and g.budgetid is not null
           and g.year = substr(riqi, 0, 4)
           and substr(replace(g1.pfdate, '.', ''),0,6)<=substr(riqi, 0, 6)
           group by
           e.isbn_code,
                  ee.code,
                  case
                    when e.division is null then
                     '99'
                    else
                     e.division
                  end,
                  e.enterprisekind,
                  e.paytype,
                  e.enterprisetype,
                  e1.isbn_code,
                  e2.isbn_code,
                  g.resourceincode,
                  nvl(e3.caigou, 0)
                  -------------------
                  ) aa
  left join
-----------当月支出
 (select '3306010101' xzqh,
         substr(riqi, 0, 6) ny,
         e.isbn_code dwbm,
         --e.name dwmc,
         ee.code zgdwbm,
     /*    case
           when e.division is null then
            '99'
           else
            e.division
         end ssgkbm,*/
         e.enterprisekind dwxz,
         e.paytype zflx,
         e.enterprisetype dwlx,
         e1.isbn_code zfjjkmbm,
         --e1.name zfjjkmmc,
         e2.isbn_code bmjjkmbm,
         --e2.name bmjjkmmc,
         b.tzbm,
         nvl(b.isbuy, 0) iscg,
         nvl(sum(b.totalmoney), 0) zxs_dy
             from zfgl.billsdetail b
    left join jczl.enterprise e
      on b.enterpriseguid = e.guid
    left join jczl.enterprise ee
      on e.parent_guid = ee.guid
    left join jczl.economysectiongov e1
      on b.govecoguid = e1.guid
    left join jczl.economysection e2
      on b.economyguid = e2.guid
   where b.year = substr(riqi, 0, 4)
     and exists (select *
            from zfgl.payreportdetail p
            left join zfgl.payreport p1
              on p.year = p1.year
             and p.reportid = p1.reportid
             and p.bankcode = p1.bankcode
           where b.year = p.year
             and e.isbn_code = p.exchangecode
             and b.billno = p.newbillno
             and b.tzbm = p1.tzbm
             and p.year = substr(riqi, 0, 4)
             and substr(p1.reportdate, 0, 6) = substr(riqi, 0, 6))
   group by e.isbn_code,
            --e.name,
            ee.code,
            case
              when e.division is null then
               '99'
              else
               e.division
            end,
            e.enterprisekind,
            e.paytype,
            e.enterprisetype,
            e1.isbn_code,
           -- e1.name,
            e2.isbn_code,
           -- e2.name,
            b.tzbm,
            nvl(b.isbuy, 0)
            union all
            ---------申拨部分-------
            select
                  '3306010101' xzqh,
               substr(riqi, 0, 6) ny,
               e.isbn_code dwbm,
               ee.code zgdwbm,
               e.enterprisekind dwxz,
               e.paytype zflx,
               e.enterprisetype dwlx,
               e1.isbn_code zfjjkmbm,
               e2.isbn_code bmjjkmbm,
               g.resourceincode ,
               to_char(nvl(e3.caigou, 0)) iscg,
               nvl(sum(g.sanction), 0) zxs_dy
                  from zjsb.gplandetail g
                  left join zjsb.gplan g1
                  on g.year = g1.year
           and g.gplanid = g1.gplanid
            left join jczl.enterprise e
            on g.enterpriseguid = e.guid
          left join jczl.enterprise ee
            on e.parent_guid = ee.guid
          left join jczl.economysectiongov e1
            on g.zfecosecguid = e1.guid
          left join jczl.economysection e2
            on g.ecosecguid = e2.guid
          left join zjsb.budget bb
            on g.budgetid = bb.budgetid
           and g.resourceincode = bb.resourceincode
          left join zbgl.enterpriseassignquota e3
            on bb.budgetid1 = e3.enterpriseid
            where g1.signed = 1
           and g1.lsname <> -1
           and g1.allostate is not null
           and g.budgetid is not null
           and g.year = substr(riqi, 0, 4)
           and substr(replace(g1.pfdate, '.', ''),0,6)=substr(riqi, 0, 6)
           group by
           e.isbn_code,
                  ee.code,
                  case
                    when e.division is null then
                     '99'
                    else
                     e.division
                  end,
                  e.enterprisekind,
                  e.paytype,
                  e.enterprisetype,
                  e1.isbn_code,
                  e2.isbn_code,
                  g.resourceincode,
                  nvl(e3.caigou, 0)
            ------------------------
            ) bb
    on aa.xzqh = bb.xzqh
   and aa.ny = bb.ny
   and aa.dwbm = bb.dwbm
   and nvl(aa.zfjjkmbm,0) = nvl(bb.zfjjkmbm,0)
   and aa.bmjjkmbm = bb.bmjjkmbm
   and aa.tzbm = bb.tzbm
   and aa.iscg = bb.iscg;


      ----1-9号删除、插入去年12月的数据---
         if substr(riqi, 5, 2) = '01' and substr(riqi, 7, 2) >= '01' and
       substr(riqi, 7, 2) <= '09' then
delete from CZFX_JCGC_ZFZXHZ
       where xzqh = '3306010101'
         and ny in (substr(riqi, 0, 4)-1||'12');
          insert into CZFX_JCGC_ZFZXHZ
          select aa.xzqh,
       aa.ny,
       -----------预算单位-----------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_YSDW') = 1 then
                        (select case when
                  (select case
                            when a1.dwbm is null then
                             '-1'
                            else
                             a1.dwbm
                          end
                     from CZFX_DM_YSDW a1
                    where a1.dwbm = aa.dwbm)
                   is null then '-1' else
                    (select case
                            when a1.dwbm is null then
                             '-1'
                            else
                             a1.dwbm
                          end
                     from CZFX_DM_YSDW a1
                    where a1.dwbm = aa.dwbm)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_YSDW') = 2 then
                  (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_YSDW'
                      and a3.dynf = substr(aa.ny,0,4)
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = aa.dwbm)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_YSDW'
                      and a3.dynf = substr(aa.ny,0,4)
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = aa.dwbm)
                    end from dual)
                 else
                  '-1'
               end dwbm,
               ------------------------------
       --aa.dwbm,
       --'' dwmc,--aa.dwmc,
       aa.dwbm ydwbm,--aa.zgdwbm,
       --'' zgdwmc,--aa.zgdwmc,
       --'' ssgkbm,--aa.ssgkbm,
       --'' ssgkmc,--case when (select d.name from jczl.division d where d.guid=aa.ssgkbm) is null then '未知' else (select d.name from jczl.division d where d.guid=aa.ssgkbm) end ssgkmc,
       ------------单位性质----------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_DWXZ') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_DWXZ a1
                    where a1.bm = aa.dwxz)
                    is null then '-1' else
                     (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_DWXZ a1
                    where a1.bm = aa.dwxz)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_DWXZ') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_DWXZ'
                      and a3.dynf = substr(aa.ny,0,4)
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = aa.dwxz)
                      is null then '-1' else
                       (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_DWXZ'
                      and a3.dynf = substr(aa.ny,0,4)
                      and a3.dyxzqh = '3306010101'
                      and a3.dybm = aa.dwxz)
                      end from dual)
                 else
                  '-1'
               end dwxz,
               --------------------
       --aa.dwxz,
       ------------支付方式----------
                 case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_ZFLX') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZFLX a1
                    where a1.bm = aa.zflx)
                    is null then '-1' else
                     (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZFLX a1
                    where a1.bm = aa.zflx)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_ZFLX') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZFLX'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = aa.zflx)
                      is null then '-1' else
                        (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZFLX'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = aa.zflx)
                      end from dual)
                 else
                  '-1'
               end zflx,
               ------------------
       --aa.zflx,
        ---------政府经济科目----------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_ZFJJKM') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZFJJKM a1
                    where a1.bm = aa.zfjjkmbm)
                    is null then '-1' else
                    (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZFJJKM a1
                    where a1.bm = aa.zfjjkmbm)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_ZFJJKM') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZFJJKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = aa.zfjjkmbm)
                      is null then '-1' else
                       (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZFJJKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = aa.zfjjkmbm)
                      end from dual)
                 else
                  '-1'
               end zfjjkmbm,
               --------------------------------------
       --aa.zfjjkmbm,
     --  '' zfjjkmmc,--aa.zfjjkmmc,
       ----------部门经济科目---------------
               case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_BMJJKM') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_BMJJKM a1
                    where a1.bm = aa.bmjjkmbm)
                    is null then '-1' else
                     (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_BMJJKM a1
                    where a1.bm = aa.bmjjkmbm)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_BMJJKM') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_BMJJKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = aa.bmjjkmbm)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_BMJJKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = aa.bmjjkmbm)
                      end from dual)
                 else
                  '-1'
               end bmjjkmbm,
               --------------------------------
       --aa.bmjjkmbm,
      -- ''bmjjkmmc,--aa.bmjjkmmc,
        --------资金来源-------
                              case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_ZJLY_JCGC') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZJLY_JCGC a1
                    where a1.bm = aa.tzbm)
                    is null then '-1' else
                    (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZJLY_JCGC a1
                    where a1.bm = aa.tzbm)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_ZJLY_JCGC') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZJLY_JCGC'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = aa.tzbm)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZJLY_JCGC'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = aa.tzbm)
                      end from dual)
                 else
                  '-1'
               end zjly,
               --------------------
       --aa.tzbm,
       aa.iscg,
       aa.zxs_lj,
       nvl(bb.zxs_dy, 0) zxs_dy,
       sysdate xgrq
         from (select '3306010101' xzqh,
               substr(riqi, 0, 4)-1||12 ny,
               e.isbn_code dwbm,
               --e.name dwmc,
               ee.code zgdwbm,
               --ee.name zgdwmc,
               e.enterprisekind dwxz,
               e.paytype zflx,
               e.enterprisetype dwlx,
               e1.isbn_code zfjjkmbm,
               --e1.name zfjjkmmc,
               e2.isbn_code bmjjkmbm,
               --e2.name bmjjkmmc,
               b.tzbm,
               nvl(b.isbuy, 0) iscg,
               nvl(sum(b.totalmoney), 0) zxs_lj
          from zfgl.billsdetail b
          left join jczl.enterprise e
            on b.enterpriseguid = e.guid
          left join jczl.enterprise ee
            on e.parent_guid = ee.guid
          left join jczl.economysectiongov e1
            on b.govecoguid = e1.guid
          left join jczl.economysection e2
            on b.economyguid = e2.guid
         where b.year = substr(riqi, 0, 4)-1
           and exists
         (select *
                  from zfgl.payreportdetail p
                  left join zfgl.payreport p1
                    on p.year = p1.year
                   and p.reportid = p1.reportid
                   and p.bankcode = p1.bankcode
                 where b.year = p.year
                   and e.isbn_code = p.exchangecode
                   and b.billno = p.newbillno
                   and b.tzbm = p1.tzbm
                   and p.year = substr(riqi, 0, 4)-1
                  -- and substr(p1.reportdate, 0, 6) <= substr(riqi, 0, 4)-1||'12'
                  )
         group by e.isbn_code,
                  --e.name,
                  ee.code,
                  --ee.name,
                  case
                    when e.division is null then
                     '99'
                    else
                     e.division
                  end,
                  e.enterprisekind,
                  e.paytype,
                  e.enterprisetype,
                  e1.isbn_code,
                  --e1.name,
                  e2.isbn_code,
                  --e2.name,
                  b.tzbm,
                  nvl(b.isbuy, 0)
                  union all
                  ---申拨部分--------
                  select
                  '3306010101' xzqh,
               substr(riqi, 0, 4)-1||'12' ny,
               e.isbn_code dwbm,
               ee.code zgdwbm,
               e.enterprisekind dwxz,
               e.paytype zflx,
               e.enterprisetype dwlx,
               e1.isbn_code zfjjkmbm,
               e2.isbn_code bmjjkmbm,
               g.resourceincode ,
               to_char(nvl(e3.caigou, 0)) iscg,
               nvl(sum(g.sanction), 0) zxs_lj
                  from zjsb.gplandetail g
                  left join zjsb.gplan g1
                  on g.year = g1.year
           and g.gplanid = g1.gplanid
            left join jczl.enterprise e
            on g.enterpriseguid = e.guid
          left join jczl.enterprise ee
            on e.parent_guid = ee.guid
          left join jczl.economysectiongov e1
            on g.zfecosecguid = e1.guid
          left join jczl.economysection e2
            on g.ecosecguid = e2.guid
          left join zjsb.budget bb
            on g.budgetid = bb.budgetid
           and g.resourceincode = bb.resourceincode
          left join zbgl.enterpriseassignquota e3
            on bb.budgetid1 = e3.enterpriseid
            where g1.signed = 1
           and g1.lsname <> -1
           and g1.allostate is not null
           and g.budgetid is not null
           and g.year = substr(riqi, 0, 4)-1
          -- and substr(replace(g1.pfdate, '.', ''),0,6)>=substr(riqi, 0, 4)-1||'12'
           group by
           e.isbn_code,
                  ee.code,
                  case
                    when e.division is null then
                     '99'
                    else
                     e.division
                  end,
                  e.enterprisekind,
                  e.paytype,
                  e.enterprisetype,
                  e1.isbn_code,
                  e2.isbn_code,
                  g.resourceincode,
                  nvl(e3.caigou, 0)
                  ---------
                  ) aa
  left join
-----------当月支出
 (select '3306010101' xzqh,
         substr(riqi, 0, 4)-1||'12' ny,
         e.isbn_code dwbm,
         --e.name dwmc,
         ee.code zgdwbm,
     /*    case
           when e.division is null then
            '99'
           else
            e.division
         end ssgkbm,*/
         e.enterprisekind dwxz,
         e.paytype zflx,
         e.enterprisetype dwlx,
         e1.isbn_code zfjjkmbm,
         --e1.name zfjjkmmc,
         e2.isbn_code bmjjkmbm,
         --e2.name bmjjkmmc,
         b.tzbm,
         nvl(b.isbuy, 0) iscg,
         nvl(sum(b.totalmoney), 0) zxs_dy
             from zfgl.billsdetail b
    left join jczl.enterprise e
      on b.enterpriseguid = e.guid
    left join jczl.enterprise ee
      on e.parent_guid = ee.guid
    left join jczl.economysectiongov e1
      on b.govecoguid = e1.guid
    left join jczl.economysection e2
      on b.economyguid = e2.guid
   where b.year = substr(riqi, 0, 4)-1
     and exists (select *
            from zfgl.payreportdetail p
            left join zfgl.payreport p1
              on p.year = p1.year
             and p.reportid = p1.reportid
             and p.bankcode = p1.bankcode
           where b.year = p.year
             and e.isbn_code = p.exchangecode
             and b.billno = p.newbillno
             and b.tzbm = p1.tzbm
             and p.year = substr(riqi, 0, 4)-1
             and substr(p1.reportdate, 0, 6) = substr(riqi, 0, 4)-1||'12')
   group by e.isbn_code,
            --e.name,
            ee.code,
            case
              when e.division is null then
               '99'
              else
               e.division
            end,
            e.enterprisekind,
            e.paytype,
            e.enterprisetype,
            e1.isbn_code,
           -- e1.name,
            e2.isbn_code,
           -- e2.name,
            b.tzbm,
            nvl(b.isbuy, 0)
            union all
            ---------申拨部分-------
            select
                  '3306010101' xzqh,
               substr(riqi, 0, 4)-1||'12' ny,
               e.isbn_code dwbm,
               ee.code zgdwbm,
               e.enterprisekind dwxz,
               e.paytype zflx,
               e.enterprisetype dwlx,
               e1.isbn_code zfjjkmbm,
               e2.isbn_code bmjjkmbm,
               g.resourceincode ,
               to_char(nvl(e3.caigou, 0)) iscg,
               nvl(sum(g.sanction), 0) zxs_dy
                  from zjsb.gplandetail g
                  left join zjsb.gplan g1
                  on g.year = g1.year
           and g.gplanid = g1.gplanid
            left join jczl.enterprise e
            on g.enterpriseguid = e.guid
          left join jczl.enterprise ee
            on e.parent_guid = ee.guid
          left join jczl.economysectiongov e1
            on g.zfecosecguid = e1.guid
          left join jczl.economysection e2
            on g.ecosecguid = e2.guid
          left join zjsb.budget bb
            on g.budgetid = bb.budgetid
           and g.resourceincode = bb.resourceincode
          left join zbgl.enterpriseassignquota e3
            on bb.budgetid1 = e3.enterpriseid
            where g1.signed = 1
           and g1.lsname <> -1
           and g1.allostate is not null
           and g.budgetid is not null
           and g.year = substr(riqi, 0, 4)-1
           and substr(replace(g1.pfdate, '.', ''),0,6)>=substr(riqi, 0, 4)-1||'12'
           group by
           e.isbn_code,
                  ee.code,
                  case
                    when e.division is null then
                     '99'
                    else
                     e.division
                  end,
                  e.enterprisekind,
                  e.paytype,
                  e.enterprisetype,
                  e1.isbn_code,
                  e2.isbn_code,
                  g.resourceincode,
                  nvl(e3.caigou, 0)
            ------------------------
            ) bb
    on aa.xzqh = bb.xzqh
   and aa.ny = bb.ny
   and aa.dwbm = bb.dwbm
   and nvl(aa.zfjjkmbm,0) = nvl(bb.zfjjkmbm,0)
   and aa.bmjjkmbm = bb.bmjjkmbm
   and aa.tzbm = bb.tzbm
   and aa.iscg = bb.iscg;
   end if;

      ------------------------------------

commit;
end;


procedure GET_CZFX_ZKJ_DYB(riqi varchar2) is
  begin
     delete from CZFX_ZKJ_DYB
       where year in (substr(riqi, 0, 4));
          insert into CZFX_ZKJ_DYB
select l.xzqh,
       l.year,
       l.year || lpad(l.month, 2, '0') || lpad(l.day, 2, '0') pzrq,
       l.year || lpad(l.month, 2, '0') ny,
       l.setid,
       l.voucherno,
       l.line,
       l.summary,
       ''  kjkmid ,   --l.sectionguid,
     case
                 when (select a.zkj
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_KJKM') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_KJKM a1
                    where a1.bm = a.isbn_code)
                    is null then '-1' else
                     (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_KJKM a1
                    where a1.bm = a.isbn_code)
                    end from dual)
                 when (select a2.zkj
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_KJKM') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 2
                      and a3.bmb = 'CZFX_DM_KJKM'
                      and a3.dynf = l.year
                      and a3.dyxzqh = l.xzqh
                      and a3.dybm = a.isbn_code)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 2
                      and a3.bmb = 'CZFX_DM_KJKM'
                      and a3.dynf = l.year
                      and a3.dyxzqh = l.xzqh
                      and a3.dybm = a.isbn_code)
                    end from dual)
                 else
                  '-1'
               end kjkmbm,
           '' kjkmmc,   --a.name,
       '' dwbm,  ---- e.isbn_code,
       ''    dwmc,--e.name,
       '' dwfjbm,  ---ee.code,
      ''  ssks, -- e.division,
      ''  dwxz, --- e.enterprisekind,
      ''  zflx,  --- e.paytype,
      ''  dwlx ,--- e.enterprisetype,
    --  ''  szfl,  --- f.SZTYPE,
     ------收支分类-----
     case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_SZFL') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_SZFL a1
                    where a1.bm = F.SZTYPE)
                    is null then '-1' else
                      (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_SZFL a1
                    where a1.bm = F.SZTYPE)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_SZFL') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_SZFL'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = F.SZTYPE)
                      is null then '-1' else
                        (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_SZFL'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = F.SZTYPE)
                      end from dual)
                 else
                  '-1'
               end szfl,
     -------------------
        case
                 when (select a.zkj
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_GNKM') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_GNKM a1
                    where a1.bm = f.isbn_code)
                    is null then '-1' else
                     (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_GNKM a1
                    where a1.bm = f.isbn_code)
                    end from dual)
                 when (select a2.zkj
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_GNKM') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_GNKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = f.isbn_code)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_GNKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = f.isbn_code)
                      end from dual)
                 else
                  '-1'
               end gnkmbm,
      '' gnkmmc,  --- f.name,
         case
                 when (select a.zkj
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_ZFJJKM') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZFJJKM a1
                    where a1.bm = e1.isbn_code)
                    is null then '-1' else
                    (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZFJJKM a1
                    where a1.bm = e1.isbn_code)
                    end from dual)
                 when (select a2.zkj
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_ZFJJKM') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZFJJKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e1.isbn_code)
                      is null then '-1' else
                       (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZFJJKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e1.isbn_code)
                      end from dual)
                 else
                  '-1'
               end zfjjkmbm,
      '' zfjjkmmc,------ e1.name,
     '' bmjjkmbm,  --e2.isbn_code,
     '' bmjjkmmc,-- e2.name,
     '' xmlbbm,   ---  p.programtypecode,
     '' xmid,  ----  p.guid,
     '' xmmc,---- p.name,
     '' zjlybm,---  l.resourceincode,
       l.debmoney,
       l.cremoney,
       sysdate xgrq
  from V_SX_ADMDIV_LEDGER l
  left join V_SX_ADMDIV_ACCOUNTSECTION a
    on l.year = a.year
   and l.setid = a.setid
   and l.sectionguid = a.guid
   and l.XZQH=a.XZQH
  left join jczl.enterprise e
    on l.enterguid = e.guid
  left join jczl.enterprise ee
    on e.parent_guid = ee.guid
  left join V_SX_ADMDIV_FUNCTIONSECTION f
    on l.functionguid = f.guid and l.XZQH=f.XZQH
  left join jczl.economysectiongov e1
    on l.economygovguid = e1.guid
  left join jczl.economysection e2
    on l.economyguid = e2.guid
  left join jczl.program p
    on l.programguid = p.guid
 where l.year =(substr(riqi, 0, 4));
        commit;
end;

procedure GET_CZFX_ZKJ_BJ(riqi varchar2) is
  begin
     delete from CZFX_ZKJ_BJ
       where year in (substr(riqi, 0, 4));
          insert into CZFX_ZKJ_BJ
select l.xzqh,
       l.year,
       l.year || lpad(l.month, 2, '0') || lpad(l.day, 2, '0') pzrq,
       l.year || lpad(l.month, 2, '0') ny,
       l.setid,
       l.voucherno,
       l.line,
       l.summary,
       ''  kjkmid ,   --l.sectionguid,
     case
                 when (select a.zkj
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_KJKM') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_KJKM a1
                    where a1.bm = a.isbn_code)
                    is null then '-1' else
                     (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_KJKM a1
                    where a1.bm = a.isbn_code)
                    end from dual)
                 when (select a2.zkj
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_KJKM') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 2
                      and a3.bmb = 'CZFX_DM_KJKM'
                      and a3.dynf = l.year
                      and a3.dyxzqh = l.xzqh
                      and a3.dybm = a.isbn_code)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 2
                      and a3.bmb = 'CZFX_DM_KJKM'
                      and a3.dynf = l.year
                      and a3.dyxzqh = l.xzqh
                      and a3.dybm = a.isbn_code)
                    end from dual)
                 else
                  '-1'
               end kjkmbm,
           '' kjkmmc,   --a.name,
       '' dwbm,  ---- e.isbn_code,
       ''    dwmc,--e.name,
       '' dwfjbm,  ---ee.code,
      ''  ssks, -- e.division,
      ''  dwxz, --- e.enterprisekind,
      ''  zflx,  --- e.paytype,
      ''  dwlx ,--- e.enterprisetype,
      ------收支分类-----
     case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_SZFL') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_SZFL a1
                    where a1.bm = F.SZTYPE)
                    is null then '-1' else
                      (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_SZFL a1
                    where a1.bm = F.SZTYPE)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_SZFL') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_SZFL'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = F.SZTYPE)
                      is null then '-1' else
                        (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_SZFL'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = F.SZTYPE)
                      end from dual)
                 else
                  '-1'
               end szfl,
     -------------------
        case
                 when (select a.zkj
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_GNKM') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_GNKM a1
                    where a1.bm = f.isbn_code)
                    is null then '-1' else
                     (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_GNKM a1
                    where a1.bm = f.isbn_code)
                    end from dual)
                 when (select a2.zkj
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_GNKM') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_GNKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = f.isbn_code)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_GNKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = f.isbn_code)
                      end from dual)
                 else
                  '-1'
               end gnkmbm,
      '' gnkmmc,  --- f.name,
         case
                 when (select a.zkj
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_ZFJJKM') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZFJJKM a1
                    where a1.bm = e1.isbn_code)
                    is null then '-1' else
                    (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZFJJKM a1
                    where a1.bm = e1.isbn_code)
                    end from dual)
                 when (select a2.zkj
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_ZFJJKM') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZFJJKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e1.isbn_code)
                      is null then '-1' else
                       (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZFJJKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e1.isbn_code)
                      end from dual)
                 else
                  '-1'
               end zfjjkmbm,
      '' zfjjkmmc,------ e1.name,
     '' bmjjkmbm,  --e2.isbn_code,
     '' bmjjkmmc,-- e2.name,
     '' xmlbbm,   ---  p.programtypecode,
     '' xmid,  ----  p.guid,
     '' xmmc,---- p.name,
     '' zjlybm,---  l.resourceincode,
       l.debmoney,
       l.cremoney,
       sysdate xgrq
  from V_SX_ADMDIV_LEDGER l
  left join V_SX_ADMDIV_ACCOUNTSECTION a
    on l.year = a.year
   and l.setid = a.setid
   and l.sectionguid = a.guid
   and l.XZQH=a.XZQH
  left join jczl.enterprise e
    on l.enterguid = e.guid
  left join jczl.enterprise ee
    on e.parent_guid = ee.guid
  left join V_SX_ADMDIV_FUNCTIONSECTION f
    on l.functionguid = f.guid and l.XZQH=f.XZQH
  left join jczl.economysectiongov e1
    on l.economygovguid = e1.guid
  left join jczl.economysection e2
    on l.economyguid = e2.guid
  left join jczl.program p
    on l.programguid = p.guid
 where l.year =(substr(riqi, 0, 4))
  and l.XZQH='3306010101' ;
        commit;
end;
end pkg_CZFX;
/

