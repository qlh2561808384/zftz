create procedure TMP_TEST
(
  yjgzbm in VARCHAR,  --预警规则编码
  jzfw   in VARCHAR,  --加载范围
  TSDXLX in VARCHAR,  --推送对象类型
  TSDXID in NUMBER,  --推送对象
  result out sys_refcursor
) as pch NUMBER;
begin
  --1，生成批次
  SELECT seq_yjjk_yw_yjsj_pch.nextval into pch from dual;

  open result for
  select (select YJFLBM from yjjk_dm_yjgz yjgz where yjgz.bm= yjgzbm ) YJFLBM,
        yjgzbm YJGZBM,zfmx.dwbm||zfmx.zfsqh YWBM,(select ysdw.dwmc from czfx_dm_ysdw ysdw where ysdw.dwbm=zfmx.dwbm ) YWMC,'1000' LYFS,
         to_char(sysdate, 'yyyy-mm-dd hh24:mi:ss') YJSJ,'单笔支出超出3亿,支付申请号：'||zfmx.zfsqh MS,
        TSDXLX as tsdxlx,TSDXID tsdxid, '0' ZT, pch PCH
        from czfx_jcgc_zfmx zfmx where zfmx.year=2018 and zfmx.zflx=0
        and zfmx.money>=300000000;
end TMP_TEST;
/

