create package pkg_CZFX_DYB is
  procedure GET_CZFX_DYB(riqi varchar2);
end pkg_CZFX_DYB;
/

