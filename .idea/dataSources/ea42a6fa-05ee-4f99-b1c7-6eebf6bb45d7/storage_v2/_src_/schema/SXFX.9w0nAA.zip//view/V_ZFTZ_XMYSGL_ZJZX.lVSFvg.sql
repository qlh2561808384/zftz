create view V_ZFTZ_XMYSGL_ZJZX as
  select t.id_zftz_xm, substr(t.zfrq, 0, 4) year, t1.je--取项目执行登记中，对应合同支付明细
  from ZFTZ_XMZXDJ t, zftz_xmzxdj_zfmx t1
 where t.id = t1.id_zftz_xmzxdj
/

