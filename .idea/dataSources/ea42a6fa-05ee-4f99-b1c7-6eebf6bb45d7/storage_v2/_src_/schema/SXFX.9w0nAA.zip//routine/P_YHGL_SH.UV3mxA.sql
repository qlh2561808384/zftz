create PROCEDURE P_YHGL_SH(
                 gwid      IN  varchar2,
                 yybm      IN  varchar2,
                 v_gwid  OUT VARCHAR2,
                 v_error  OUT VARCHAR2
                 ) IS
v_count number;
v_i number;
v_gwid1 varchar2(1000);
BEGIN
      if yybm='FSZG' then
        /*同时申请非税征管248和249时，拆分成两条记录，推送至jczl*/
       select count(*) into v_count
         from (select regexp_substr(gwid, '[^,]+', 1, rownum) gwid from dual
           connect by rownum <= length(regexp_replace(gwid, '[^,]', null)) + 1) t;
       if v_count=1 then
         v_gwid:=gwid;
       elsif v_count>=2 then
          select count(*) into v_i
         from (select regexp_substr(gwid, '[^,]+', 1, rownum) gwid from dual
           connect by rownum <= length(regexp_replace(gwid, '[^,]', null)) + 1) t
              where t.gwid in (248, 249); 
              if v_i<=1 then 
                 v_gwid:=gwid;
              elsif v_count=2 and v_i=2 then 
                v_gwid:=replace(gwid,',',' ');
                else
                select listagg(gwid,',') within group(order by gwid) gwid into v_gwid from 
                 (select * from (select regexp_substr(gwid, '[^,]+', 1, rownum) gwid from dual
                  connect by rownum <= length(regexp_replace(gwid, '[^,]', null)) + 1) t
                  where t.gwid not in (248, 249))aa ;
                  v_gwid:='248,'||v_gwid||' '||'249,'||v_gwid;
                  end if;
              end if;
          elsif yybm='ZFCG' then 
          /*同时申请政府采购221和222在不能同时申请，在存储过程P_YHGL_BCYZ中已经校验，
          主管单位可以同时申请政府采购单位经办、单位审核、主管单位经办、主管单位审核，
          但是推送至jczl时岗位需要拆分成两个用户名*/
         select count(*) into v_count
         from (select regexp_substr(gwid, '[^,]+', 1, rownum) gwid from dual
           connect by rownum <= length(regexp_replace(gwid, '[^,]', null)) + 1) t;
       if v_count=1 then
         v_gwid:=gwid;
       elsif v_count>=2 then
          select count(*) into v_i
         from (select regexp_substr(gwid, '[^,]+', 1, rownum) gwid from dual
           connect by rownum <= length(regexp_replace(gwid, '[^,]', null)) + 1) t
              where t.gwid in (221,222); 
              if v_i=0 then 
                 v_gwid:=gwid;
                 elsif v_i=1 then 
                select listagg(gwid,',') within group(order by gwid) gwid into v_gwid1 from 
                 (select * from (select regexp_substr(gwid, '[^,]+', 1, rownum) gwid from dual
                  connect by rownum <= length(regexp_replace(gwid, '[^,]', null)) + 1) t
                  where t.gwid in (221,222))aa;
              select listagg(gwid,',') within group(order by gwid) gwid into v_gwid from 
                 (select * from (select regexp_substr(gwid, '[^,]+', 1, rownum) gwid from dual
                  connect by rownum <= length(regexp_replace(gwid, '[^,]', null)) + 1) t
                  where t.gwid not in (221,222))aa;
                   v_gwid:=v_gwid1||' '||v_gwid;
              
                  end if;
              end if;
          --------------------------
            
          else --yybm='JZZF' then
              v_gwid:=gwid;
         end if;
Dbms_output.put_line(v_gwid);
Dbms_output.put_line(v_error);
end P_YHGL_SH;
/

