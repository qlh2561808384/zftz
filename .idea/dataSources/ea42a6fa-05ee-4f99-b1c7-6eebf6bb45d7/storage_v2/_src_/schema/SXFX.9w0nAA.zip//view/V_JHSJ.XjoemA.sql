create view V_JHSJ as
  select d.zdbm,e.zdbm bm,d.cybm,d.sx, case when  instr(d.fh,'-')>0 then '-' else '+' end fh,d.guid  from (
SELECT  zdbm,REGEXP_SUBSTR(replace(replace(replace(zdycygs,'{',''),'+',''),'-',''), '[^}]+', 1, lv) bm,cybm,sx,guid,REGEXP_SUBSTR(replace(zdycygs,'{',''), '[^}]+', 1, lv) fh
  FROM dn_jh c, (SELECT LEVEL lv FROM dual CONNECT BY LEVEL < 100) b
 WHERE b.lv <= REGEXP_COUNT(c.zdycygs, '\}') + 1
/* and    guid ='4E192AC1-7962-4974-AD31-8C8FB6107E5C'*/ and jsbj=0 and zdycybj=1) d left join dn_jh e
 on d.guid=e.guid and d.bm=e.cm
 where d.bm is not null
 union all
 select zdbm,zdbm bm,cybm,sx,'+' fh,c.guid from dn_jh c where /*c.guid ='4E192AC1-7962-4974-AD31-8C8FB6107E5C' and*/ c.jsbj=0 and zdycybj=0
order by sx
/

