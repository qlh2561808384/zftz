create view V_ZFTZ_XMYSGL_ZJQK as
  select nvl(aa.id_zftz_xm,bb.id_zftz_xm) id_zftz_xm,nvl(aa.nd,bb.year)year,aa.ysap_je,bb.zjdw_je,bb.zjzx_je from
(select id_zftz_xm,nd,sum(ysap_je) ysap_je from v_zftz_xmysgl_ysap group by id_zftz_xm,nd) aa
full join
(select a.id_zftz_xm,nvl(a.year,b.year) year,a.zjdw_je,b.zjzx_je from
(select id_zftz_xm,year,sum(money) zjdw_je from v_zftz_xmysgl_zjdw group by id_zftz_xm,year)a
full join
(select id_zftz_xm,year,sum(je) zjzx_je from v_zftz_xmysgl_zjzx group by id_zftz_xm,year)b
on a.id_zftz_xm=b.id_zftz_xm and a.year=b.year) bb
on aa.id_zftz_xm=bb.id_zftz_xm and aa.nd=bb.year
/

