create view V_JC_VV_ZBFCG1 as
  select a_datakey,b_datakey,DIVID,
ZFJJKM,
ZFJJKMMC,
PROJECTID,
ZBID,
PROJTYPEID,
PROJECTNO,
/*PROJECTNAME,
PROJECTNAME1,*/
GMFWBZ,
ISBUYCATALOG,
PROJFLAG_PROJ,
ACCTCODE,
SFDFPXM,
D_SBWH,
ACCTCODE_JJ,
CURRENTYEAR,
C00,
CE012,
CE013,
CE015,
CE016,
CE017,
CE008,
CE011,
CE003,
CE004,
CE005,
CE006,
CE007,
CE009,
CE028,
CE026,
CE025,
CE027,
CGLXDM,
CGLXMC,
CGMLDM,
CGMLMC,
CGSL,
JLDW9249,
JSCSJPZBZ,
decode(GMFWBZ,'1','zg'||projectname1,projectname1)projectname1,
decode(GMFWBZ,'1','zg'||projectname,projectname)projectname from
(select a_datakey,b_datakey,divid,   case when divid in ( select divid from efm_tra_zjsx_2018.bas_t_dysdwsxb where d_dwxz in ('F0917CEEE75240568BBF0F13AEA164CD','6B5AA03D688F4F9E9C5655679D66072D')）or
         divid in ('C5B4F721506A40F48E976BE93FC83DB6','E6BB8D85A9E8427DBDC7D38B74D366EF','D49E13CDB7E64000A061EFA7254DC7D6','3E3A0A8F23044FFFB67313F3CB5E8991') then
         efm_tra_zjsx_2018.f_getzfjgjjkm(acctcode_jj) else efm_tra_zjsx_2018.f_getzfsyjjkm(acctcode_jj) end as    zfjjkm,
          case when divid in ( select divid from efm_tra_zjsx_2018.bas_t_dysdwsxb where d_dwxz in ('F0917CEEE75240568BBF0F13AEA164CD','6B5AA03D688F4F9E9C5655679D66072D')）or
         divid in ('C5B4F721506A40F48E976BE93FC83DB6','E6BB8D85A9E8427DBDC7D38B74D366EF','D49E13CDB7E64000A061EFA7254DC7D6','3E3A0A8F23044FFFB67313F3CB5E8991') then
       efm_tra_zjsx_2018.f_getzfjgjjkmmc(acctcode_jj) else efm_tra_zjsx_2018.f_getzfsyjjkmmc(acctcode_jj) end as    zfjjkmmc,
PROJECTID,efm_tra_zjsx_2018.getyear()||projectid zbid,
PROJTYPEID,
PROJECTNO,
PROJECTNAME, case when ce017>0 and d_sbwh is not null then PROJECTNAME|| '-'||d_sbwh else PROJECTNAME end projectname1,
 (case when (projectid,acctcode_jj) in (select projectid ,acct from efm_tra_zjsx_2018.AA_V_GMFWJL)
/*              and divid not in (select divid from efm_t_division where fisctype='04')-------非上线采购单位
*/         then '1' else '0' end) as GMFWBZ,'0' as isbuycatalog,projflag_proj,
ACCTCODE,
SFDFPXM,
D_SBWH,
ACCTCODE_JJ,
CURRENTYEAR,
C00,
CE012,
CE013,
CE015,
CE016,
CE017,
CE008,
CE011,
CE003,
CE004,
CE005,
CE006,
CE007,
CE009,
CE028,
CE026,
CE025,
CE027,null as cglxdm,null as cglxmc,null cgmldm,null cgmlmc,0 as cgsl ,null JLDW9249,null JSCSJPZBZ from v_jc_vv_zbfcg
union all
---采购部分
select a_datakey,b_datakey,
divid,   case when divid in ( select divid from efm_tra_zjsx_2018.bas_t_dysdwsxb where d_dwxz in ('F0917CEEE75240568BBF0F13AEA164CD','6B5AA03D688F4F9E9C5655679D66072D')）or
         divid in ('C5B4F721506A40F48E976BE93FC83DB6','E6BB8D85A9E8427DBDC7D38B74D366EF','D49E13CDB7E64000A061EFA7254DC7D6','3E3A0A8F23044FFFB67313F3CB5E8991') then
         efm_tra_zjsx_2018.f_getzfjgjjkm(acctcode_jj) else efm_tra_zjsx_2018.f_getzfsyjjkm(acctcode_jj) end as    zfjjkm,
          case when divid in ( select divid from efm_tra_zjsx_2018.bas_t_dysdwsxb where d_dwxz in ('F0917CEEE75240568BBF0F13AEA164CD','6B5AA03D688F4F9E9C5655679D66072D')）or
         divid in ('C5B4F721506A40F48E976BE93FC83DB6','E6BB8D85A9E8427DBDC7D38B74D366EF','D49E13CDB7E64000A061EFA7254DC7D6','3E3A0A8F23044FFFB67313F3CB5E8991') then
       efm_tra_zjsx_2018.f_getzfjgjjkmmc(acctcode_jj) else efm_tra_zjsx_2018.f_getzfsyjjkmmc(acctcode_jj) end as    zfjjkmmc,projectid,efm_tra_zjsx_2018.getyear()||projectid zbid,projtypeid,projectno,projectname,projectname1, (case when (projectid,acctcode_jj) in (select projectid ,acct from efm_tra_zjsx_2018.AA_V_GMFWJL)
/*              and divid not in (select divid from efm_t_division where fisctype='04')-------非上线采购单位
*/         then '1' else '0' end) as GMFWBZ,'1' as isbuycatalog,projflag_proj,acctcode,SFDFPXM,D_SBWH,ACCTCODE_JJ,CURRENTYEAR,ZJ2392,YSNHBXJ,JFBKBZ,YSNJJTZ,NRYSGLDXZSYXSFSR,SJCXJFBZ,ZFXJJYSBK,SYDWZHHBDYSWZJSR,

SYSRBHZHHBZJ,SYDWJYSR,SJBZSRFCZZHHB,FSDWSJSRFCZZHHB,QTSR7500,YSYJJMBSZCE,D_YBGGYSJZ,D_ZFXJJYSBKJZ,D_ZXJZ,D_QTJYJZ,
decode(SFZFJZCG,'D5F011451BAA492B9A6A650EBEE2BD64','2','1')cglxdm,decode(SFZFJZCG,'D5F011451BAA492B9A6A650EBEE2BD64','集中采购','分散采购')cglxmc,CGMLDM,CGMLmc,SL0514,JLDW9249, JSCSJPZBZ from v_jc_VB_04BGT_T_ZFCGYSB_A
       where  divid in (select divid from efm_tra_zjsx_2018.efm_t_division where fisctype='04'))tt
    /

