create trigger GET_TDCB_XXB_ID
  before insert
  on TDCB_XXB
  for each row
  declare
  NEXT_ID number;
begin
  select SEQ_TDCB_XXB.NEXTVAL into NEXT_ID from dual;
  :NEW.ID:=NEXT_ID;
end get_tdcb_xxb_id;
/

