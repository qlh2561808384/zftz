create view V_JCZL_DIVISION as
  select t.guid bm,t.remark deptid, t.name mc,'0' fjbm,'Y' yxbz
  from jczl.division t
 where t.enabled = 1
   --and t.isdeptmandiv = 1
 order by t.dorder
/

