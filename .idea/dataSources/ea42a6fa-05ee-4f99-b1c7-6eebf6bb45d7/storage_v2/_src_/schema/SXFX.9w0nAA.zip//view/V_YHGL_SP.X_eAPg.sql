create view V_YHGL_SP as
  SELECT YHGLDB.YWXTBM, YHGLDB.CODE, YHGLDB.SL
  FROM (SELECT 'key' AS ZJ,
               '2' AS DBLX,
               'YHGL' AS YWXTBM,
               '绍兴市财税局' AS DWMC,
               B.YHZH AS CODE,
               COUNT(*) AS SL,
               '待办事项' AS BTNR,
               'http://172.23.205.169/sjgl/login_cas.jsp' AS LJDZ,
               '数据分析' AS DDDLDZ,
               SYSDATE AS QSSJ
          FROM (SELECT DISTINCT W.YHZH, F.GUID
                  FROM YHGL_YW_YHYYSQ   Y,
                       YHGL_YW_YHYYSQFB F,
                       YHGL_DM_YYSPLC   Z,
                       YHGL_GG_RYQZYH   R,
                       XTGL_DM_YY       D,
                       YHGL_YW_YHYY     W
                 WHERE Y.GUID = F.SQDID
                   AND F.DQHJBM = Z.DQHJBM
                   AND F.DQHJBM != '0'
                   AND F.DQHJBM != '-99'
                   AND F.YYID = Z.SSYYID
                   AND F.ZT = '1'
                   AND F.YYID = D.GUID
                   AND Z.SPRFZID = R.QZID
                   AND D.DQBB = Z.DQBB
                   AND Y.YHLX = Z.TYPE
                   AND F.LX != '2'

                   AND EXISTS (SELECT 1
                          FROM YHGL_GG_RYQZYH V
                         WHERE F.GUID = V.YWID
                           AND V.YHID = W.GUID)) B
         GROUP BY B.YHZH) YHGLDB
/

