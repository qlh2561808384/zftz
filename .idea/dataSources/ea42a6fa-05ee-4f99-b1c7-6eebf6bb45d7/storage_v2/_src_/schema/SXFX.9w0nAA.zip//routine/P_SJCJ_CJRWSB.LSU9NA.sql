create procedure P_SJCJ_CJRWSB(cjrwid in VARCHAR2, --采集任务ID
                                          rwmxid in VARCHAR2, --采集任务明细ID
                                          sfsb out VARCHAR2) is --是否上报0否1是
mxnum int;
begin
     sfsb := '1' ;--每个采集任务默认为1，表示无需判断是否填报都可以提交
     if cjrwid= '241' then --表示该采集任务id需判断实际的表中单位是否填报过，0未填报，1已填报
        select case when count(*)=0 then  '0' else '1' end into mxnum from sjcj_rw_mx where id=rwmxid;
      sfsb :=mxnum;
     end if;
     if cjrwid= '244' then --表示该采集任务id需判断实际的表中单位是否填报过，0未填报，1已填报
        select case when count(*)=0 then  '0' else '1' end into mxnum from sjcj_rw_mx where id=rwmxid;
      sfsb :=mxnum;
     end if;
     if cjrwid='421' then 
       sfsb := 1;
       end if;
       
Dbms_output.put_line(sfsb);
end P_SJCJ_CJRWSB;
/

