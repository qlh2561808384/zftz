create view V_TDCB_DLXX_ZQQK as
  select a.bm,a.mc,nvl(b.gs,0) gs,nvl(b.mj,0) mj,nvl(b.jsy,0) jsy from tdcb_xxb a left join
(select t.zqqk,count(*) gs,sum(t.tdmj) mj,sum(t.jsy) jsy from V_TDCB_DLXX_XMZT t group by t.zqqk ) b
on a.bm=b.zqqk where a.lx='zqqk' and a.bm<>99
/

