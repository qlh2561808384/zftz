create view VIEW_ZC_JK as
  select "CZCDBH","CMXXMMC","DDATE","IJE","CMEMO","DSHDATE","CGKKM","CZCGKKMNAME","CDKBM","CDKMC","CKMBM","CKMNAME" from land.view_zc_jk@tbview
/

