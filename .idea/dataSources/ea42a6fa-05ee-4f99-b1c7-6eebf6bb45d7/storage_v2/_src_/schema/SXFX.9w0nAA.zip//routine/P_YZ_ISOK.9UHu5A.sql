create PROCEDURE P_YZ_ISOK(
                 gwid      IN  varchar2,
                 yybm      IN  varchar2,
                 v_isok  OUT VARCHAR2,
                 v_error  OUT VARCHAR2
                 ) IS
v_count number;
BEGIN
      v_isok:='1';
      if yybm='JZZF' then
        select count(*) into v_count from YHGL_DM_YYGW t where ssyybm='JZZF' and t.gwlx='2' 
        and t.guid in(select regexp_substr(gwid, '[^,]+', 1, rownum) gwid 
                        from dual connect by rownum <=length(regexp_replace(gwid, '[^,]', null)) + 1);
       if v_count>=2 then
         v_isok:='2';
         v_error:='岗位冲突(集中支付，不能同时是会计和出纳)';
         else
           v_isok:='1';
            end if;
      end if;


Dbms_output.put_line(v_isok);
Dbms_output.put_line(v_error);
end P_YZ_ISOK;
/

