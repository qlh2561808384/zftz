create trigger TIGGER_MHDP_JXKH
  before insert
  on V_DP_JXKH
  for each row
  when (NEW.id IS NULL)
  BEGIN
    SELECT SEQ_MHDP_JXKH.Nextval INTO:NEW.id FROM DUAL;
END;
/

