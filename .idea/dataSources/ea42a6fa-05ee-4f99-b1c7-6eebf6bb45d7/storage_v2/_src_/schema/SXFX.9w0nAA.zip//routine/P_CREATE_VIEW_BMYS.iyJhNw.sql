create procedure p_create_view_bmys(VC_ERRMSG_O OUT VARCHAR2 ) is
  TYPE CUR IS REF CURSOR;
  V_SQL   clob;
  M_SQL   VARCHAR2(4000);
  COL_SQL   VARCHAR2(4000);
  DYCOL_SQL VARCHAR2(4000);
  X       number;
  NOWYEAR number;
  CUR_TEXT  CUR;
  CUR_COLUMN  CUR;
  U_ISHAVE  NUMBER;
  U_COLUMN VARCHAR2(200);
  U_BM   VARCHAR2(200);
  U_MC   VARCHAR2(200);
  U_DYBM   VARCHAR2(200);
  U_YXRQ   VARCHAR2(200);
  U_SXRQ   VARCHAR2(200);
  E_ALREADY_CARRY EXCEPTION;
BEGIN

  
  M_SQL := 'select bm,mc,dybm,yxrq,sxrq  from CZFX_DM_ZDYJHMX where DYID in (select id  from CZFX_DM_ZDYJH where jhmc =''部门预算编制视图'' )  ';
  OPEN CUR_TEXT FOR M_SQL;
  LOOP
    FETCH CUR_TEXT
        INTO U_BM, U_MC, U_DYBM,U_YXRQ,U_SXRQ;
 EXIT WHEN CUR_TEXT%NOTFOUND;
  ------参数初始化部分------
  X:= 2016;
  NOWYEAR := TO_NUMBER(to_char(sysdate, 'yyyy'));
  if( to_number(substr(U_YXRQ,1,4))>to_number(substr(U_SXRQ,1,4))) then
  continue; 
  end if;
  if(to_number(substr(U_YXRQ,1,4))>NOWYEAR) then
  continue; 
  end if;
  if(to_number(substr(U_SXRQ,1,4))<X) then
  continue; 
  end if;
  
  IF (X<to_number(substr(U_YXRQ,1,4))) THEN
    X:=to_number(substr(U_YXRQ,1,4));
    END IF;
    IF (NOWYEAR>to_number(substr(U_SXRQ,1,4))) THEN
       X:=to_number(substr(U_SXRQ,1,4));
       END IF;
   ---------------------------
   COL_SQL:='select COLUMN_NAME from all_tab_columns  where owner='''||upper(replace( substr(U_DYBM,0,instr(U_DYBM,'.',1)-1),'{year}',NOWYEAR))||''' and table_name= '''||upper( substr(U_DYBM,instr(U_DYBM,'.',1)+1,length(U_DYBM)) )||''' order by column_id';

 --  OPEN CUR_COLUMN FOR
     V_SQL := 'create or replace view '||U_MC||' as ';
     
  WHILE X < NOWYEAR + 1 LOOP
    
     
    V_SQL := V_SQL || 'select ' || X || ' nd,';
       IF CUR_COLUMN%ISOPEN THEN
    CLOSE CUR_COLUMN;
    end if;
   open CUR_COLUMN for COL_SQL;
  LOOP
    FETCH CUR_COLUMN INTO U_COLUMN;
    EXIT WHEN CUR_COLUMN%NOTFOUND;
    
    /*DYCOL_SQL :='select count(*) from all_tab_columns  where owner='''||upper(replace( substr(U_DYBM,0,instr(U_DYBM,'.',1)-1),'{year}',X))||''' and table_name='''|| upper( substr(U_DYBM,instr(U_DYBM,'.',1)+1,length(U_DYBM)) )||'''and COLUMN_NAME in ( 
     select COLUMN_NAME from all_tab_columns  where owner='''||upper(replace( substr(U_DYBM,0,instr(U_DYBM,'.',1)-1),'{year}',NOWYEAR))||''' and table_name='''|| upper( substr(U_DYBM,instr(U_DYBM,'.',1)+1,length(U_DYBM)) )||''' AND COLUMN_NAME='''|| U_COLUMN ||''')';
*/
  DYCOL_SQL :='select count(*) from all_tab_columns  where owner='''||upper(replace( substr(U_DYBM,0,instr(U_DYBM,'.',1)-1),'{year}',X))||''' and table_name='''|| upper( substr(U_DYBM,instr(U_DYBM,'.',1)+1,length(U_DYBM)) )||'''and COLUMN_NAME ='''|| U_COLUMN ||'''';
 
 
     execute immediate DYCOL_SQL INTO U_ISHAVE;
    
    IF (U_ISHAVE=0) THEN
      V_SQL := V_SQL||'NULL '||U_COLUMN||',';
       else
      V_SQL := V_SQL||U_COLUMN||',';
    
    END IF;
    
    END LOOP;
      V_SQL := substr(V_SQL,0,length(V_SQL)-1);
     V_SQL:=V_SQL||' from '|| replace(U_DYBM,'{year}',X)  ||' t 
';
    if (X < NOWYEAR) then
      V_SQL := V_SQL || 'union all 
';
      -- else  V_SQL:=V_SQL||';';
    end if;
    X := X + 1;
  END LOOP;
  --bbb :=V_SQL;
  execute immediate V_SQL;
  
  END LOOP;
 if CUR_TEXT%isopen then
        close CUR_TEXT;
        end if;
         if CUR_TEXT%isopen then
        close CUR_COLUMN;
        end if;

  RAISE E_ALREADY_CARRY;
  
  
  

  ------异常部分------
    EXCEPTION
    WHEN E_ALREADY_CARRY THEN
      VC_ERRMSG_O := '已经按照定版的库自动创建视图和更新视图结构!';
     -- COMMIT;
    WHEN OTHERS THEN
      if CUR_TEXT%isopen then
        close CUR_TEXT;
        end if;
         if CUR_TEXT%isopen then
        close CUR_COLUMN;
        end if;
      VC_ERRMSG_O := U_MC||'视图创建失败！，具体原因：'||SUBSTR(SQLERRM, 1, 6000);
      --  ROLLBACK;
  --------------------
  
  
END p_create_view_bmys;
/

