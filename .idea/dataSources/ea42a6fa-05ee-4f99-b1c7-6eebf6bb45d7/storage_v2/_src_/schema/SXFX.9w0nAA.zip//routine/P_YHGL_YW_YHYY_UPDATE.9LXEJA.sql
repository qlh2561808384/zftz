create PROCEDURE P_YHGL_YW_YHYY_UPDATE
                
                  IS
v_count number;

BEGIN
  insert into yhgl_yw_yhyy
  select '',t.yhid,10,'1','',sysdate,1,1,t.yhzh,t.szdwid,'YHGL',t.ssyybm,t.yhmm,t.ssgkcs,t.regicode,t.clsj,t.sfcl 
  from yhgl_yw_yhyy t where t.yybm in ('YSDWFWPT','CZDSJ') and not exists
  (select * from yhgl_yw_yhyy t1 where t1.yybm='YHGL' and t.yhzh=t1.yhzh );
  
  delete from  yhgl_yw_yhyy t where t.yyid=10 and to_char(t.cjsj,'yyyymmdd')>=20181208
   and not exists (select * from yhgl_yw_yhyy t1 where t1.yybm in ('YSDWFWPT','CZDSJ') and t.yhzh=t1.yhzh);
   commit;
end P_YHGL_YW_YHYY_UPDATE;
/

