create package pkg_CZFX_ZKJ is
  procedure GET_CZFX_ZKJ_BJ(riqi varchar2);
  procedure GET_CZFX_JCGC_ZKJPZ(riqi varchar2);
end pkg_CZFX_ZKJ;
/

