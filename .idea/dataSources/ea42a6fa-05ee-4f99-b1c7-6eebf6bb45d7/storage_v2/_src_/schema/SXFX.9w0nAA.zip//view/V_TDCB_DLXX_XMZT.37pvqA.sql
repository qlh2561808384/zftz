create view V_TDCB_DLXX_XMZT as
  select a.id,
       a.xmid,
       (select x.ssxzqy from tdcb_xmdj x where x.xmid=a.xmid) ssxzyh,
       a.tdmj,
       a.sjcrje,
       a.yqtdsr,
       b.sccb,
       nvl(a.yqtdsr,0)-nvl(b.sccb,0) jsy,--净收益
       c.xmzt,--项目状态
       case
         when a.sjcrje = 0 then
          '01'
         when a.yqtdsr >= nvl(b.sccb, 0) then
          '02'
         when a.yqtdsr <= nvl(b.sccb, 0) then
          '03'
       end zqqk, --债券情况
       'TDCB' yybm
  from tdcb_dkxx a
  left join (select t.dkxxid, sum(t.je) sccb
               from v_tdcb_sccb t
              group by t.dkxxid) b
    on a.id = b.dkxxid,tdcb_xmdj c
    where a.xmid=c.xmid and c.xmzt<>99
/

