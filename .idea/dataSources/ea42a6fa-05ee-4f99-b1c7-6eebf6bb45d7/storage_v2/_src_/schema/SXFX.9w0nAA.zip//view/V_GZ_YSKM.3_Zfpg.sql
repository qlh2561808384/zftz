create view V_GZ_YSKM as
  select t.bm id,t.bm,t.mc,t.fjbm,lower(t.yxbz) yxbz,'' bz from czfx_dm_gnkm t where t.bm like '10306%' and t.yxbz='Y'
/

