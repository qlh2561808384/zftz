create package body pkg_CZFX_DYB is
---------------------电月报----------------------------------
 procedure GET_CZFX_DYB(riqi varchar2) is

  begin
    delete  from CZFX_DYB t where t.ny=substr(riqi,0,6);
    insert into CZFX_DYB
SELECT t.ny,
       ---部门编码转换为行政区划----------------
       case
         when (select a.dyb from czfx_dm_bmbqd a where a.bmb = 'CZFX_DM_XZQH') = 1 then
          (select case
                    when (select case
                                   when a1.bm is null then
                                    '-1'
                                   else
                                    a1.bm
                                 end
                            from CZFX_DM_XZQH a1
                           where a1.bm = t.bmbm) is null then
                     '-1'
                    else
                     (select case
                               when a1.bm is null then
                                '-1'
                               else
                                a1.bm
                             end
                        from CZFX_DM_XZQH a1
                       where a1.bm = t.bmbm)
                  end
             from dual)
         when (select a2.dyb
                 from czfx_dm_bmbqd a2
                where a2.bmb = 'CZFX_DM_XZQH') = 2 then
          (select case
                    when (select case
                                   when a3.bm is null then
                                    '-1'
                                   else
                                    a3.bm
                                 end
                            from czfx_dm_dygx a3
                           where a3.dyly = 5
                             and a3.bmb = 'CZFX_DM_XZQH'
                             and a3.dynf = 0
                             and a3.dyxzqh = 0
                             and a3.dybm = t.bmbm) is null then
                     '-1'
                    else
                     (select case
                               when a3.bm is null then
                                '-1'
                               else
                                a3.bm
                             end
                        from czfx_dm_dygx a3
                       where a3.dyly = 5
                         and a3.bmb = 'CZFX_DM_XZQH'
                         and a3.dynf = 0
                         and a3.dyxzqh = 0
                         and a3.dybm = t.bmbm)
                  end
             from dual)
         else
          '-1'
       end XZQH,
       -------------------------
       --t.bmbm,
       ----收支分类转换------------------------
       case
         when (select a.dyb from czfx_dm_bmbqd a where a.bmb = 'CZFX_DM_SZFL') = 1 then
          (select case
                    when (select case
                                   when a1.bm is null then
                                    '-1'
                                   else
                                    a1.bm
                                 end
                            from CZFX_DM_SZFL a1
                           where a1.bm = t.szlxbj) is null then
                     '-1'
                    else
                     (select case
                               when a1.bm is null then
                                '-1'
                               else
                                a1.bm
                             end
                        from CZFX_DM_SZFL a1
                       where a1.bm = t.szlxbj)
                  end
             from dual)
         when (select a2.dyb
                 from czfx_dm_bmbqd a2
                where a2.bmb = 'CZFX_DM_SZFL') = 2 then
          (select case
                    when (select case
                                   when a3.bm is null then
                                    '-1'
                                   else
                                    a3.bm
                                 end
                            from czfx_dm_dygx a3
                           where a3.dyly = 5
                             and a3.bmb = 'CZFX_DM_SZFL'
                             and a3.dynf = 0
                             and a3.dyxzqh = 0
                             and a3.dybm = t.szlxbj) is null then
                     '-1'
                    else
                     (select case
                               when a3.bm is null then
                                '-1'
                               else
                                a3.bm
                             end
                        from czfx_dm_dygx a3
                       where a3.dyly = 5
                         and a3.bmb = 'CZFX_DM_SZFL'
                         and a3.dynf = 0
                         and a3.dyxzqh = 0
                         and a3.dybm = t.szlxbj)
                  end
             from dual)
         else
          '-1'
       end szfl,

       ----------------------------------
       -- t.szlxbj,
       case
         when t.yskmbm = '10104+10105' then
          '10104'
         when (select a.jcgc
                 from czfx_dm_bmbqd a
                where a.bmb = 'CZFX_DM_GNKM') = 1 then
          (select case
                    when (select case
                                   when a1.bm is null then
                                    '-1'
                                   else
                                    a1.bm
                                 end
                            from CZFX_DM_GNKM a1
                           where a1.bm = t.yskmbm) is null then
                     '-1'
                    else
                     (select case
                               when a1.bm is null then
                                '-1'
                               else
                                a1.bm
                             end
                        from CZFX_DM_GNKM a1
                       where a1.bm = t.yskmbm)
                  end
             from dual)
         when (select a2.jcgc
                 from czfx_dm_bmbqd a2
                where a2.bmb = 'CZFX_DM_GNKM') = 2 then
          (select case
                    when (select case
                                   when a3.bm is null then
                                    '-1'
                                   else
                                    a3.bm
                                 end
                            from czfx_dm_dygx a3
                           where a3.dyly = 0
                             and a3.bmb = 'CZFX_DM_GNKM'
                             and a3.dynf = 0
                             and a3.dyxzqh = 0
                             and a3.dybm = t.yskmbm) is null then
                     '-1'
                    else
                     (select case
                               when a3.bm is null then
                                '-1'
                               else
                                a3.bm
                             end
                        from czfx_dm_dygx a3
                       where a3.dyly = 5
                         and a3.bmb = 'CZFX_DM_GNKM'
                         and a3.dynf = 0
                         and a3.dyxzqh = 0
                         and a3.dybm = t.yskmbm)
                  end
             from dual)
         else
          '-1'
       end gnkmbm,
       t.sjflbm,
       t.je nlj_je,
       '' ylj_je,
       sysdate
  FROM sjck.gk_hz_czyssz t
 where (t.yskmbm like '1%' or t.yskmbm like '2%')
   and t.yskmbm not like '1010103+1010105'
   and t.bmbm in ('00901290061',
                  '00901290069006',
                  '00901290069001',
                  '00901290069002',
                  '00901290069004',
                  '00901290069005',
                  '00901290069003')
      --and t.bmbm='0090129006'
      --and t.szlxbj=1
   and t.ny = substr(riqi, 0, 6);

    commit;
     --根据预算科目长度逐层递减
    ----更新gnkmbm=7的节点--
    update  CZFX_DYB t
set t.nlj_je=(
select t.nlj_je-aa.nlj_je from
(select t1.ny,t1.xzqh,t1.szfl,t1.sjflbm,substr(t1.gnkmbm,0,7) gnkmbm ,
nvl(sum(t1.nlj_je),0) nlj_je from CZFX_DYB t1
where (t1.gnkmbm like '1%' or t1.gnkmbm like '2%') and t1.gnkmbm not like '1010103+1010105'
and length(t1.gnkmbm)=9 group by t1.ny,t1.xzqh,t1.szfl,t1.sjflbm,substr(t1.gnkmbm,0,7)
having nvl(sum(t1.nlj_je),0)<>0) aa where t.ny=aa.ny and t.xzqh=aa.xzqh and t.szfl=aa.szfl
and t.gnkmbm=aa.gnkmbm and t.sjflbm=aa.sjflbm
)
where (t.gnkmbm like '1%' or t.gnkmbm like '2%') and t.gnkmbm not like '1010103+1010105'
and length(t.gnkmbm)=7 and t.ny=substr(riqi,0,6) and exists
(select * from
(select t1.ny,t1.xzqh,t1.szfl,t1.sjflbm,substr(t1.gnkmbm,0,7) gnkmbm ,
nvl(sum(t1.nlj_je),0) nlj_je from CZFX_DYB t1
where (t1.gnkmbm like '1%' or t1.gnkmbm like '2%') and t1.gnkmbm not like '1010103+1010105'
and length(t1.gnkmbm)=9 group by t1.ny,t1.xzqh,t1.szfl,t1.sjflbm,substr(t1.gnkmbm,0,7)
having nvl(sum(t1.nlj_je),0)<>0) aa where t.ny=aa.ny and t.xzqh=aa.xzqh and t.szfl=aa.szfl
and t.gnkmbm=aa.gnkmbm and t.sjflbm=aa.sjflbm);
commit;
    ----更新gnkmbm=5的节点--
    update  CZFX_DYB t
set t.nlj_je=(
select t.nlj_je-aa.nlj_je from
(select t1.ny,t1.xzqh,t1.szfl,t1.sjflbm,substr(t1.gnkmbm,0,5) gnkmbm ,
nvl(sum(t1.nlj_je),0) nlj_je from CZFX_DYB t1
where (t1.gnkmbm like '1%' or t1.gnkmbm like '2%') and t1.gnkmbm not like '1010103+1010105'
and length(t1.gnkmbm)>=7 group by t1.ny,t1.xzqh,t1.szfl,t1.sjflbm,substr(t1.gnkmbm,0,5)
having nvl(sum(t1.nlj_je),0)<>0) aa where t.ny=aa.ny and t.xzqh=aa.xzqh and t.szfl=aa.szfl
and t.gnkmbm=aa.gnkmbm and t.sjflbm=aa.sjflbm
)
where (t.gnkmbm like '1%' or t.gnkmbm like '2%') and t.gnkmbm not like '1010103+1010105'
and length(t.gnkmbm)=5 and t.ny=substr(riqi,0,6) and exists
(select * from
(select t1.ny,t1.xzqh,t1.szfl,t1.sjflbm,substr(t1.gnkmbm,0,5) gnkmbm ,
nvl(sum(t1.nlj_je),0) nlj_je from CZFX_DYB t1
where (t1.gnkmbm like '1%' or t1.gnkmbm like '2%') and t1.gnkmbm not like '1010103+1010105'
and length(t1.gnkmbm)>=7 group by t1.ny,t1.xzqh,t1.szfl,t1.sjflbm,substr(t1.gnkmbm,0,5)
having nvl(sum(t1.nlj_je),0)<>0) aa where t.ny=aa.ny and t.xzqh=aa.xzqh and t.szfl=aa.szfl
and t.gnkmbm=aa.gnkmbm and t.sjflbm=aa.sjflbm);
commit;
  ----更新gnkmbm=3的节点--
    update  CZFX_DYB t
set t.nlj_je=(
select t.nlj_je-aa.nlj_je from
(select t1.ny,t1.xzqh,t1.szfl,t1.sjflbm,substr(t1.gnkmbm,0,3) gnkmbm ,
nvl(sum(t1.nlj_je),0) nlj_je from CZFX_DYB t1
where (t1.gnkmbm like '1%' or t1.gnkmbm like '2%') and t1.gnkmbm not like '1010103+1010105'
and length(t1.gnkmbm)>=5 group by t1.ny,t1.xzqh,t1.szfl,t1.sjflbm,substr(t1.gnkmbm,0,3)
having nvl(sum(t1.nlj_je),0)<>0) aa where t.ny=aa.ny and t.xzqh=aa.xzqh and t.szfl=aa.szfl
and t.gnkmbm=aa.gnkmbm and t.sjflbm=aa.sjflbm
)
where (t.gnkmbm like '1%' or t.gnkmbm like '2%') and t.gnkmbm not like '1010103+1010105'
and length(t.gnkmbm)=3 and t.ny=substr(riqi,0,6) and exists
(select * from
(select t1.ny,t1.xzqh,t1.szfl,t1.sjflbm,substr(t1.gnkmbm,0,3) gnkmbm ,
nvl(sum(t1.nlj_je),0) nlj_je from CZFX_DYB t1
where (t1.gnkmbm like '1%' or t1.gnkmbm like '2%') and t1.gnkmbm not like '1010103+1010105'
and length(t1.gnkmbm)>=5 group by t1.ny,t1.xzqh,t1.szfl,t1.sjflbm,substr(t1.gnkmbm,0,3)
having nvl(sum(t1.nlj_je),0)<>0) aa where t.ny=aa.ny and t.xzqh=aa.xzqh and t.szfl=aa.szfl
and t.gnkmbm=aa.gnkmbm and t.sjflbm=aa.sjflbm);
commit;
if substr(riqi,5,2)=01 then
  update czfx_dyb t set t.ylj_je=t.nlj_je where t.ny=substr(riqi,0,6);
  else
update czfx_dyb t set t.ylj_je=(select t.nlj_je-nvl(a.nlj_je,0) from czfx_dyb a where a.ny=t.ny-1 and a.xzqh=t.xzqh
and a.szfl=t.szfl and a.gnkmbm=t.gnkmbm and a.sjflbm=t.sjflbm )
where t.ny=substr(riqi,0,6);
end if;
commit;
    end;


end pkg_CZFX_DYB;
/

