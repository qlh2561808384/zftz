create view V_DN_MH_USER as
  select t."id" fid,t1.c_name,t1.c_userscreenname, t1.c_oid, t2.bm,t2.mc
  from V_DN_MH_USER@SJFXPT t, mv_cos_org_user t1, v_jczl_division t2
 where t.user_name_ = t1.c_userscreenname
   and t1.c_oid = t2.deptid
/

