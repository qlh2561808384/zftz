create procedure P_USER_PIC_DIS(pCursor out sys_refcursor, -- 调用返回结果集
                                             V_USERNAME in varchar2
                                             ) is

upic_count number(2);                                            
begin
  select count(1)
      into upic_count
      from czfx_user_pic_display upic
     where upic.createid = V_USERNAME;

  if upic_count = 0 then
  open pCursor for
  select p.pic_id,p.pic_name,p.pic_name||'<font color=red>['||p.pic_id||']</font>' db,p.pic_address,'' pic_targetlink,'0' pic_isshow,p.pic_index,'' createid,'' createdate 
  from czfx_pic_info p
  order by p.pic_index; 
  
  else
  open pCursor for
  select upic.pic_id,upic.pic_name,upic.pic_name||'<font color=red>['||upic.pic_id||']</font>' db,pic.pic_address,pic.pic_targetlink,upic.pic_isshow,upic.pic_index,upic.createid,upic.createdate 
  from czfx_user_pic_display upic 
  left join czfx_pic_info pic on upic.pic_id=pic.pic_id 
  where (upic.createid = V_USERNAME or pic_accountid = V_USERNAME)  and exists (select * from czfx_user_pic_display where createid = V_USERNAME or pic_accountid = V_USERNAME)
  order by upic.pic_index;
  end if;
  
end P_USER_PIC_DIS;
/

