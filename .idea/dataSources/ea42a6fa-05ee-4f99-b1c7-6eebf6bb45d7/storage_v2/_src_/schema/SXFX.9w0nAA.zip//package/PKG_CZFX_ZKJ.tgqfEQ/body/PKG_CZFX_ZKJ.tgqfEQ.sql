create package body pkg_CZFX_zkj is
  ------------------总会计_本级---------------------------
procedure GET_CZFX_ZKJ_BJ(riqi varchar2) is
  begin
     delete from CZFX_ZKJ_BJ
       where year in (substr(riqi, 0, 4));
          insert into CZFX_ZKJ_BJ
select l.xzqh,
       l.year,
       l.year || lpad(l.month, 2, '0') || lpad(l.day, 2, '0') pzrq,
       l.year || lpad(l.month, 2, '0') ny,
       l.setid,
       l.voucherno,
       l.line,
       l.summary,
       ''  kjkmid ,   --l.sectionguid,
     case
                 when (select a.zkj
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_KJKM') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_KJKM a1
                    where a1.bm = a.isbn_code)
                    is null then '-1' else
                     (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_KJKM a1
                    where a1.bm = a.isbn_code)
                    end from dual)
                 when (select a2.zkj
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_KJKM') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 2
                      and a3.bmb = 'CZFX_DM_KJKM'
                      and a3.dynf = l.year
                      and a3.dyxzqh = l.xzqh
                      and a3.dybm = a.isbn_code)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 2
                      and a3.bmb = 'CZFX_DM_KJKM'
                      and a3.dynf = l.year
                      and a3.dyxzqh = l.xzqh
                      and a3.dybm = a.isbn_code)
                    end from dual)
                 else
                  '-1'
               end kjkmbm,
           '' kjkmmc,   --a.name,
       '' dwbm,  ---- e.isbn_code,
       ''    dwmc,--e.name,
       '' dwfjbm,  ---ee.code,
      ''  ssks, -- e.division,
      ''  dwxz, --- e.enterprisekind,
      ''  zflx,  --- e.paytype,
      ''  dwlx ,--- e.enterprisetype,
      ------收支分类-----
     case
                 when (select a.jcgc
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_SZFL') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_SZFL a1
                    where a1.bm = F.SZTYPE)
                    is null then '-1' else
                      (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_SZFL a1
                    where a1.bm = F.SZTYPE)
                    end from dual)
                 when (select a2.jcgc
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_SZFL') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_SZFL'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = F.SZTYPE)
                      is null then '-1' else
                        (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_SZFL'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = F.SZTYPE)
                      end from dual)
                 else
                  '-1'
               end szfl,
     -------------------
        case
                 when (select a.zkj
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_GNKM') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_GNKM a1
                    where a1.bm = f.isbn_code)
                    is null then '-1' else
                     (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_GNKM a1
                    where a1.bm = f.isbn_code)
                    end from dual)
                 when (select a2.zkj
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_GNKM') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_GNKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = f.isbn_code)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_GNKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = f.isbn_code)
                      end from dual)
                 else
                  '-1'
               end gnkmbm,
      '' gnkmmc,  --- f.name,
         case
                 when (select a.zkj
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_ZFJJKM') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZFJJKM a1
                    where a1.bm = e1.isbn_code)
                    is null then '-1' else
                    (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZFJJKM a1
                    where a1.bm = e1.isbn_code)
                    end from dual)
                 when (select a2.zkj
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_ZFJJKM') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZFJJKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e1.isbn_code)
                      is null then '-1' else
                       (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZFJJKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e1.isbn_code)
                      end from dual)
                 else
                  '-1'
               end zfjjkmbm,
      '' zfjjkmmc,------ e1.name,
     '' bmjjkmbm,  --e2.isbn_code,
     '' bmjjkmmc,-- e2.name,
     '' xmlbbm,   ---  p.programtypecode,
     '' xmid,  ----  p.guid,
     '' xmmc,---- p.name,
     '' zjlybm,---  l.resourceincode,
       l.debmoney,
       l.cremoney,
       sysdate xgrq
  from V_SX_ADMDIV_LEDGER l
  left join V_SX_ADMDIV_ACCOUNTSECTION a
    on l.year = a.year
   and l.setid = a.setid
   and l.sectionguid = a.guid
   and l.XZQH=a.XZQH
  left join jczl.enterprise e
    on l.enterguid = e.guid
  left join jczl.enterprise ee
    on e.parent_guid = ee.guid
  left join V_SX_ADMDIV_FUNCTIONSECTION f
    on l.functionguid = f.guid and l.XZQH=f.XZQH
  left join jczl.economysectiongov e1
    on l.economygovguid = e1.guid
  left join jczl.economysection e2
    on l.economyguid = e2.guid
  left join jczl.program p
    on l.programguid = p.guid
 where l.year =(substr(riqi, 0, 4))
  and l.XZQH='3306010101' ;
        commit;
end;

procedure GET_CZFX_JCGC_ZKJPZ(riqi varchar2) is
  begin
     delete from czfx_jcgc_zkjpz
       where year in (substr(riqi, 0, 4));
  insert into czfx_jcgc_zkjpz
select l.xzqh,
       l.year,
       l.year || lpad(l.month, 2, '0') || lpad(l.day, 2, '0') pzrq,
       l.year || lpad(l.month, 2, '0') ny,
       l.setid,
       l.voucherno,
       l.line,
       l.summary,
       l.sectionguid,
       ----会计科目编码------
        case
                 when (select aa.zkj
                         from czfx_dm_bmbqd aa
                        where aa.bmb = 'CZFX_DM_KJKM') = 1 then
                        (select case when
                  (select case
                            when aa1.bm is null then
                             '-1'
                            else
                             aa1.bm
                          end
                     from CZFX_DM_KJKM aa1
                    where aa1.bm = a.ISBN_CODE)
                    is null then '-1' else
                     (select case
                            when aa1.bm is null then
                             '-1'
                            else
                             aa1.bm
                          end
                     from CZFX_DM_KJKM aa1
                    where aa1.bm = a.ISBN_CODE)
                    end from dual)
                 when (select aa2.zkj
                         from czfx_dm_bmbqd aa2
                        where aa2.bmb = 'CZFX_DM_KJKM') = 2 then
                        (select case when
                  (select case
                            when aa3.bm is null then
                             '-1'
                            else
                             aa3.bm
                          end
                     from czfx_dm_dygx aa3
                    where aa3.dyly = 2
                      and aa3.bmb = 'CZFX_DM_KJKM'
                      and aa3.dynf = l.year
                      and aa3.dyxzqh = l.XZQH
                      and aa3.dybm = a.ISBN_CODE)
                      is null then '-1' else
                       (select case
                            when aa3.bm is null then
                             '-1'
                            else
                             aa3.bm
                          end
                     from czfx_dm_dygx aa3
                    where aa3.dyly = 2
                      and aa3.bmb = 'CZFX_DM_KJKM'
                      and aa3.dynf = l.year
                      and aa3.dyxzqh = l.XZQH
                      and aa3.dybm = a.ISBN_CODE)
                      end from dual)
                 else
                  '-1'
               end kjkmbm,
               ----------------------
               ----会计科目名称------
               
               
       ''  会计科目名称,---a.name
       e.isbn_code,
       e.name,
       ee.code,
       e.division,
       e.enterprisekind,
       e.paytype,
       e.enterprisetype,
       
       -------收支分类-------------
               case
                 when (select a.zkj
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_SZFL') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_SZFL a1
                    where a1.bm = f.SZTYPE)
                    is null then '-1' else
                      (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_SZFL a1
                    where a1.bm = f.SZTYPE)
                    end from dual)
                 when (select a2.zkj
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_SZFL') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_SZFL'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = f.SZTYPE)
                      is null then '-1' else
                        (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_SZFL'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = f.SZTYPE)
                      end from dual)
                 else
                  '-1'
               end szfl,
       -----------功能科目-----------------
               case
                 when (select a.zkj
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_GNKM') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_GNKM a1
                    where a1.bm = f.isbn_code)
                    is null then '-1' else
                     (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_GNKM a1
                    where a1.bm = f.isbn_code)
                    end from dual)
                 when (select a2.zkj
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_GNKM') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_GNKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = f.isbn_code)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_GNKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = f.isbn_code)
                      end from dual)
                 else
                  '-1'
               end gnkmbm,
               ----------------------------
      '' 功能科目名称,  ---- f.name,
      ---------政府经济科目----------------
               case
                 when (select a.zkj
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_ZFJJKM') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZFJJKM a1
                    where a1.bm = e1.isbn_code)
                    is null then '-1' else
                    (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_ZFJJKM a1
                    where a1.bm = e1.isbn_code)
                    end from dual)
                 when (select a2.zkj
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_ZFJJKM') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZFJJKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e1.isbn_code)
                      is null then '-1' else
                       (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_ZFJJKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e1.isbn_code)
                      end from dual)
                 else
                  '-1'
               end zfjjkmbm,
      --------------------
       ''  政府经济科目 ,--- e1.name,
       
       ----------部门经济科目---------------
               case
                 when (select a.zkj
                         from czfx_dm_bmbqd a
                        where a.bmb = 'CZFX_DM_BMJJKM') = 1 then
                        (select case when
                  (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_BMJJKM a1
                    where a1.bm = e2.isbn_code)
                    is null then '-1' else
                     (select case
                            when a1.bm is null then
                             '-1'
                            else
                             a1.bm
                          end
                     from CZFX_DM_BMJJKM a1
                    where a1.bm = e2.isbn_code)
                    end from dual)
                 when (select a2.zkj
                         from czfx_dm_bmbqd a2
                        where a2.bmb = 'CZFX_DM_BMJJKM') = 2 then
                        (select case when
                  (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_BMJJKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e2.isbn_code)
                      is null then '-1' else
                      (select case
                            when a3.bm is null then
                             '-1'
                            else
                             a3.bm
                          end
                     from czfx_dm_dygx a3
                    where a3.dyly = 0
                      and a3.bmb = 'CZFX_DM_BMJJKM'
                      and a3.dynf = 0
                      and a3.dyxzqh = 0
                      and a3.dybm = e2.isbn_code)
                      end from dual)
                 else
                  '-1'
               end bmjjkmbm,
       ''   部门经济科目名称,---  e2.name,
       p.programtypecode,
       p.guid,
       p.name,
       l.resourceincode,
       l.debmoney,
       l.cremoney,
       sysdate xgrq
  from V_SX_ADMDIV_LEDGER l
  left join V_SX_ADMDIV_ACCOUNTSECTION a
    on l.year = a.year
   and l.setid = a.setid
   and l.sectionguid = a.guid
   and l.XZQH=a.XZQH
  left join jczl.enterprise e
    on l.enterguid = e.guid 
  left join jczl.enterprise ee
    on e.parent_guid = ee.guid
  left join V_SX_ADMDIV_FUNCTIONSECTION f
    on l.functionguid = f.guid and l.XZQH=f.XZQH
  left join jczl.economysectiongov e1
    on l.economygovguid = e1.guid
  left join jczl.economysection e2
    on l.economyguid = e2.guid
  left join jczl.program p
    on l.programguid = p.guid
 where l.year = (substr(riqi, 0, 4));
 --  and l.setid =6
  
  
        commit;
end;
end pkg_CZFX_zkj;
/

