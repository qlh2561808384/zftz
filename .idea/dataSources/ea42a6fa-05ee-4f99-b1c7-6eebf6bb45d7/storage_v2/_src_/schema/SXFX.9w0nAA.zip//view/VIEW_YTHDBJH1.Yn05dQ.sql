create view VIEW_YTHDBJH1 as
  (select ywxtbm,code, sl  from Mv_dbsx_HD
union all
select ywxtbm,code, sl from
   MHDP_FOA_DB
  )
/

