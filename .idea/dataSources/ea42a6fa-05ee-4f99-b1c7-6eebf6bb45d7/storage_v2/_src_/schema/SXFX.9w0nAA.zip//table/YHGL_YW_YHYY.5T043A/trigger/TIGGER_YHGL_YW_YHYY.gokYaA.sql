create trigger TIGGER_YHGL_YW_YHYY
  before insert
  on YHGL_YW_YHYY
  for each row
  when (NEW.guid IS NULL)
  BEGIN
    SELECT seq_yhgl_yw_yhyy.Nextval INTO:NEW.guid FROM DUAL;
END;
/

