create view V_TDCB_SCCB as
  select t01.xmid, t01.dkxxid, t01.nd, t01.szxmbm, t01.je
  from tdcb_tdcbszys t01
 where t01.szxmbm in ('1001', '1002', '1003', '1004', '1005', '1008', '1099')
   and exists (select *
          from tdcb_xmdj t02
         where t01.xmid = t02.xmid
           and t02.xmzt <> '99')
union all
--债务利息--
select t03.xmid, t03.id, to_number(t03.nd), '1008', t03.zwlx
  from V_TDCB_YS_ZWLX t03
/

