create procedure GETP_YHGL_YY(xmls in VARCHAR2, --输入xml
                                      yhzh out VARCHAR2, --返回的用户账号
                                      yhmm out VARCHAR2) is
  --返回的用户密码

  -- 变量定义用户
  GUIDS    VARCHAR2(500); --用户GUID
  YHLX     VARCHAR2(500); --用户类型
  ZJHM     VARCHAR2(500); --身份证号
  XM       VARCHAR2(500); --姓名
  BGDH     VARCHAR2(500); --办公电话
  YDHM     VARCHAR2(500); --手机号码
  LXDZ     VARCHAR2(500); --联系地址
  RYLX     VARCHAR2(500); --人员类型
  ZC       VARCHAR2(500); --职称
  ZW       VARCHAR2(500); --职务
  YHSZDW   VARCHAR2(500); --用户所属单位
  DLM      VARCHAR2(500); --登录名
  ZT       VARCHAR2(500); --状态
  RYXZ     VARCHAR2(500); --人员性质
  SSGKCS   VARCHAR2(500); --所属归口科室
  REGICODE VARCHAR2(500); --行政区划
  EMAIL    VARCHAR2(500); --邮箱地址
  -- 变量定义用户对应用
  GUIDSS   VARCHAR2(500); --用户应用GUID
  YHID     VARCHAR2(500); --对用用户guid
  YYID     VARCHAR2(500); --对应应用guid
  GWID     VARCHAR2(500); --岗位guid
  CJYHID   VARCHAR2(500); --创建人id
  ZTS       VARCHAR2(500); --状态
  SZDWID   VARCHAR2(500); --账号所属单位
  YYBM     VARCHAR2(500); --应用编码
  REGICODES VARCHAR2(500); --行政区划

  --创建xml解析器实例xmlparser.Parser
  xmlPar xmlparser.Parser := xmlparser.newParser;
  --定义DOM文档
  xDoc xmldom.DOMDocument;
  --定义item子节点数目变量
  lenItme integer;

  --定义节点列表，存放item节点们
  itemNodes xmldom.DOMNodeList;
  --定义节点列表，存放item子节点们
  childNodes xmldom.DOMNodeList;
  --定义节点，存放单个item节点
  itemNode xmldom.DOMNode;
  --定义属性变量，存放节点属性
  itemArrMap xmldom.DOMNamedNodeMap;


BEGIN

  xmlPar := xmlparser.newParser;
  --解析xmlStr中xml字符串，并存放到xmlPar中
  /*xmlparser.parse(xmlPar, xmlStr);*/
  xmlparser.parseClob(xmlPar, xmls);
  --将xmlPar中的数据转存到dom文档中
  xDoc := xmlparser.getDocument(xmlPar);
  --释放解析器实例
  xmlparser.freeParser(xmlPar);

  --获取所有YH节点
  itemNodes := xmldom.getElementsByTagName(xDoc, 'YH');
  itemNode :=xmldom.item( itemNodes,0 );
  childNodes :=xmldom.getChildNodes(itemNode);

  GUIDS :=xmldom.getNodeValue(xmldom.getFirstChild(xmldom.item(childNodes,0)));
  YHLX  :=xmldom.getNodeValue(xmldom.getFirstChild(xmldom.item(childNodes,1)));
  ZJHM  :=xmldom.getNodeValue(xmldom.getFirstChild(xmldom.item(childNodes,2)));
  XM    :=xmldom.getNodeValue(xmldom.getFirstChild(xmldom.item(childNodes,3)));
  BGDH  :=xmldom.getNodeValue(xmldom.getFirstChild(xmldom.item(childNodes,4)));
  YDHM  :=xmldom.getNodeValue(xmldom.getFirstChild(xmldom.item(childNodes,5)));
  LXDZ  :=xmldom.getNodeValue(xmldom.getFirstChild(xmldom.item(childNodes,6)));
  RYLX  :=xmldom.getNodeValue(xmldom.getFirstChild(xmldom.item(childNodes,7)));
  ZC    :=xmldom.getNodeValue(xmldom.getFirstChild(xmldom.item(childNodes,8)));
  ZW    :=xmldom.getNodeValue(xmldom.getFirstChild(xmldom.item(childNodes,9)));
  YHSZDW  :=xmldom.getNodeValue(xmldom.getFirstChild(xmldom.item(childNodes,10)));
  DLM   :=xmldom.getNodeValue(xmldom.getFirstChild(xmldom.item(childNodes,11)));
  ZT    :=xmldom.getNodeValue(xmldom.getFirstChild(xmldom.item(childNodes,12)));
  RYXZ  :=xmldom.getNodeValue(xmldom.getFirstChild(xmldom.item(childNodes,13)));
  SSGKCS  :=xmldom.getNodeValue(xmldom.getFirstChild(xmldom.item(childNodes,14)));
  REGICODE :=xmldom.getNodeValue(xmldom.getFirstChild(xmldom.item(childNodes,15)));
  EMAIL   :=xmldom.getNodeValue(xmldom.getFirstChild(xmldom.item(childNodes,16)));
  -- YHYY
  itemNodes := xmldom.getElementsByTagName(xDoc, 'YHYY');
  itemNode :=xmldom.item( itemNodes,0 );
  childNodes :=xmldom.getChildNodes(itemNode);

  GUIDSS   :=xmldom.getNodeValue(xmldom.getFirstChild(xmldom.item(childNodes,0)));
  YHID     :=xmldom.getNodeValue(xmldom.getFirstChild(xmldom.item(childNodes,1)));
  YYID     :=xmldom.getNodeValue(xmldom.getFirstChild(xmldom.item(childNodes,2)));
  GWID     :=xmldom.getNodeValue(xmldom.getFirstChild(xmldom.item(childNodes,3)));
  CJYHID   :=xmldom.getNodeValue(xmldom.getFirstChild(xmldom.item(childNodes,4)));
  ZTS       :=xmldom.getNodeValue(xmldom.getFirstChild(xmldom.item(childNodes,5)));
  SZDWID   :=xmldom.getNodeValue(xmldom.getFirstChild(xmldom.item(childNodes,6)));
  YYBM     :=xmldom.getNodeValue(xmldom.getFirstChild(xmldom.item(childNodes,7)));
  REGICODES :=xmldom.getNodeValue(xmldom.getFirstChild(xmldom.item(childNodes,8)));




  DBMS_OUTPUT.PUT_LINE('GUIDS :' || GUIDS);
  DBMS_OUTPUT.PUT_LINE('YHLX :' || YHLX);
  DBMS_OUTPUT.PUT_LINE('s_end :' || ZJHM);

  xmldom.freeDocument(xDoc);
/*EXCEPTION
  WHEN OTHERS THEN
    DBMS_output.PUT_LINE(SQLERRM);*/
  
END GETP_YHGL_YY;
/

