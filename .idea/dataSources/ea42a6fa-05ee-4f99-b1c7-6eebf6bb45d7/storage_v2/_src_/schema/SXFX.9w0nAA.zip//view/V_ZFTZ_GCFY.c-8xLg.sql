create view V_ZFTZ_GCFY as
  select id gcfyid,
       (select id_zftz_xm from zftz_xmgs  where id=id_zftz_xmgs) id_zftz_xm,
       id_zftz_xmgs,
       gcfymc,
       '1' lx,
       case when tzefl = 'TZE_JZTZ' then 1
         when tzefl = 'TZE_AZTZ' then 2
           when tzefl = 'TZE_SBTZ' then 3
             when tzefl = 'TZE_QTTZ' then 4
       end tzefl,
       tzje gstzje
  from zftz_xmgsmx t unpivot(tzje for tzefl in(tze_jztz,
                                               tze_aztz,
                                               tze_sbtz,
                                               tze_qttz))
/*union all
select t.gcfyid,(select id_zftz_xm from zftz_xmgs_tz  where id=id_zftz_xmgs_tz) id_zftz_xm, t.id_zftz_xmgs_tz, t.gcfymc, '2' lx, t.tzefl, t.tzje gstzje
  from zftz_xmgs_tzmx t;*/

