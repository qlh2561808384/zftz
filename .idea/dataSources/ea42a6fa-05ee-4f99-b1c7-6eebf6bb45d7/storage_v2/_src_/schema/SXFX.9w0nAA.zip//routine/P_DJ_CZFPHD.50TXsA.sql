create procedure P_DJ_CZFPHD
(
  v_userid  in varchar2,
  V_hid     IN NUMBER,
  v_djxh    in CLOB,
  v_czfp_dm in varchar2,
  d_qsrq    in NUMBER,
  d_zzrq    in NUMBER,
  v_flag		out varchar2
) IS
  v_zgswj_dm  VARCHAR2（50):      --核定前税务机构代码代码
  v_czfp_old  VARCHAR2(50);       --核定前财政分片代码
  DT_LOG      date;               --日志日期
  v_err       VARCHAR2(2000);     --oracle错误
  n_cnt       NUMBER(10):=0;      --待核定记录数
  N_HDID      NUMBER(20);
  CURSOR CUR_DJXH IS
    select TO_CHAR(substr(t.ca,instr(t.ca,'@',1,c.lv)+1,instr(t.ca,'@',1,c.lv+1)-(instr(t.ca,'@',1,c.lv)+1))) as DJXH
    from (select '@'||v_djxh||'@' as ca, length('@'||v_djxh||'@')-nvl(length(replace('@'||v_djxh||'@','@')),0)-1 as cnt from dual) t,
       (select level lv from dual connect by level<=1000) c
    where c.lv<=t.cnt;
begin
  --0.写日志
  select sysdate into DT_LOG from dual;
--  P_GG_LOG(V_SPNAME =>'P_DJ_CZFPHD',DT_START => DT_LOG,C_ERRMSG =>'$开始'||v_djxh);

 /* if to_char(d_qsrq,'yyyy')<to_char(sysdate,'yyyy') and to_char(sysdate,'mm')>'01' then
     v_flag:='每年2月份以后不得核定历史年度数据！';
  ELSif to_char(d_qsrq,'yyyy')<>to_char(d_zzrq,'yyyy') then
    v_flag:='只能核定一个年度内的‘财政分片’数据！';
/*
  elsif d_zzrq<trunc(sysdate,'mon') and to_char(d_zzrq,'mm')<>'12' then
    v_flag:='同一年度内不支持部分月份核定！';
*/
  else
    for R_DJXH in CUR_DJXH loop
      --原分片编码
      select CZFP_DM INTO v_czfp_old from SRFX_DJ_NSR A where f_djxh=R_DJXH.DJXH;
      --原主管税务机构代码
      select zgswj_dm INTO v_zgswj_dm from SRFX_DJ_NSR A where f_djxh=R_DJXH.DJXH;
      --插入核定批次表
      INSERT INTO SRFX_DJ_HDZB(HID,CZR,STATUS) values(V_hid,v_userid,0)
      --插入核定信息表
      INSERT INTO SRFX_DJ_HDMX(HID,F_DJXH,ZGSWJ_DM,OLDCZFP,NEWCZFP,FROMDAY,TODAY,STATUS)  --SELECT HID,F_DJXH,ZGSWJ_DM,OLDCZFP,NEWCZFP,FROMDAY,TODAY,STATUS FROM SRFX_DJ_HDMX
        values(V_hid,R_DJXH.DJXH,v_zgswj_dm,v_czfp_old,v_czfp_dm,d_qsrq,d_zzrq,0);
      n_cnt:=n_cnt+1;
    end loop;
    commit;
 --调用核定存储过程

exception when others then
  rollback;
  v_err:=substr(sqlerrm,1,2000);
  v_flag:='错误：'||v_err;
  --失败写日志
  P_GG_LOG(V_SPNAME =>'P_DJ_CZFPHD',DT_START => DT_LOG,C_ERRMSG =>v_err);

End P_DJ_CZFPHD;
/

