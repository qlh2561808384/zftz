create view V_DP_BMZC as
  select "DM_NAME","PERCENT" from (
select (select d.name from jczl.division d where d.guid=a.dd) DM_NAME,
       to_char(cast(round(a.pp/a.bb*100,2) as numeric(6,2)),'fm99990.00')||'%' AS PERCENT
    from
      (
         select b.divisionguid dd,sum(b.money) bb,sum(b.pmoney) pp
           from zjsb.budget b
           where b.year=to_char(sysdate,'yyyy')-1
           group by b.divisionguid
       ) a) aa
/

