create view V_YHGL_BMFZR as
  select aa.guid ywid,aa.ssgkcs,bb.dwmc,cc.guid yhid from
(select T.GUID,T1.YHLX,
--(select e.deptid from mv_gg_enterdivision_yhgl e where e.entid=T.SZDWID and rownum=1),
nvl((select d.deptid from v_jczl_division d where d.bm=T1.SSGKCS),
(select e.deptid from mv_gg_enterdivision_yhgl e where e.entid=T.SZDWID and rownum=1)) ssgkcs
from YHGL_YW_YHYYSQFB t,YHGL_YW_YHYYSQ T1
WHERE T.SQDID=T1.GUID) aa,lcgl.kh_dm_dwfzr bb,yhgl_yw_yhyy cc
where cc.yybm='YHGL' and aa.ssgkcs=bb.deptid and cc.yhzh=bb.fzruserid
/

