create trigger TIGGER_MHDP_RYB
  before insert
  on V_DP_RYB
  for each row
  when (NEW.id IS NULL)
  BEGIN
    SELECT SEQ_MHDP_RYB.Nextval INTO:NEW.id FROM DUAL;
END;
/

