create trigger TRI_CZFX_JH
  before insert
  on CZFX_JH
  for each row
  begin
select SEQ_CZFX_JH.nextval into :new.jhbm from dual;
end ;
/

