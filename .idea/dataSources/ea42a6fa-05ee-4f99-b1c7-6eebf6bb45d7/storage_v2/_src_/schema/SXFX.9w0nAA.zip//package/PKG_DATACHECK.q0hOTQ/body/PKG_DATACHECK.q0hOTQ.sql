create PACKAGE BODY PKG_DATACHECK AS

PROCEDURE  GET_MAINQUERY(
        P_YEAR     IN NUMBER,
        P_ID   IN NUMBER, 
        CUR_SELECT OUT  T_CURSOR,
        P_BODY OUT  T_CURSOR
        ) 

IS
BEGIN
/*  IF P_STEPID=0 THEN
    OPEN CUR_SELECT FOR SELECT 1 as 收入项目层码,'' as 收入项目编码,'' AS 收入项目名称,0 AS 收入金额,1 as 支出项目层码,'' AS 支出项目编码,'' AS 支出项目名称,
    0 AS 支出金额,0 AS 数据类型 FROM DUAL;
    RETURN CUR_SELECT;
  END IF;*/

  GET_CHECK_DYB_YLJNLJ(P_YEAR,P_ID,P_BODY);
  IF CUR_SELECT%ISOPEN THEN
    CLOSE CUR_SELECT;
    end if ;
  OPEN CUR_SELECT FOR
  SELECT guid,ssyy,name,flag FROM TMP_DATACHECK ;
END;



PROCEDURE GET_CHECK_DYB_YLJNLJ(
        P_YEAR     IN NUMBER,
        P_ID   IN NUMBER,
        P_BODY        OUT  T_CURSOR    -- 返回的数据集游标
        )    -- 错误描述
IS
  W_MAXNY  NUMBER;
  W_NLJ    NUMBER;
  W_YLJ    NUMBER;
  W_QUERYSTRING    LONG;
BEGIN
    select max(t.ny) into W_MAXNY from CZFX_DYB t where t.ny like P_YEAR||'%';
    select sum(t.nlj_je) into W_NLJ   from CZFX_DYB t where t.ny=W_MAXNY;
    select sum(t.ylj_je) into W_YLJ   from CZFX_DYB t where t.ny like P_YEAR||'%';
if(W_NLJ<>W_YLJ) THEN
   insert into TMP_DATACHECK 
   select 1,'电月报','电月报数据清洗','0' from dual;
   if (P_ID=1) then
   IF P_BODY%ISOPEN THEN
    CLOSE P_BODY;
    end if;
    OPEN P_BODY FOR
   select W_MAXNY,sum(ylj_je) ylj_je ,sum(case when ny=W_MAXNY then nlj_je else 0 end ) nlj_je from CZFX_DYB where ny like '2018%' ;
   end if;
   else
     insert into TMP_DATACHECK 
   select 1,'电月报','电月报数据清洗','1' from dual;
      if (P_ID=1) then
    IF P_BODY%ISOPEN THEN
    CLOSE P_BODY;
    end if;
    OPEN P_BODY FOR
   select W_MAXNY,sum(ylj_je) ylj_je ,sum(case when ny=W_MAXNY then nlj_je else 0 end ) nlj_je from CZFX_DYB where ny like '2018%' ;
   end if;
END IF;


/*  IF P_BODY%ISOPEN THEN
    CLOSE P_BODY;
    end if ;
  OPEN P_BODY FOR
  SELECT guid,ssyy,name,flag FROM TMP_DATACHECK ;*/

END GET_CHECK_DYB_YLJNLJ;

END PKG_DATACHECK;
/

