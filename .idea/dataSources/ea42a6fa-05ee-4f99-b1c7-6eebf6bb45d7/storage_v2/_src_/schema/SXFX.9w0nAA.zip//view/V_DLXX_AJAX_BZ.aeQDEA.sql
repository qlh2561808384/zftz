create view V_DLXX_AJAX_BZ as
  select '01' dxlx,'02' bzlx,t.id ,t.dkmc mc,t1.ssxzqy ssxzqh,'TDCB' yybm from tdcb_dkxx t,tdcb_xmdj t1
where t.xmid=t1.xmid and t1.xmzt<>99
union all
select '02','01', t.xmid,t.xmmc,t.ssxzqy,'TDCB' yybm from tdcb_xmdj t where  t.xmzt<>99
/

