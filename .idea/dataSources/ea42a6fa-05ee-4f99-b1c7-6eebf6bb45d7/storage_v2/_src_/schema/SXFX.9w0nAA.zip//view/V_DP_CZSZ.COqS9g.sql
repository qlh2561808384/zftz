create view V_DP_CZSZ as
  select "DQ","BNCZSR","BNCZSRZZL","BNYBGGYSSR","BNYBGGYSSRZZL","CZSRZB","BNSSSR","BNSSSRZZL","YBGGYSSRZB","BNFSSR","BNFSSRZZL","BNYBGGYSZC","TXT","NY" from (
select * from (
SELECT DQ,BNCZSR/10000 AS BNCZSR,BNCZSRZZL,BNYBGGYSSR/10000 AS BNYBGGYSSR,BNYBGGYSSRZZL,CZSRZB,BNSSSR/10000 AS BNSSSR,BNSSSRZZL,YBGGYSSRZB,BNFSSR/10000 as BNFSSR,BNFSSRZZL,BNYBGGYSZC/10000 as BNYBGGYSZC,BNYBGGYSZCZZL AS TXT,case when to_number(to_char(sysdate,'dd'))<=10
       then to_number(to_char(add_months(sysdate,-3),'yyyymm'))
       else to_number(to_char(add_months(sysdate,-2),'yyyymm')) end NY
                FROM (
                  WITH tmp0 AS (
                      SELECT CASE WHEN t.DQ LIKE '%小计' THEN REPLACE(t.DQ, '小计', NULL)
                              WHEN t.DQ LIKE '%小浙江%' THEN '不含宁波' ELSE t.DQ END DQ,
                             SUM(CASE WHEN t.NY = (case when to_number(to_char(sysdate,'dd'))<=10
       then to_number(to_char(add_months(sysdate,-9),'yyyymm'))
       else to_number(to_char(add_months(sysdate,-8),'yyyymm')) end)-100 AND t.TJZB = '财政总收入' THEN t.BNLJ ELSE 0 END) BNCZSR,
                             SUM(CASE WHEN t.NY = (case when to_number(to_char(sysdate,'dd'))<=10
       then to_number(to_char(add_months(sysdate,-9),'yyyymm'))
       else to_number(to_char(add_months(sysdate,-8),'yyyymm')) end)-100 AND t.TJZB = '财政总收入' THEN t.TBZZ ELSE 0 END) BNCZSRZZL,
                             SUM(CASE WHEN t.NY = (case when to_number(to_char(sysdate,'dd'))<=10
       then to_number(to_char(add_months(sysdate,-9),'yyyymm'))
       else to_number(to_char(add_months(sysdate,-8),'yyyymm')) end)-100 AND t.TJZB = '一般公共预算收入' THEN t.BNLJ ELSE 0 END) BNYBGGYSSR,
                             SUM(CASE WHEN t.NY = (case when to_number(to_char(sysdate,'dd'))<=10
       then to_number(to_char(add_months(sysdate,-9),'yyyymm'))
       else to_number(to_char(add_months(sysdate,-8),'yyyymm')) end)-100 AND t.TJZB = '一般公共预算收入' THEN t.TBZZ ELSE 0 END) BNYBGGYSSRZZL,
                             SUM(CASE WHEN t.NY = (case when to_number(to_char(sysdate,'dd'))<=10
       then to_number(to_char(add_months(sysdate,-9),'yyyymm'))
       else to_number(to_char(add_months(sysdate,-8),'yyyymm')) end)-100 AND t.TJZB = '税收收入' THEN t.BNLJ ELSE 0 END) BNSSSR,
                             SUM(CASE WHEN t.NY = (case when to_number(to_char(sysdate,'dd'))<=10
       then to_number(to_char(add_months(sysdate,-9),'yyyymm'))
       else to_number(to_char(add_months(sysdate,-8),'yyyymm')) end)-100 AND t.TJZB = '税收收入' THEN t.TBZZ ELSE 0 END) BNSSSRZZL,
                             SUM(CASE WHEN t.NY = (case when to_number(to_char(sysdate,'dd'))<=10
       then to_number(to_char(add_months(sysdate,-9),'yyyymm'))
       else to_number(to_char(add_months(sysdate,-8),'yyyymm')) end)-100 AND t.TJZB = '非税收入' THEN t.BNLJ ELSE 0 END) BNFSSR,
                             SUM(CASE WHEN t.NY = (case when to_number(to_char(sysdate,'dd'))<=10
       then to_number(to_char(add_months(sysdate,-9),'yyyymm'))
       else to_number(to_char(add_months(sysdate,-8),'yyyymm')) end)-100 AND t.TJZB = '非税收入' THEN t.TBZZ ELSE 0 END) BNFSSRZZL,
                             SUM(CASE WHEN t.NY = (case when to_number(to_char(sysdate,'dd'))<=10
       then to_number(to_char(add_months(sysdate,-9),'yyyymm'))
       else to_number(to_char(add_months(sysdate,-8),'yyyymm')) end)-100 AND t.TJZB = '一般公共预算支出' THEN t.BNLJ ELSE 0 END) BNYBGGYSZC,
                             SUM(CASE WHEN t.NY = (case when to_number(to_char(sysdate,'dd'))<=10
       then to_number(to_char(add_months(sysdate,-9),'yyyymm'))
       else to_number(to_char(add_months(sysdate,-8),'yyyymm')) end)-100 AND t.TJZB = '一般公共预算支出' THEN t.TBZZ ELSE 0 END) BNYBGGYSZCZZL
                        FROM SRFX.SZ_QSYSZXQK t
                       WHERE t.NY = (case when to_number(to_char(sysdate,'dd'))<=10
       then to_number(to_char(add_months(sysdate,-9),'yyyymm'))
       else to_number(to_char(add_months(sysdate,-8),'yyyymm')) end)-100
                         AND t.DQ IS NOT NULL
                         AND (t.DQ LIKE '%小计%' OR t.DQ LIKE '%省级%' OR t.DQ LIKE '%小浙江%' OR t.DQ LIKE '%全省汇总%')
                       GROUP BY t.DQ
                  ), tmp1 AS (
                      SELECT CASE WHEN t.DQ LIKE '%小计' THEN REPLACE(t.DQ, '小计', NULL)
                              WHEN t.DQ LIKE '%小浙江%' THEN '不含宁波' ELSE t.DQ END DQ,
                             SUM(CASE WHEN t.NY = case when to_number(to_char(sysdate,'dd'))<=10
       then to_number(to_char(add_months(sysdate,-9),'yyyymm'))
       else to_number(to_char(add_months(sysdate,-8),'yyyymm')) end AND t.TJZB = '财政总收入' THEN t.BNLJ ELSE 0 END) BNCZSR,
                             SUM(CASE WHEN t.NY = case when to_number(to_char(sysdate,'dd'))<=10
       then to_number(to_char(add_months(sysdate,-9),'yyyymm'))
       else to_number(to_char(add_months(sysdate,-8),'yyyymm')) end AND t.TJZB = '财政总收入' THEN t.TBZZ ELSE 0 END) BNCZSRZZL,
                             SUM(CASE WHEN t.NY = case when to_number(to_char(sysdate,'dd'))<=10
       then to_number(to_char(add_months(sysdate,-9),'yyyymm'))
       else to_number(to_char(add_months(sysdate,-8),'yyyymm')) end AND t.TJZB = '一般公共预算收入' THEN t.BNLJ ELSE 0 END) BNYBGGYSSR,
                             SUM(CASE WHEN t.NY = case when to_number(to_char(sysdate,'dd'))<=10
       then to_number(to_char(add_months(sysdate,-9),'yyyymm'))
       else to_number(to_char(add_months(sysdate,-8),'yyyymm')) end AND t.TJZB = '一般公共预算收入' THEN t.TBZZ ELSE 0 END) BNYBGGYSSRZZL,
                             SUM(CASE WHEN t.NY = case when to_number(to_char(sysdate,'dd'))<=10
       then to_number(to_char(add_months(sysdate,-9),'yyyymm'))
       else to_number(to_char(add_months(sysdate,-8),'yyyymm')) end AND t.TJZB = '税收收入' THEN t.BNLJ ELSE 0 END) BNSSSR,
                             SUM(CASE WHEN t.NY = case when to_number(to_char(sysdate,'dd'))<=10
       then to_number(to_char(add_months(sysdate,-9),'yyyymm'))
       else to_number(to_char(add_months(sysdate,-8),'yyyymm')) end AND t.TJZB = '税收收入' THEN t.TBZZ ELSE 0 END) BNSSSRZZL,
                             SUM(CASE WHEN t.NY = case when to_number(to_char(sysdate,'dd'))<=10
       then to_number(to_char(add_months(sysdate,-9),'yyyymm'))
       else to_number(to_char(add_months(sysdate,-8),'yyyymm')) end AND t.TJZB = '非税收入' THEN t.BNLJ ELSE 0 END) BNFSSR,
                             SUM(CASE WHEN t.NY = case when to_number(to_char(sysdate,'dd'))<=10
       then to_number(to_char(add_months(sysdate,-9),'yyyymm'))
       else to_number(to_char(add_months(sysdate,-8),'yyyymm')) end AND t.TJZB = '非税收入' THEN t.TBZZ ELSE 0 END) BNFSSRZZL,
                             SUM(CASE WHEN t.NY = case when to_number(to_char(sysdate,'dd'))<=10
       then to_number(to_char(add_months(sysdate,-9),'yyyymm'))
       else to_number(to_char(add_months(sysdate,-8),'yyyymm')) end AND t.TJZB = '一般公共预算支出' THEN t.BNLJ ELSE 0 END) BNYBGGYSZC,
                             SUM(CASE WHEN t.NY = case when to_number(to_char(sysdate,'dd'))<=10
       then to_number(to_char(add_months(sysdate,-9),'yyyymm'))
       else to_number(to_char(add_months(sysdate,-8),'yyyymm')) end AND t.TJZB = '一般公共预算支出' THEN t.TBZZ ELSE 0 END) BNYBGGYSZCZZL
                        FROM SRFX.SZ_QSYSZXQK t
                       WHERE t.NY = case when to_number(to_char(sysdate,'dd'))<=10
       then to_number(to_char(add_months(sysdate,-9),'yyyymm'))
       else to_number(to_char(add_months(sysdate,-8),'yyyymm')) end
                         AND t.DQ IS NOT NULL
                         AND (t.DQ LIKE '%小计%' OR t.DQ LIKE '%省级%' OR t.DQ LIKE '%小浙江%' OR t.DQ LIKE '%全省汇总%')
                       GROUP BY t.DQ
                  ), tmp11 AS (
                      SELECT DQ, BNCZSR, BNCZSRZZL, BNYBGGYSSR, BNYBGGYSSRZZL, round(BNYBGGYSSR/BNCZSR*100, 2) CZSRZB, BNSSSR, BNSSSRZZL, ROUND(BNSSSR/BNYBGGYSSR*100, 2) YBGGYSSRZB, BNFSSR, BNFSSRZZL, BNYBGGYSZC, BNYBGGYSZCZZL
                        FROM tmp1
                       ORDER BY (CASE WHEN DQ = '全省汇总' THEN -10
                                      WHEN DQ = '不含宁波' THEN -5
                                      WHEN DQ = '省级' THEN 0
                                      WHEN DQ = '杭州市' THEN 5
                                      WHEN DQ = '温州市' THEN 10
                                      WHEN DQ = '嘉兴市' THEN 15
                                      WHEN DQ = '湖州市' THEN 20
                                      WHEN DQ = '绍兴市' THEN 25
                                      WHEN DQ = '金华市' THEN 30
                                      WHEN DQ = '舟山市' THEN 35
                                      WHEN DQ = '台州市' THEN 40
                                      WHEN DQ = '衢州市' THEN 45
                                      WHEN DQ = '丽水市' THEN 50
                                      WHEN DQ = '宁波市' THEN 55 END)
                  ), tmp111 AS (
                      SELECT CASE WHEN tmp11.DQ = '绍兴市' THEN '十一市中的位置' ELSE tmp11.DQ END DQ,
                             RANK() OVER( ORDER BY tmp11.BNCZSR DESC),
                             RANK() OVER( ORDER BY tmp11.BNCZSRZZL DESC),
                             RANK() OVER( ORDER BY tmp11.BNYBGGYSSR DESC),
                             RANK() OVER( ORDER BY tmp11.BNYBGGYSSRZZL DESC),
                             RANK() OVER( ORDER BY tmp11.CZSRZB DESC),
                             RANK() OVER( ORDER BY tmp11.BNSSSR DESC),
                             RANK() OVER( ORDER BY tmp11.BNSSSRZZL DESC),
                             RANK() OVER( ORDER BY tmp11.YBGGYSSRZB DESC),
                             RANK() OVER( ORDER BY tmp11.BNFSSR DESC),
                             RANK() OVER( ORDER BY tmp11.BNFSSRZZL DESC),
                             RANK() OVER( ORDER BY tmp11.BNYBGGYSZC DESC),
                             RANK() OVER( ORDER BY tmp11.BNYBGGYSZCZZL DESC)
                        FROM tmp11
                       WHERE tmp11.DQ <> '全省汇总' AND tmp11.DQ <> '不含宁波' AND tmp11.DQ <> '省级'
                  ), tmp00 AS (
                      SELECT DQ, BNCZSR, BNCZSRZZL, BNYBGGYSSR, BNYBGGYSSRZZL, round(BNYBGGYSSR/BNCZSR*100, 2) CZSRZB, BNSSSR, BNSSSRZZL, ROUND(BNSSSR/BNYBGGYSSR*100, 2) YBGGYSSRZB, BNFSSR, BNFSSRZZL, BNYBGGYSZC, BNYBGGYSZCZZL
                        FROM tmp0
                   WHERE DQ <> '全省汇总' AND DQ <> '不含宁波' AND DQ <> '省级'
                  ), tmp000 AS (
                      SELECT CASE WHEN tmp00.DQ = '绍兴市' THEN '去年同期' ELSE tmp00.DQ END DQ,
                             RANK() OVER( ORDER BY tmp00.BNCZSR DESC),
                             RANK() OVER( ORDER BY tmp00.BNCZSRZZL DESC),
                             RANK() OVER( ORDER BY tmp00.BNYBGGYSSR DESC),
                             RANK() OVER( ORDER BY tmp00.BNYBGGYSSRZZL DESC),
                             RANK() OVER( ORDER BY tmp00.CZSRZB DESC),
                             RANK() OVER( ORDER BY tmp00.BNSSSR DESC),
                             RANK() OVER( ORDER BY tmp00.BNSSSRZZL DESC),
                             RANK() OVER( ORDER BY tmp00.YBGGYSSRZB DESC),
                             RANK() OVER( ORDER BY tmp00.BNFSSR DESC),
                             RANK() OVER( ORDER BY tmp00.BNFSSRZZL DESC),
                             RANK() OVER( ORDER BY tmp00.BNYBGGYSZC DESC),
                             RANK() OVER( ORDER BY tmp00.BNYBGGYSZCZZL DESC)
                        FROM tmp00
                  )
                  SELECT DQ, BNCZSR, BNCZSRZZL, BNYBGGYSSR, BNYBGGYSSRZZL, CZSRZB, BNSSSR, BNSSSRZZL, YBGGYSSRZB, BNFSSR, BNFSSRZZL, BNYBGGYSZC, BNYBGGYSZCZZL FROM tmp11
                   UNION ALL
                  SELECT * FROM tmp111 WHERE tmp111.DQ = '十一市中的位置'
                   UNION ALL
                  SELECT * FROM tmp000 WHERE tmp000.DQ = '去年同期'
              ))
               order by decode(substr(txt,1,2),'省级',1,'杭州',2,'宁波',3,'温州',4,'绍兴',5,'嘉兴',6,'台州',7,'金华',8,'湖州',9,'衢州',10,'丽水',11,'舟山',12,0)

) aa
/

