create procedure P_YJJK_YW_YWJZJOB(
                                           lx    in  varchar2, --类型（1新增，2修改轮询时间，3删除，4启用，5停用）
                                           yjkzjzid in NUMBER --预警规则加载id
                                           ) as 

--预警规则加载定时job（创建和修改）存储过程
jobno binary_integer;
next_date   date; --何时将运行这个工作
LXJGDW  VARCHAR2(2);--轮询间隔单位(0分钟，1天，2周，3月)
LXJGSL NUMBER(3);   --轮询间隔数量
interval   varchar2(1000); --一个工作重执行的频度
yjgzbm  varchar2(255);  --预警规则编码
jzfw    varchar2(15);  --加载范围
TSDXID  VARCHAR2(15) ;--通知分组id
begin
   --1，根据预警规则加载id查出需要的数据
   select 
      z.jobid, sysdate, z.lxjgdw, z.lxjgsl, z.yjgzbm, z.jzfw, z.tsdxid  
    into 
      jobno , next_date  , LXJGDW  , LXJGSL ,  yjgzbm , jzfw    , TSDXID 
   from yjjk_dm_yjgzjz z where z.guid = yjkzjzid;
   
   if LXJGDW ='0' THEN  --分钟
     interval :='sysdate+'||LXJGSL||'/(24*60)';
   ELSIF LXJGDW ='1' THEN  --天
     interval :='sysdate+'||LXJGSL;
   ELSIF LXJGDW ='2' THEN    --周
     interval:='(sysdate+'||LXJGSL||')*7';
   ELSIF LXJGDW ='3' THEN   --月
     interval:='(sysdate+'||LXJGSL||')*30';
   END IF;  
   
   
  -- INSERT INTO  a_test(CONTENT,adddate) VALUES(lx||','||jobno,sysdate);
  --  commit;
  if lx='1' THEN   --新增job
        dbms_job.submit(jobno,'P_YJJK_YW_YWJZ('''||yjgzbm||''','''||(''||jzfw)||''','||TSDXID||');',sysdate,interval);
        update yjjk_dm_yjgzjz z set z.jobid = jobno where z.guid = yjkzjzid;      
  elsif  lx='2' THEN   -- 修改轮询时间
        --dbms_job.interval(jobno, interval);
				dbms_job.remove(jobno); 
				dbms_job.submit(jobno,'P_YJJK_YW_YWJZ('''||yjgzbm||''','''||(''||jzfw)||''','||TSDXID||');',sysdate,interval);
        update yjjk_dm_yjgzjz z set z.jobid = jobno where z.guid = yjkzjzid;
  elsif  lx='3' THEN   --删除job    
        dbms_job.remove(jobno); 
  elsif  lx='4' THEN   --启用job   
        dbms_job.run(jobno); 
  elsif  lx='5' THEN   --停用job     
        dbms_job.BROKEN(jobno,TRUE); 
  END IF;
end;

/

