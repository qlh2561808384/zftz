create PROCEDURE P_YHGL_ZXYZ(--用户管理系统注销验证
                 yhguid      IN  varchar2,--申请附表yhgl_yw_yhyy.guid,逗号分割
                 v_isok  OUT VARCHAR2,--1允许2不允许
                 v_error  OUT VARCHAR2--错误信息
                 ) IS
v_count number;
v_count1 number;
/*用户权限申请保存时，校验是否岗位冲突，1通过，2不通过*/
BEGIN
      v_isok:='1';
      select count(*) into v_count from yhgl_yw_yhyy t where t.yybm='FSZG'
      and t.guid in (select regexp_substr(yhguid, '[^,]+', 1, rownum) yhguid
                        from dual connect by rownum <=length(regexp_replace(yhguid, '[^,]', null)) + 1);
      if v_count>=1 then
       select count(*) into v_count1 from yhgl_yw_yhyy t,jczl.operator o,fszg_pj_billcheck p where t.yybm='FSZG'
              and t.guid in (select regexp_substr(yhguid, '[^,]+', 1, rownum) yhguid
                        from dual connect by rownum <=length(regexp_replace(yhguid, '[^,]', null)) + 1)
              and t.yhzh=o.code and o.guid=p.userguid;
              if v_count1>=1 then
                v_isok:=2;
                v_error:='注销的用户存在未收回的票据，请在非税征管系统中收回后，再注销!';
                end if;
                end if;
Dbms_output.put_line(v_isok);
Dbms_output.put_line(v_error);
end P_YHGL_ZXYZ;
/

