create trigger GET_CZFGID
  before insert
  on CZFX_DJDP_ZCFG
  for each row
  declare
  NEXT_ID number;
begin
  select SEQ_dj.NEXTVAL into NEXT_ID from dual;
  :NEW.ID:=NEXT_ID;
end get_czfgid;
/

