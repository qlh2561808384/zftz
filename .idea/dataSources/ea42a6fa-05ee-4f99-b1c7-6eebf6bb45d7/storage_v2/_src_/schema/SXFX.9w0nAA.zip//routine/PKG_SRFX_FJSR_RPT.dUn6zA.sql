create PROCEDURE PKG_SRFX_FJSR_RPT(
   v_ny in number
  )
  IS
  BEGIN
  --删除同一时间同一汇总类型的数据
  delete from srfx_fjsr_rpt where ny=v_ny;
  commit;
  --插入月汇总数据
  insert into srfx_fjsr_rpt
  select /*+parallel(r 4) */ v_ny ny,0 lxbm,sjly , case when r.zsxm_dm='10101' and yskm_dm like '101010301%' then '101010301'
     when r.zsxm_dm='10101' and yskm_dm like '101010302%' then '101010302'
     when r.zsxm_dm='10101' and yskm_dm like '1010101%' then '1010101'
     when r.zsxm_dm='10101' and yskm_dm like '1010104%' then '1010104'
     when r.zsxm_dm='10102' and yskm_dm not like '1010202%' then '1010222'
     else r.zsxm_dm end szbm,
      sum( se_ylj)/10000 sxs,
     sum(case when czfp_dm in (select czfp_dm from srfx_dm_czfp start with czfp_dm='10608001' connect by prior czfp_dm=sjczfpdm) then se_ylj else 0 end)/10000 szs,
     sum(case when czfp_dm in (select czfp_dm from srfx_dm_czfp start with czfp_dm='10608004' connect by prior czfp_dm=sjczfpdm) then se_ylj else 0 end)/10000 pjxq,
     sum(case when czfp_dm in (select czfp_dm from srfx_dm_czfp start with czfp_dm='10608005' connect by prior czfp_dm=sjczfpdm) then se_ylj else 0 end)/10000 gxq,
     sum(case when czfp_dm in (select czfp_dm from srfx_dm_czfp start with czfp_dm='10608006' connect by prior czfp_dm=sjczfpdm) then se_ylj else 0 end)/10000 bhxc,
     sum(case when czfp_dm in (select czfp_dm from srfx_dm_czfp start with czfp_dm='33060002' connect by prior czfp_dm=sjczfpdm) then se_ylj else 0 end)/10000 ycqhgxq,
     sum(case when czfp_dm in (select czfp_dm from srfx_dm_czfp start with czfp_dm='33060010' connect by prior czfp_dm=sjczfpdm) then se_ylj else 0 end)/10000 kqq,
     sum(case when czfp_dm in (select czfp_dm from srfx_dm_czfp start with czfp_dm='33060040' connect by prior czfp_dm=sjczfpdm) then se_ylj else 0 end)/10000 syq,
     sum(case when czfp_dm in (select czfp_dm from srfx_dm_czfp start with czfp_dm='33060030' connect by prior czfp_dm=sjczfpdm) then se_ylj else 0 end)/10000 zjs,
     sum(case when czfp_dm in (select czfp_dm from srfx_dm_czfp start with czfp_dm='33062400' connect by prior czfp_dm=sjczfpdm) then se_ylj else 0 end)/10000 xcq,
     sum(case when czfp_dm in (select czfp_dm from srfx_dm_czfp start with czfp_dm='33060050' connect by prior czfp_dm=sjczfpdm) then se_ylj else 0 end)/10000 shengzs,max(sysdate)
     from SRFX_RTK_SRTJ r
     where ny=v_ny
     group by
     case when r.zsxm_dm='10101' and yskm_dm like '101010301%' then '101010301'
     when r.zsxm_dm='10101' and yskm_dm like '101010302%' then '101010302'
          when r.zsxm_dm='10101' and yskm_dm like '1010101%' then '1010101'
          when r.zsxm_dm='10101' and yskm_dm like '1010104%' then '1010104'
          when r.zsxm_dm='10102' and yskm_dm not like '1010202%' then '1010222'
          else r.zsxm_dm end,sjly;
     commit;
     ----插入年汇总数据
     commit;

     insert into srfx_fjsr_rpt
  select /*+parallel(r 4) */ v_ny ny,1 lxbm,sjly , case when r.zsxm_dm='10101' and yskm_dm like '101010301%' then '101010301'
     when r.zsxm_dm='10101' and yskm_dm like '101010302%' then '101010302'
     when r.zsxm_dm='10101' and yskm_dm like '1010101%' then '1010101'
     when r.zsxm_dm='10101' and yskm_dm like '1010104%' then '1010104'
     when r.zsxm_dm='10102' and yskm_dm not like '1010202%' then '1010222'
     else r.zsxm_dm end szbm,
      sum( se_nlj)/10000 sxs,
     sum(case when czfp_dm in (select czfp_dm from srfx_dm_czfp start with czfp_dm='10608001' connect by prior czfp_dm=sjczfpdm) then se_nlj else 0 end)/10000 szs,
     sum(case when czfp_dm in (select czfp_dm from srfx_dm_czfp start with czfp_dm='10608004' connect by prior czfp_dm=sjczfpdm) then se_nlj else 0 end)/10000 pjxq,
     sum(case when czfp_dm in (select czfp_dm from srfx_dm_czfp start with czfp_dm='10608005' connect by prior czfp_dm=sjczfpdm) then se_nlj else 0 end)/10000 gxq,
     sum(case when czfp_dm in (select czfp_dm from srfx_dm_czfp start with czfp_dm='10608006' connect by prior czfp_dm=sjczfpdm) then se_nlj else 0 end)/10000 bhxc,
     sum(case when czfp_dm in (select czfp_dm from srfx_dm_czfp start with czfp_dm='33060002' connect by prior czfp_dm=sjczfpdm) then se_nlj else 0 end)/10000 ycqhgxq,
     sum(case when czfp_dm in (select czfp_dm from srfx_dm_czfp start with czfp_dm='33060010' connect by prior czfp_dm=sjczfpdm) then se_nlj else 0 end)/10000 kqq,
     sum(case when czfp_dm in (select czfp_dm from srfx_dm_czfp start with czfp_dm='33060040' connect by prior czfp_dm=sjczfpdm) then se_nlj else 0 end)/10000 syq,
     sum(case when czfp_dm in (select czfp_dm from srfx_dm_czfp start with czfp_dm='33060030' connect by prior czfp_dm=sjczfpdm) then se_nlj else 0 end)/10000 zjs,
     sum(case when czfp_dm in (select czfp_dm from srfx_dm_czfp start with czfp_dm='33062400' connect by prior czfp_dm=sjczfpdm) then se_nlj else 0 end)/10000 xcq,
     sum(case when czfp_dm in (select czfp_dm from srfx_dm_czfp start with czfp_dm='33060050' connect by prior czfp_dm=sjczfpdm) then se_nlj else 0 end)/10000 shengzs,max(sysdate)
     from SRFX_RTK_SRTJ r
     where ny=v_ny
     group by
     case when r.zsxm_dm='10101' and yskm_dm like '101010301%' then '101010301'
     when r.zsxm_dm='10101' and yskm_dm like '101010302%' then '101010302'
          when r.zsxm_dm='10101' and yskm_dm like '1010101%' then '1010101'
          when r.zsxm_dm='10101' and yskm_dm like '1010104%' then '1010104'
          when r.zsxm_dm='10102' and yskm_dm not like '1010202%' then '1010222'
          else r.zsxm_dm end,sjly;
     commit;
  END PKG_SRFX_FJSR_RPT;
/

