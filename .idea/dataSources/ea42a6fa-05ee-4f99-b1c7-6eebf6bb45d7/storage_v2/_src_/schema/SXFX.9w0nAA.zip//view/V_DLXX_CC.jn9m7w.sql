create view V_DLXX_CC as
  select t.yybm,t.ssxzqh,t.nd value,t.sr je1,t.bj je2,t.lx je3 from v_tdcb_dlxx_tdsyqk t
/

