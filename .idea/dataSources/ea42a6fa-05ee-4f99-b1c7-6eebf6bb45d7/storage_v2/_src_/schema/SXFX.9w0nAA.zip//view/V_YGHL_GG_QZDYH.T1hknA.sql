create view V_YGHL_GG_QZDYH as
  select ryqz.GUID||','||yy.guid id, ryqz.GUID,  ryqz.MC,  ryqz.FZLX,   ryqz.MS,  ryqz.CJYHID,  ryqz.CJSJ,  ryqz.ZT, ryqz.SSYYBM,  ryqz.PID,  ryqz.SSYYID,yy.guid userid
--按单位查询用户
from yhgl_gg_ryqz ryqz ,yhgl_gg_ryqzfb ryqzfb,yhgl_yw_yhyy yy  where ryqz.fzlx ='1' and ryqz.guid = ryqzfb.qzid and   ryqz.SSYYBM = yy.yybm and  ryqzfb.qzval = yy.szdwid
union all
--按角色查询用户
select ryqz.GUID||','||yy.guid id, ryqz.GUID,  ryqz.MC,  ryqz.FZLX, ryqz.MS,  ryqz.CJYHID,  ryqz.CJSJ,  ryqz.ZT, ryqz.SSYYBM,  ryqz.PID,  ryqz.SSYYID,yy.guid userid
from yhgl_gg_ryqz ryqz ,yhgl_gg_ryqzfb ryqzfb, yhgl_yw_yhyy yy where  ryqz.fzlx ='2' and ryqz.guid = ryqzfb.qzid  and  ryqz.SSYYBM = yy.yybm and  ','||yy.gwid||',' like '%,'||ryqzfb.qzval||',%'
 union all
--按指定人员id查询用户
select ryqz.GUID||','||ryqzfb.QZVAL id, ryqz.GUID,  ryqz.MC,  ryqz.FZLX,  ryqz.MS,  ryqz.CJYHID,  ryqz.CJSJ,  ryqz.ZT, ryqz.SSYYBM,  ryqz.PID,  ryqz.SSYYID,yy.guid userid
from yhgl_gg_ryqz ryqz ,yhgl_gg_ryqzfb ryqzfb, yhgl_yw_yhyy yy ,yhgl_yw_yh y  where ryqz.fzlx ='3' and ryqz.guid = ryqzfb.qzid and y.guid=yy.yhid and y.guid=ryqzfb.qzval
/

