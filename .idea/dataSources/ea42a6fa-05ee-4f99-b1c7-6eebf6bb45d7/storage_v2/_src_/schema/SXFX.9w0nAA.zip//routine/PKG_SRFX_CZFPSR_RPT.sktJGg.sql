create PROCEDURE PKG_SRFX_CZFPSR_RPT(
   v_ny in number
  )IS
  BEGIN
  delete from srfx_czfpsr_rpt where ny=v_ny;
  commit;
  --导入月汇总数据
  insert into srfx_czfpsr_rpt
select /*+parallel(r 4) */v_ny,0,sjly, r.czfp_dm czfp_dm,case when r.zsxm_dm='10101' and yskm_dm like '101010301%' then '101010301'
     when r.zsxm_dm='10101' and yskm_dm like '101010302%' then '101010302'
     when r.zsxm_dm='10101' and yskm_dm like '1010101%' then '1010101'
     when r.zsxm_dm='10101' and yskm_dm like '1010104%' then '1010104'
     when r.zsxm_dm='10102' and yskm_dm not like '1010202%' then '1010222'
     else r.zsxm_dm end szbm,
     sum( se_ylj)/10000 sxs
     from SRFX_RTK_SRTJ r
     where ny=v_ny
     group by sjly,r.czfp_dm ,case when r.zsxm_dm='10101' and yskm_dm like '101010301%' then '101010301'
     when r.zsxm_dm='10101' and yskm_dm like '101010302%' then '101010302'
     when r.zsxm_dm='10101' and yskm_dm like '1010101%' then '1010101'
     when r.zsxm_dm='10101' and yskm_dm like '1010104%' then '1010104'
     when r.zsxm_dm='10102' and yskm_dm not like '1010202%' then '1010222'
     else r.zsxm_dm end;
     commit;
    ----导入年汇总数据
    insert into srfx_czfpsr_rpt
select /*+parallel(r 4) */v_ny,1,sjly, r.czfp_dm czfp_dm,case when r.zsxm_dm='10101' and yskm_dm like '101010301%' then '101010301'
     when r.zsxm_dm='10101' and yskm_dm like '101010302%' then '101010302'
     when r.zsxm_dm='10101' and yskm_dm like '1010101%' then '1010101'
     when r.zsxm_dm='10101' and yskm_dm like '1010104%' then '1010104'
     when r.zsxm_dm='10102' and yskm_dm not like '1010202%' then '1010222'
     else r.zsxm_dm end szbm,
     sum( se_nlj)/10000 sxs
     from SRFX_RTK_SRTJ r
     where ny=v_ny
     group by sjly,r.czfp_dm ,case when r.zsxm_dm='10101' and yskm_dm like '101010301%' then '101010301'
     when r.zsxm_dm='10101' and yskm_dm like '101010302%' then '101010302'
     when r.zsxm_dm='10101' and yskm_dm like '1010101%' then '1010101'
     when r.zsxm_dm='10101' and yskm_dm like '1010104%' then '1010104'
     when r.zsxm_dm='10102' and yskm_dm not like '1010202%' then '1010222'
     else r.zsxm_dm end;
     commit;
  END PKG_SRFX_CZFPSR_RPT;
/

