create function F_DN_REPORT_YJG(v_yyid  in VARCHAR2, -- 知识库中的应用ID
                                                  v_jszmc in VARCHAR2, -- 计算值唯一名称
                                                  v_cszh  in VARCHAR2 -- 参数组合串，格式如：NIAN=2018;YUE=7;DQ=311200;
                                                  ) return boolean is
  V_OK        boolean;
  v_cszh_guid VARCHAR2(50);
  rsCursor    SYS_REFCURSOR;
  v_zdmc      VARCHAR2(50);
begin
  V_OK := true;

  -- 删除当前计算值及参数组合串的记录
  begin
    select guid
      into v_cszh_guid
      from dn_cc_jsz_cs_zh
     where YYID = v_yyid
       and JSZMC = v_jszmc
       and CSZHNR = v_cszh;
    delete from dn_cc_jsz_cs_zh
     where YYID = v_yyid
       and JSZMC = v_jszmc
       and CSZHNR = v_cszh;
    delete from dn_cc_jsz_zd_jg where CSZH_GUID = v_cszh_guid;
  exception
    when others then
      v_cszh_guid := null;
  end;

  -- 新增参数组合表记录
  v_cszh_guid := sys_guid();
  insert into dn_cc_jsz_cs_zh
    (guid, yyid, jszmc, cszhnr)
  values
    (v_cszh_guid, v_yyid, v_jszmc, v_cszh);
  -- 循环新增字段结果 TODO: 表DN_TMP_JSZ_ZD替换成DN_DY_JSZ_ZD
  OPEN rsCursor for
    select ZDMC
      from DN_TMP_JSZ_ZD
     where YYID = v_yyid
       and JSZMC = v_jszmc;
  loop
    fetch rsCursor
      into v_zdmc;
    exit when rsCursor%NOTFOUND;
    insert into dn_cc_jsz_zd_jg
    values
      (sys_guid(),
       v_cszh_guid,
       v_zdmc,
       abs(mod(dbms_random.random, 1000000000) / 100));
  end loop;
  close rsCursor;

  commit;

  return(V_OK);
end F_DN_REPORT_YJG;
/

