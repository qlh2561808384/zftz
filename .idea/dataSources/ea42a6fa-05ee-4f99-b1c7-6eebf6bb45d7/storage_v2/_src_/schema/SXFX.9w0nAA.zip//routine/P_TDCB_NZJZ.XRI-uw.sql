create PROCEDURE P_TDCB_NZJZ(
NF IN VARCHAR2,     --年份
BM IN VARCHAR2,     --编码
RES out VARCHAR2    --返回结果(0:成功 非0:失败)
) IS
  YSZC       NUMBER:=0;       --预算支出合计
  YSZWSR     NUMBER:=0;       --预算债务收入

  SJZC       NUMBER:=0;       --实际支出合计
  SJZWSR     NUMBER:=0;       --实际债务收入

  SNJZ       NUMBER:=0;       --上年结转
  CZSR       NUMBER:=0;       --财政收入
  JYJZ       NUMBER:=0;       --结余结转下年

  YSZC_SQL   VARCHAR2(500);   --计算预算支出合计
  YSZWSR_SQL VARCHAR2(500);   --计算预算债务收入

  SJZC_SQL   VARCHAR2(500);   --计算实际支出合计
  SJZWSR_SQL VARCHAR2(500);   --计算实际债务收入

  SNJZ_SQL VARCHAR2(500);     --计算上年结转

  FLAG1       NUMBER:=0;      --判断上年结转数是否存在，1存在，0不存在
  FLAG2      NUMBER:=0;       --判断下年结转数是否存在，1存在，0不存在

  XXBID      NUMBER:=0;       --结余结转数编码
  XXBBM      NUMBER:=0;       --结余结转数年份
  XXBMC      NUMBER:=0;       --结余结转数金额
  XXBLX      VARCHAR2(50);     --结余结转数类型
  XXBMS      VARCHAR2(50);     --结余结转数描述
BEGIN
  /*计算结余结转数*/ 
  RES:='-1';
  IF(BM = '01' OR BM = '02')
  THEN
  --预算支出合计(不包括债务利息)
  YSZC_SQL := ' select sum(t.num) from('||
              ' select sum(t4.je) num from tdcb_tdcbszys t4' ||
              ' where (t4.szxmbm = ''1001'' '||'or t4.szxmbm = ''1002'' '||'or t4.szxmbm = ''1003'''||
              ' or t4.szxmbm = ''1004'' '||'or t4.szxmbm = ''1005'' '||'or t4.szxmbm = ''1007'' '||'or t4.szxmbm = ''1099'')'||' and t4.nd = '||NF||
              ' and exists(select t6.xmid from tdcb_xmdj t6 where t6.xmid = t4.xmid and t6.xmzt <> 99)'||
              ' group by t4.nd'||
              ' union all select sum(t5.yflx) num from tdcb_czjh t5 where'||
              ' to_number(to_char(t5.rq,'||'''yyyy'''||')) = '||NF||' group by t5.xmid'||
              ' union all select 0 num from dual) t';
  EXECUTE IMMEDIATE YSZC_SQL INTO YSZC;

  --预算债务收入
  YSZWSR_SQL := ' select sum(t.num) from('||
                ' select sum(t9.zq_sqe) num from tdcb_xmdj t9 where t9.zq_zqnd = '||NF||
                ' and t9.xmzt <> 99 group by t9.zq_zqnd'||
                ' union all select 0 num from dual) t';
  EXECUTE IMMEDIATE YSZWSR_SQL INTO YSZWSR;

  --上年结转
  --判断上年结转数是否存在
  SELECT COUNT(*) INTO FLAG1 FROM tdcb_xxb t WHERE t.lx = 'snjzjs' AND t.bm = NF;
  --存在则取出
  IF(FLAG1>0)
  THEN
   SNJZ_SQL := ' select t8.mc from tdcb_xxb t8 where t8.lx = ''snjzjs'' and t8.bm = '|| ''''||NF|| '''';
  EXECUTE IMMEDIATE SNJZ_SQL INTO SNJZ;
  --不存在值为零
  ELSE SNJZ:=0;
  end if;

  --获得财政收入
  CZSR := YSZC - YSZWSR - SNJZ;


  --实际支出合计
  SJZC_SQL := ' select sum(t.num) from('||
              ' select sum(t4.je)/10000 num from tdcb_sjzcpz t3,tdcb_pzmx t4 where t3.zwnd = t4.zwnd and t3.pzhm = t4.pzhm'||
              ' and t4.zcxmid in('||'''1001'''||','||'''1002'''||','||'''1003'''||','||'''1004'''||','||'''1005'''||','||'''1007'''||','||'''1099'''||')'||
              ' and to_number(to_char(t3.zcrq,'||'''yyyy'''||')) = '||NF||
              ' group by to_number(to_char(t3.zcrq,'||'''yyyy'''||'))'||
              ' union all select 0 num from dual) t';
  EXECUTE IMMEDIATE SJZC_SQL INTO SJZC;

  --实际债务收入
  SJZWSR_SQL := ' select sum(t.num) from('||
                ' select sum(t9.zq_sje) num from tdcb_xmdj t9 where t9.zq_zqnd = '||NF||
                ' and t9.xmzt <> 99 group by t9.zq_zqnd'||
                ' union all select 0 num from dual) t';
  EXECUTE IMMEDIATE SJZWSR_SQL INTO SJZWSR;

  --结余结转下年
  JYJZ:= CZSR + SJZWSR + SNJZ - SJZC;


  /*结余结转数数据落地*/
  XXBMC:=JYJZ;
  
  --判断下年结转数是否存在
  --判断是清算结转还是决算结转
  IF(BM = '01')
  THEN
   XXBLX:='snjzqs';
   XXBMS:='上年结转清算';
  ELSIF(BM = '02')
  THEN
   XXBLX:='snjzjs';
   XXBMS:='上年结转决算';
  ELSE
   XXBLX:='ERROR';
   XXBMS:='结转类型错误';
  END IF;
  XXBBM:=to_char(to_number(NF)+1);
  SELECT COUNT(*) INTO FLAG2 FROM tdcb_xxb t WHERE t.lx = XXBLX AND t.bm = XXBBM;

  --下年结转数存在则更新记录
  IF(FLAG2>0)
  then
  SELECT t.id INTO XXBID FROM tdcb_xxb t WHERE t.lx = XXBLX AND t.bm = XXBBM;
  --SELECT t.bm INTO XXBBM FROM tdcb_xxb t WHERE t.lx = 'snjzjs' AND t.bm = NF;
  --SELECT t.mc INTO XXBMC FROM tdcb_xxb t WHERE t.lx = 'snjzjs' AND t.bm = NF;
  UPDATE TDCB_XXB SET(BM, MC, FJBM, YXBZ, LX, MS) = (SELECT XXBBM,XXBMC,'0','Y',XXBLX,XXBMS FROM dual) WHERE ID = XXBID;
  COMMIT;
  RES :=0;
  --下年结转数不存在则插入一条新记录
  ELSE
  INSERT INTO TDCB_XXB (BM, MC, FJBM, YXBZ, LX, MS) VALUES(XXBBM,XXBMC,'0','Y',XXBLX,XXBMS);
  COMMIT;
  RES :=0;
  end if;
  END IF;
END P_TDCB_NZJZ;
/

