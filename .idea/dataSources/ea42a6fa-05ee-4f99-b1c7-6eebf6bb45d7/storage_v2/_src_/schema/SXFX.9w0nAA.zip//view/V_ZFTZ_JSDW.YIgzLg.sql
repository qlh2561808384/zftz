create view V_ZFTZ_JSDW as
  select t.C_ID id,
       t.C_ORG_CODE bm,
       t.C_ORGNAME mc,
       t.C_PARENT_ID fjbm,
       case
         when t.C_DELETED = 0 then
          'Y'
         else
          'N'
       end yxbz,
       '' bz from mv_cos_organization_org t start with t.C_ID=56150342  connect by prior t.C_ID=t.C_PARENT_ID
       order by t.C_ORG_CODE
/

