create view V_ZFTZ_XMYSGL_YSAP as
  select a.id_zftz_xm,--预算安排，含手工录入部分和金财部分，其中资金来源是1,2,4的取自金财工程
       a.nd,
       a.zjly,
       case
         when a.zjly in (1, 2, 4) then
          nvl(b.je,0)
         else
          nvl(a.je,0)
       end ysap_je
  from zftz_xmysgl a
  left join (select t.id_zftz_xmysgl, nvl(sum(t1.je),0) je
               from zftz_xmysdyzbmx t, v_zftz_jc_dwzb t1
              where t.zbid = t1.budgetid
                and t.zjlybm = t1.id
              group by t.id_zftz_xmysgl) b
    on a.id = b.id_zftz_xmysgl
/

