create package pkg_bmys is
  type cur is ref cursor;

  procedure GET_CZFX_BMYS_YSMX(riqi varchar2);
  procedure GET_CZFX_DM_YSDWFWJGZW(riqi varchar2);
  procedure GET_CZFX_DM_YSDWJDC(riqi varchar2);
  procedure GET_CZFX_DM_YSDWKZ(riqi varchar2);  
  procedure GET_CZFX_DM_YSDWRY(riqi varchar2);  


end pkg_bmys;
/

