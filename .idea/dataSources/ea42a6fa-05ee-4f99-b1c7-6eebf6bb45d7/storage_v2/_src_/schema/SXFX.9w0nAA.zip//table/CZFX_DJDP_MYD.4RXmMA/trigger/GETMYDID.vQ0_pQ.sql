create trigger GETMYDID
  before insert
  on CZFX_DJDP_MYD
  for each row
  declare
  NEXT_ID number;
begin
  select SEQ_myd.NEXTVAL into NEXT_ID from dual;
  :NEW.ID:=NEXT_ID;
end getMydId;
/

