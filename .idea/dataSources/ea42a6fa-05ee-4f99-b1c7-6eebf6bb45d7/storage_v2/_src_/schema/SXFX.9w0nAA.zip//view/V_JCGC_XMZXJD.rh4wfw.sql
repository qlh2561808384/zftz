create view V_JCGC_XMZXJD as
  select e.guid ,
       e.isbn_code 单位编码,
       e.name 单位名称,
       b.programguid 项目id,
       b.programname 项目名称,
       decode(sum(b.money), 0, 0, round(Sum(b.pmoney) / sum(b.money), 2)) 进度
  from zjsb.budget b, jczl.enterprise e
 where b.enterpriseguid = e.guid
   and b.programtypecode = 3
      --and e.isbn_code = '221001'  --接收“单位类型按钮对应的 bm”
   and e.enabled = 1
   and e.year = to_char(sysdate, 'yyyy')
 group by e.guid, e.isbn_code, e.name, b.programguid, b.programname
 order by decode(sum(b.money), 0, 0, round(Sum(b.pmoney) / sum(b.money), 2)) desc
/

