create PROCEDURE P_YHGL_BCYZ(
                 gwid      IN  varchar2,--岗位ID
                 yybm      IN  varchar2,--应用编码
                 dlm      IN  varchar2,--登录名
                 zjhm      IN  varchar2,--身份证号
                 xm      IN  varchar2,--姓名
                 lx      IN  varchar2,--类型
                 yhszdw      IN  varchar2,--主信息所属单位
                 ssgkcs      IN  varchar2,--归口处室
                 szdwid      IN  varchar2,--账号所属单位
                 v_isok  OUT VARCHAR2,
                 v_error  OUT VARCHAR2
                 ) IS
v_count number;
/*用户权限申请保存时，校验是否岗位冲突，1通过，2不通过*/
BEGIN
      v_isok:='1';
      if yybm='JZZF' then
        select count(*) into v_count from YHGL_DM_YYGW t where ssyybm='JZZF' and t.gwlx='2' 
        and t.guid in(select regexp_substr(gwid, '[^,]+', 1, rownum) gwid 
                        from dual connect by rownum <=length(regexp_replace(gwid, '[^,]', null)) + 1);
       if v_count>=2 then
         v_isok:='2';
         v_error:='岗位冲突(集中支付，不能同时是会计和出纳)';
         else
           v_isok:='1';
            end if;
            elsif yybm='ZFCG' then 
            -----------
            select count(*) into v_count from YHGL_DM_YYGW t where ssyybm='ZFCG' and t.gwlx='2' 
            and t.guid in (221,222)  
            and t.guid in(select regexp_substr(gwid, '[^,]+', 1, rownum) gwid 
                        from dual connect by rownum <=length(regexp_replace(gwid, '[^,]', null)) + 1);
       if v_count>=2 then
         v_isok:='2';
         v_error:='岗位冲突(政府采购，不能同时是单位经办和审核)';
         else
           v_isok:='1';
            end if;
            ------------
      end if;
      


Dbms_output.put_line(v_isok);
Dbms_output.put_line(v_error);
end P_YHGL_BCYZ;
/

