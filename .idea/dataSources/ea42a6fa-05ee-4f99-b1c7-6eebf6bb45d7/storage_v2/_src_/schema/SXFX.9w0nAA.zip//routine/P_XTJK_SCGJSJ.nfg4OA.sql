create procedure p_xtjk_scgjsj (
                               gjflyjbm in VARCHAR2,  --告警分类一级编码
                               gjflbm  in VARCHAR2,   --告警分类编码
                               gjdx in VARCHAR2,      --告警对象（所属应用）
                               gjsj_bm in VARCHAR2,    --告警数据编码（判断重复）
                               gjjb in number,        --告警级别(3紧急|2严重|1一般|0可忽略)
                               bt in VARCHAR2,        --标题
                               ccfssj in timestamp,   --告警初次发生时间
                               bcfssj in timestamp,   --告警本次发生时间
                               fscs in number,        --告警发生次数
                               tsdxid in VARCHAR2,       --推送对象（待处理人分组）
                               zt in VARCHAR2,        --状态(0为处理中，1为已结束)
                               rzjs in VARCHAR2       --日志简述
                               ) as

gjsjid NUMBER(15);
sl    NUMBER(15);

begin
   select count(*) into sl from xtjk_yw_gjsj m where m.zt='0' and gjsjbm=gjsj_bm;

   if sl=0 then
     gjsjid:=SEQ_XTJK_YW_GJSJ.nextval;
     --第一次插入主表和明细表
     insert into XTJK_YW_GJSJ(guid,gjflyjbm,gjflbm,gjdx,gjsjbm,gjjb,bt,ccfssj,bcfssj,fscs,tsdxid,zt)
               values(gjsjid,gjflyjbm,gjflbm,gjdx,gjsj_bm,gjjb,bt,ccfssj,bcfssj,fscs,tsdxid,zt);

     insert into XTJK_YW_GJSJMX(guid,gjsjid,fssj,sm,xzsj)
               values(SEQ_XTJK_YW_GJSJMX.nextval,gjsjid,bcfssj,rzjs,bcfssj);
     --插入处理记录
     insert into XTJK_YW_GJSJCLJL(guid,gjsjid,SYHJID,YHID2)
               values(SEQ_XTJK_YW_GJSJCLJL.nextval,gjsjid,SEQ_XTJK_YW_GJSJCLJL.nextval,tsdxid);

     --告警级别为可忽略的自动消除
     if gjjb = 0 then
        update XTJK_YW_GJSJ set zt='1',gjxcr =tsdxid where gjsjbm = gjsj_bm;

        insert into XTJK_YW_GJSJCLJL(GUID,GJSJID,SYHJID,YHID2,SM,CLCZ,CLSJ,YHTSDXID,XYHJTSDXID)
                   values(SEQ_XTJK_YW_GJSJCLJL.nextval,gjsjid,SEQ_XTJK_YW_GJSJCLJL.nextval,'','','21',sysdate,'','');
     end if;

     --判断本次发生时间是否在白名单内 是则修改为自动消除

     select count(1) into  sl from xtjk_yw_gjsj m where m.zt='0' and gjsjbm=gjsj_bm and exists(
        select 1 from xtjk_yw_bmd b where b.gjsjbm=m.gjsjbm and  b.starttime<=m.bcfssj and m.bcfssj<=b.endtime
     );
     if sl<>0  then
         update XTJK_YW_GJSJ set zt='1',gjxcr =tsdxid where gjsjbm = gjsj_bm;
        insert into XTJK_YW_GJSJCLJL(GUID,GJSJID,SYHJID,YHID2,SM,CLCZ,CLSJ,YHTSDXID,XYHJTSDXID)
                   values(SEQ_XTJK_YW_GJSJCLJL.nextval,gjsjid,SEQ_XTJK_YW_GJSJCLJL.nextval,'','','21',sysdate,'','');
     end if;


   else
     --主表已存在的话 直插入明细
     select max(m.guid) into gjsjid from xtjk_yw_gjsj m where gjsjbm=gjsj_bm;
     insert into XTJK_YW_GJSJMX(guid,gjsjid,fssj,sm,xzsj)
               values(SEQ_XTJK_YW_GJSJMX.nextval,gjsjid,bcfssj,rzjs,bcfssj);

   end if;






end p_xtjk_scgjsj;
/

