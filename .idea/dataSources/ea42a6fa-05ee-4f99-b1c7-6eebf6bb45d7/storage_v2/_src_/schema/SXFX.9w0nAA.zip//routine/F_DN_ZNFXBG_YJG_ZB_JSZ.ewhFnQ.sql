create function F_DN_ZNFXBG_YJG_ZB_JSZ(v_yyid  in VARCHAR2, -- 知识库中的应用ID
                                                  v_jszmc in VARCHAR2, -- 计算值唯一名称
                                                  v_cszh  in VARCHAR2 -- 参数组合串，格式如：NIAN=2018;YUE=7;DQ=311200;
                                                  ) return boolean is
  V_OK        boolean;
  v_cszh_guid VARCHAR2(50);
  rsCursor    SYS_REFCURSOR;
  v_zdmc      VARCHAR2(500);

begin
  V_OK := true;

  -- 删除当前计算值及参数组合串的记录
  begin
    select guid
      into v_cszh_guid
      from dn_cc_jsz_cs_zh
     where YYID = v_yyid
       and JSZMC = v_jszmc
       and CSZHNR = v_cszh;
    delete from dn_cc_jsz_cs_zh
     where YYID = v_yyid
       and JSZMC = v_jszmc
       and CSZHNR = v_cszh;
    delete from dn_cc_jsz_zd_jg where CSZH_GUID = v_cszh_guid;
  exception
    when others then
      v_cszh_guid := null;

  end;

  -- 新增参数组合表记录
  v_cszh_guid := sys_guid();
  insert into dn_cc_jsz_cs_zh
    (guid, yyid, jszmc, cszhnr)
  values
    (v_cszh_guid, v_yyid, v_jszmc, v_cszh);
  -- 循环新增字段结果 TODO: 表DN_TMP_JSZ_ZD替换成DN_DY_JSZ_ZD
  if(v_jszmc = 'htwv_2018_09_11202750391') then--htwv_2018_09_12113251370
  OPEN rsCursor for
    /*select ZDMC
      from DN_TMP_JSZ_ZD
     where YYID = v_yyid
       and JSZMC = v_jszmc;*/
    select ZDMC||';'||SDATA ZDMC from
    (
    select zd,sdata from (
    select year 年份,szfl 收支分类,to_char(sum(money)) 金额 from czfx_jcgc_zbmx 
    where year=substr(v_cszh,instr(v_cszh,'=')+1,4) and szfl=replace(substr(v_cszh,instr(v_cszh,'=',1,2)+1),';','')   
    group by year,szfl order by year
    )a unpivot(sdata for zd in(年份,收支分类,金额)) 
    ) a2 left join DN_DY_JSZ_ZD zd on zd.ZDMC=a2.zd
    where zd.jszmc=v_jszmc and zd.yyid=v_yyid;
  elsif(v_jszmc = 'htwv_2018_09_18161202417') then--htwv_2018_09_18161202417
  OPEN rsCursor for
    select ZDMC||';'||SDATA ZDMC from
    (
    select zd,sdata from (
    select t1.mc 行政区划,to_char(sum(t2.ylj)) 金额 from
    (select bm,mc from czfx_dm_xzqh where bm not in ( '-1','330602','33060101','3306010101','3306010102')) t1
    left join
    (select t.xzqh,sum(t.ylj_je) ylj from czfx_dyb t where t.szfl = '01' 
    and t.ny = substr(v_cszh,instr(v_cszh,'=',1,1)+1,instr(v_cszh,';',1,1)-instr(v_cszh,'=',1,1)-1) group by t.xzqh) t2
    on t2.xzqh like t1.bm||'%'
    where t1.bm = substr(v_cszh,instr(v_cszh,'=',1,2)+1,instr(v_cszh,';',1,2)-instr(v_cszh,'=',1,2)-1) group by t1.mc
    )a unpivot(sdata for zd in(行政区划,金额))
    ) a2 left join DN_DY_JSZ_ZD zd on zd.ZDMC=a2.zd
    where zd.jszmc=v_jszmc and zd.yyid=v_yyid;
  else
  OPEN rsCursor for
    select ZDMC
      from DN_TMP_JSZ_ZD
     where YYID = v_yyid
       and JSZMC = v_jszmc;
  end if;
  
  loop
    fetch rsCursor
      into v_zdmc;
    exit when rsCursor%NOTFOUND;
    insert into dn_cc_jsz_zd_jg
    values
      (sys_guid(),
       v_cszh_guid,
       substr(v_zdmc,0,instr(v_zdmc,';')-1),
       replace(substr(v_zdmc,instr(v_zdmc,';')),';',''));
  end loop;
  close rsCursor;

  commit;

  return(V_OK);
end F_DN_ZNFXBG_YJG_ZB_JSZ;
/

