create view V_JCGC_DWZXJD as
  select e.guid 单位编码,
e.isbn_code,
       e.name 单位,
       decode(sum(b.money), 0, 0, round(Sum(b.pmoney) / sum(b.money), 2)) 执行总进度
  from (select *
          from zjsb.budget
         where programtypecode = 3
           and year = to_char(sysdate, 'yyyy')) b
 right join (select *
               from jczl.enterprise
              where enabled = 1
                and isleaf = 1
                and year = to_char(sysdate, 'yyyy')
                /*and isbn_code like '221%'*/) e
    on b.enterpriseguid = e.guid
 group by e.guid,e.isbn_code,e.name
 order by decode(sum(b.money), 0, 0, round(Sum(b.pmoney) / sum(b.money), 2)) desc
/

