create view V_SJCJ_SP as
  SELECT SJCJDB.YWXTBM, SJCJDB.CODE, SJCJDB.SL  FROM
(
--数据采集局内
   select 'key' as zj,'2' as dblx,'SJCJ' as ywxtbm,'绍兴市财税局' as dwmc,a.yhzh as code,count(*) as sl,'待办事项' as btnr
      ,'http://172.23.205.169/sjgl/login_cas.jsp' as ljdz,'数据分析' as dddldz
      ,sysdate as qssj

  from (

select distinct z.id,b.yhzh
  from sjcj_rw_mx m
  left join sjcj_rw_zb z
    on z.id = m.cjpcid
  left join sjcj_dm_cjrwk d
    on z.cjrwid = d.id
  left join sjcj_dm_cjzq q
    on d.cjzqid = q.id
  left join sjcj_hjb h
    on m.zt = h.tbzt
  left join sjcj_dm_cjp c
    on z.cjpcid = c.id
  left join yhgl_dm_dw w
    on w.guid = m.jgid
  left join yhgl_yw_yhyy b
  on b.ssgkcs = d.rwqx
 where m.zt not in (0, 1)
   and w.yybm = 'YHGL'
   and instr(d.rwqx, b.ssgkcs) > 0
   and m.jgid in (select entid from mv_gg_enterdivision where deptid=b.ssgkcs)
 union all
 select distinct z.id,b.yhzh
  from sjcj_rw_mx m
  left join sjcj_rw_zb z
    on z.id = m.cjpcid
  left join sjcj_dm_cjrwk d
    on z.cjrwid = d.id
  left join sjcj_dm_cjzq q
    on d.cjzqid = q.id
  left join sjcj_hjb h
    on m.zt = h.tbzt
  left join sjcj_dm_cjp c
    on z.cjpcid = c.id
  left join yhgl_dm_dw w
    on w.guid = m.jgid
  left join yhgl_yw_yhyy b
  on b.ssgkcs = d.rwqx
 where m.zt not in (0, 1)
   and w.yybm = 'YHGL'
   and instr(d.rwqx, b.ssgkcs) > 0
   and 0 in (select entid from mv_gg_enterdivision where deptid=b.ssgkcs)
   and m.jgid in (select entid from mv_gg_enterdivision )
   ) a group by a.yhzh
   union all
   --数据采集局外
  select 'key' as zj,'2' as dblx,'SJCJ' as ywxtbm,'预算单位' as dwmc,a.yhzh as code,count(*) as sl,'待办事项' as btnr
      ,'http://172.23.205.169/sjgl/login_cas.jsp' as ljdz,'数据分析' as dddldz
      ,sysdate as qssj

  from (select distinct   b.yhzh,z.id
          from sjcj_rw_mx m
          left join sjcj_rw_zb z
            on m.cjpcid = z.id
          left join sjcj_dm_cjrwk d
            on z.cjrwid = d.id
          left join sjcj_dm_cjfs c
            on d.cjfsid = c.id
          left join sjcj_dm_cjzq q
            on d.cjzqid = q.id
          left join sjcj_hjb h
            on d.lcid = h.sslcid
           and m.zt = h.tbzt
          left join sjcj_dm_cjp p
            on z.cjpcid = p.id
          left join yhgl_yw_yhyy b
          on m.jgid=b.szdwid
         where
            to_number(replace(m.jzrq, '-', '')) >=to_number(to_char(sysdate,'yyyymmdd'))
           and to_number(replace(m.ksrq, '-', '')) <=to_number(to_char(sysdate,'yyyymmdd'))
           and m.yqjzrq is null
           and m.zt = '1'
        union
        select distinct  b.yhzh,z.id
          from sjcj_rw_mx m
          left join sjcj_rw_zb z
            on m.cjpcid = z.id
          left join sjcj_dm_cjrwk d
            on z.cjrwid = d.id
          left join sjcj_dm_cjfs c
            on d.cjfsid = c.id
          left join sjcj_dm_cjzq q
            on d.cjzqid = q.id
          left join sjcj_hjb h
            on d.lcid = h.sslcid
           and m.zt = h.tbzt
          left join sjcj_dm_cjp p
            on z.cjpcid = p.id
          left join yhgl_yw_yhyy b
           on m.jgid=b.szdwid
         where
            to_number(replace(m.yqjzrq, '-', '')) >=to_number(to_char(sysdate,'yyyymmdd'))
           and to_number(replace(m.ksrq, '-', '')) <= to_number(to_char(sysdate,'yyyymmdd'))
           and m.yqjzrq is not null
           and m.zt = '1'
        union
        select  distinct  b.yhzh,z.id
          from sjcj_rw_mx m
          left join sjcj_rw_zb z
            on m.cjpcid = z.id
          left join sjcj_dm_cjrwk d
            on z.cjrwid = d.id
          left join sjcj_dm_cjfs c
            on d.cjfsid = c.id
          left join sjcj_dm_cjzq q
            on d.cjzqid = q.id
          left join sjcj_hjb h
            on d.lcid = h.sslcid
           and m.zt = h.tbzt
          left join sjcj_dm_cjp p
            on z.cjpcid = p.id
          left join yhgl_yw_yhyy b
          on m.jgid=b.szdwid
         where
            m.ksrq is null
           and m.jzrq is null
           and m.zt = '1') a group by a.yhzh
) SJCJDB
/

