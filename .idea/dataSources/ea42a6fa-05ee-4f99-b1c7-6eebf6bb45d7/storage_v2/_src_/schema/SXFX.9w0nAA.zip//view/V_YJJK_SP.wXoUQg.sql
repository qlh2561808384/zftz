create view V_YJJK_SP as
  SELECT YJJKDB.YWXTBM, YJJKDB.CODE, YJJKDB.SL  FROM
(
--预警监控局内
           select 'key' as zj,'2' as dblx,'YJJK' as ywxtbm,'绍兴市财税局' as dwmc,a.yhzh as code,count(*) as sl,'待办事项' as btnr
      ,'http://172.23.205.169/sjgl/login_cas.jsp' as ljdz,'数据分析' as dddldz
      ,sysdate as qssj

  from (select distinct t.guid,b.yhzh

  from YJJK_YW_YJSJ t, YJJK_DM_YJFL f, YJJK_DM_LYFS l, YJJK_DM_YJGZ g,yhgl_yw_yhyy b,mv_cos_org_user o,mv_cos_organization_org g
 where t.yjflbm = f.bm
   and t.lyfs = l.bm
   and o.C_USERSCREENNAME=b.yhzh
   and g.C_ID=o.C_ID
   and g.C_ORGTYPE='01'
   and t.zt = '0'
   and t.yjgzbm = g.bm
   and g.regicode = b.regicode
   and (exists
        (select 1
           from YHGL_GG_RYQZYH y
          where t.tsdxlx = '0'
            and y.YWID = t.guid
            and y.YHID = b.guid
            and y.SSYYBM = 'YHGL') or (t.tsdxid = b.szdwid and t.tsdxlx = '1') or
        (t.tsdxid = b.guid and t.tsdxlx = '2'))
   and not exists
 (select 1
          from YJJK_YW_RWYJ r
         where (r.YJFLBM is null or t.YJFLBM = r.YJFLBM)
           and ((r.starttime is null and r.endtime is null) or
               (r.endtime >= sysdate and r.starttime is null and
               r.endtime is not null) or
               (sysdate >= r.starttime and r.starttime is not null and
               r.endtime is null) or
               (sysdate >= r.starttime and r.endtime >= sysdate and
               r.starttime is not null and r.endtime is not null))
           and r.cjyhid = b.guid
           and r.zt = '0')
UNION
select distinct s.guid,b.yhzh
  from yjjk_yw_yjsj s, YJJK_YW_RWYJ y, YJJK_DM_YJFL f, YJJK_DM_LYFS l,yhgl_yw_yhyy b,mv_cos_org_user o,mv_cos_organization_org g
 where (y.YJFLBM is null or s.YJFLBM = y.YJFLBM)
   and s.yjflbm = f.bm
   and s.lyfs = l.bm
   and o.C_USERSCREENNAME=b.yhzh
   and g.C_ID=o.C_ID
   and g.C_ORGTYPE='01'
   and ((y.starttime is null and y.endtime is null) or
       (y.endtime >= sysdate and y.starttime is null and
       y.endtime is not null) or
       (sysdate >= y.starttime and y.starttime is not null and
       y.endtime is null) or
       (sysdate >= y.starttime and y.endtime >= sysdate and
       y.starttime is not null and y.endtime is not null))
   and s.ZT = '0'
   and ((y.tsdxlx = '0' and exists
        (select 1
            from YHGL_GG_RYQZYH v1
           where s.TSDXID = v1.qzid
             and y.CJYHID = v1.yhid) and exists
        (select 1
            from YHGL_GG_RYQZYH v2
           where y.TSDXID = V2.qzid
             and V2.yhid = b.guid)) or (y.tsdxlx = '1' and y.tsdxid = b.szdwid) or
       (y.tsdxlx = '2' and y.tsdxid = b.guid) or
       (y.tsdxlx = '0' and (s.tsdxlx = '2' or s.tsdxlx = '1') and exists
        (select 1
            from YHGL_GG_RYQZYH v
           where y.tsdxid = v.qzid
             and v.yhid = b.guid)))
) a group by a.yhzh

union all
--预警监控局外
select 'key' as zj,'2' as dblx,'YJJK' as ywxtbm,'预算单位' as dwmc,a.yhzh as code,count(*) as sl,'待办事项' as btnr
      ,'http://172.23.205.169/sjgl/login_cas.jsp' as ljdz,'数据分析' as dddldz
      ,sysdate as qssj

  from (select distinct t.guid,b.yhzh

  from YJJK_YW_YJSJ t, YJJK_DM_YJFL f, YJJK_DM_LYFS l, YJJK_DM_YJGZ g,yhgl_yw_yhyy b,mv_cos_org_user o,mv_cos_organization_org g
 where t.yjflbm = f.bm
   and t.lyfs = l.bm
   and o.C_USERSCREENNAME=b.yhzh
   and g.C_ID=o.C_ID
   and g.C_ORGTYPE!='01'
   and t.zt = '0'
   and t.yjgzbm = g.bm
   and g.regicode = b.regicode
   and (exists
        (select 1
           from YHGL_GG_RYQZYH y
          where t.tsdxlx = '0'
            and y.YWID = t.guid
            and y.YHID = b.guid
            and y.SSYYBM = 'YHGL') or (t.tsdxid = b.szdwid and t.tsdxlx = '1') or
        (t.tsdxid = b.guid and t.tsdxlx = '2'))
   and not exists
 (select 1
          from YJJK_YW_RWYJ r
         where (r.YJFLBM is null or t.YJFLBM = r.YJFLBM)
           and ((r.starttime is null and r.endtime is null) or
               (r.endtime >= sysdate and r.starttime is null and
               r.endtime is not null) or
               (sysdate >= r.starttime and r.starttime is not null and
               r.endtime is null) or
               (sysdate >= r.starttime and r.endtime >= sysdate and
               r.starttime is not null and r.endtime is not null))
           and r.cjyhid = b.guid
           and r.zt = '0')
UNION
select distinct s.guid,b.yhzh
  from yjjk_yw_yjsj s, YJJK_YW_RWYJ y, YJJK_DM_YJFL f, YJJK_DM_LYFS l,yhgl_yw_yhyy b,mv_cos_org_user o,mv_cos_organization_org g
 where (y.YJFLBM is null or s.YJFLBM = y.YJFLBM)
   and s.yjflbm = f.bm
   and s.lyfs = l.bm
   and o.C_USERSCREENNAME=b.yhzh
   and g.C_ID=o.C_ID
   and g.C_ORGTYPE!='01'
   and ((y.starttime is null and y.endtime is null) or
       (y.endtime >= sysdate and y.starttime is null and
       y.endtime is not null) or
       (sysdate >= y.starttime and y.starttime is not null and
       y.endtime is null) or
       (sysdate >= y.starttime and y.endtime >= sysdate and
       y.starttime is not null and y.endtime is not null))
   and s.ZT = '0'
   and ((y.tsdxlx = '0' and exists
        (select 1
            from YHGL_GG_RYQZYH v1
           where s.TSDXID = v1.qzid
             and y.CJYHID = v1.yhid) and exists
        (select 1
            from YHGL_GG_RYQZYH v2
           where y.TSDXID = V2.qzid
             and V2.yhid = b.guid)) or (y.tsdxlx = '1' and y.tsdxid = b.szdwid) or
       (y.tsdxlx = '2' and y.tsdxid = b.guid) or
       (y.tsdxlx = '0' and (s.tsdxlx = '2' or s.tsdxlx = '1') and exists
        (select 1
            from YHGL_GG_RYQZYH v
           where y.tsdxid = v.qzid
             and v.yhid = b.guid)))
) a group by a.yhzh
) YJJKDB
/

