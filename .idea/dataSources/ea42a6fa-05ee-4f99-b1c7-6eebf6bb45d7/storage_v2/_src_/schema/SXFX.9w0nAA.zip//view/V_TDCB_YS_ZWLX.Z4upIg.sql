create view V_TDCB_YS_ZWLX as
  select nvl(bb.xmid,aa.xmid) xmid,bb.id,aa.nd,aa.yflx,bb.tdmj,bb.xmzmj,bb.zb,nvl(aa.yflx,0)*bb.zb zwlx from
(select t.xmid, t.nd,t.yflx
  from ( select xmid,to_char(rq, 'yyyy') nd,sum(yflx) yflx from tdcb_czjh group by xmid,to_char(rq, 'yyyy')) t
 where exists (select *
          from tdcb_xmdj t1
         where t.xmid = t1.xmid
           and t1.xmzt <> 99)) aa
           full join
(select a.xmid,a.id,a.tdmj,b.xmzmj,a.tdmj/b.xmzmj zb from
(select t.xmid,t.id,t.tdmj from tdcb_dkxx t where exists (select *
          from tdcb_xmdj t1
         where t.xmid = t1.xmid
           and t1.xmzt <> 99))a
left join
(select t.xmid,sum(t.tdmj) xmzmj from tdcb_dkxx t where exists (select *
          from tdcb_xmdj t1
         where t.xmid = t1.xmid
           and t1.xmzt <> 99) group by t.xmid)b
           on a.xmid=b.xmid where b.xmzmj>0) bb
           on aa.xmid=bb.xmid
/

