create view V_TDCB_DLXX_XMZTQK as
  select a.bm,a.mc,nvl(b.gs,0) gs,nvl(b.mj,0) mj,nvl(b.jsy,0) jsy from tdcb_xxb a left join
(select t.xmzt,count(*) gs,sum(t.tdmj) mj,sum(t.jsy) jsy from V_TDCB_DLXX_XMZT t group by t.xmzt ) b
on a.bm=b.xmzt where a.lx='xmzt' and a.bm<>99
/

