create view V_SGJF_ZB as
  select e1.isbn_code dwbm,e.isbn_code, sum(b.money) money
      from zjsb.budgetdetail b,
           zjsb.budget b1,
           (select t.guid, t.isbn_code
            from jczl.economysection t
            where t.year = to_char(sysdate, 'yyyy')
              and t.isbn_code in (select km from V_sgjf_KZJJKM t)) e,
           jczl.enterprise e1
      where b.economysectionguid = e.guid
        and b.budgetid = b1.budgetid
        and b1.enterpriseguid = e1.guid
        and b.year = to_char(sysdate, 'yyyy')
       -- and e1.isbn_code like '221%'
      group by e1.year,e1.isbn_code,e.isbn_code
/

