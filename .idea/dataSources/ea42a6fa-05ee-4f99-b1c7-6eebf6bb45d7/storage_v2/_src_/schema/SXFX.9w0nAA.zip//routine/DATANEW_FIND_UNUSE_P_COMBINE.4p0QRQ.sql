create function DATANEW_FIND_UNUSE_P_COMBINE(cszh in VARCHAR2,
                                                         v_app in VARCHAR2,
                                                         v_jsx in VARCHAR2)
                                                         return integer is
flag  integer DEFAULT 0;

lenIndex integer DEFAULT 0;

startPosition integer DEFAULT 1;

equalsPosition integer DEFAULT 0;

nameLength integer DEFAULT 0;

p_name VARCHAR2(50);

newIndex  integer DEFAULT 0;

csCount integer DEFAULT 0;
BEGIN

startPosition:=1;

IF cszh IS NULL THEN
  RETURN 0;
END IF;

-- 定位=号位置
SELECT
  instr(cszh,'=', startPosition) INTO equalsPosition from dual;

IF(equalsPosition >0) THEN
 flag := 1;
END IF;
-- 定位;号位置
SELECT
  instr(cszh,';', startPosition) INTO newIndex from dual;
-- 轮询查找
WHILE (equalsPosition > 0 AND flag = 1) LOOP
  nameLength := equalsPosition - startPosition;
-- 截取名称
SELECT
  substr(
    cszh,
    startPosition,
    nameLength
  ) INTO p_name from dual;
-- 查找对应顺序的名称，是否存在
SELECT
  count(1) INTO csCount
FROM
  dn_dy_jsx_cs x
WHERE
  x.yymc = v_app
AND x.jsxmc = v_jsx
AND x.csmc = p_name
AND x.cssx = lenIndex;

-- 不存在则跳出循环
IF csCount = 0 THEN
  flag := 0;


ELSE
  flag := 1;


END
IF;
if newIndex = 0 then
 startPosition := equalsPosition + 1;
else
 startPosition := newIndex + 1;
end if;

SELECT
  instr(cszh,'=', startPosition) INTO equalsPosition from dual;
-- 定位;号位置
SELECT
  instr(cszh,';', startPosition) INTO newIndex from dual;
 lenIndex := lenIndex+1;


END LOOP;


IF (flag = 1 AND lenIndex > 0) THEN
-- 在匹配完成后再看看是否有更多未匹配的定义项，如果有也是无效的
  SELECT
    count(1) INTO csCount
  FROM
    dn_dy_jsx_cs x
  WHERE
    x.yymc = v_app
  AND x.jsxmc = v_jsx
  AND x.cssx = lenIndex;


IF csCount = 1 THEN
 flag := 0;


ELSE
  flag := 1;


END
IF;


END
IF;

RETURN flag;


END DATANEW_FIND_UNUSE_P_COMBINE;
/

