create procedure P_DJ_CZFPHD_JOB is
  v_pd        number;             --状态判断
  v_gk_dm     VARCHAR2(100);      --国库代码
  v_err        VARCHAR2(2000);      --oracle错误
  v_out        VARCHAR2(4000):=',';--核定失败输出
  v_fc        number;
  v_ny        number;
  v_count     number;

begin

  for R_ZB in (SELECT ZB.*,ROWID FROM SRFX_DJ_HDZB ZB WHERE status='0' ORDER BY dotime) loop
    --用户可更改的国库权限
    select a.gk_dm into v_gk_dm
      from srfx_dm_orgdyqx a,charisma.st_sysuser b
      where b.userid=R_ZB.czr and b.orgid=a.orgid;


    FOR R_MX IN(SELECT MX.*,ROWID FROM srfx_dj_hdmx MX WHERE HID=R_ZB.HID AND status='0' ) LOOP
    begin

      --修改DJ_NSRXX表
      UPDATE srfx_dj_nsrxx T SET T.CZFP_DM=R_MX.newczfp where t_DJXH=R_MX.F_DJXH;
      --commit;
      UPDATE srfx_dj_nsr T SET T.CZFP_DM=R_MX.newczfp where F_DJXH in (select t_djxh from srfx_dj_nsrdy where f_djxh =R_MX.F_DJXH union select R_MX.F_DJXH from dual);
      commit;

      --修改征收数据
        update srfx_rtk t set t.CZFP_DM=R_MX.newczfp
          where t.rkrq between R_MX.fromday and R_MX.today and T.GK_DM LIKE CASE WHEN INSTR(V_GK_DM,',')>0 THEN '%' ELSE V_GK_DM END
            and t.f_DJXH =R_MX.f_djxh;
        commit;
      --冲入汇总数据
      --导入当月数
      select count(*) into v_fc from srfx_dm_fc where czfp_dm=R_MX.newczfp;
      if(v_fc<>0)
      then        
       execute immediate'truncate table SRFX_TMP_RTK_SRTJ';

       insert into SRFX_TMP_RTK_SRTJ
       select ny,ZSXM_DM,ZSPM_DM,HY_DM,SKSSQQ,SKSSQZ,DJZCLX_DM,ZSDLFS_DM,SKZL_DM,SKSSSWJG_DM,ZGSWSKFJ_DM,YSKM_DM,SJLY,f.czfp_dm_fc,GK_DM,
       sum(round(SE*f.bl/100,2)) from srfx_rtk t,srfx_dm_fc f
       where t.rkrq between R_MX.fromday and R_MX.today and T.GK_DM LIKE CASE WHEN INSTR(V_GK_DM,',')>0 THEN '%' ELSE V_GK_DM END
       and t.T_DJXH =R_MX.f_djxh and f.czfp_dm=r_mx.newczfp
       group by ny,ZSXM_DM,ZSPM_DM,HY_DM,SKSSQQ,SKSSQZ,DJZCLX_DM,ZSDLFS_DM,SKZL_DM,SKSSSWJG_DM,ZGSWSKFJ_DM,YSKM_DM,SJLY,GK_DM,f.czfp_dm_fc;
       --commit;


       insert into SRFX_TMP_RTK_SRTJ
       select ny,ZSXM_DM,ZSPM_DM,HY_DM,SKSSQQ,SKSSQZ,DJZCLX_DM,ZSDLFS_DM,SKZL_DM,SKSSSWJG_DM,ZGSWSKFJ_DM,YSKM_DM,SJLY,R_MX.oldczfp,GK_DM,
       sum(-SE) from srfx_rtk t
       where t.rkrq between R_MX.fromday and R_MX.today and T.GK_DM LIKE CASE WHEN INSTR(V_GK_DM,',')>0 THEN '%' ELSE V_GK_DM END
       and t.T_DJXH =R_MX.f_djxh
       group by ny,ZSXM_DM,ZSPM_DM,HY_DM,SKSSQQ,SKSSQZ,DJZCLX_DM,ZSDLFS_DM,SKZL_DM,SKSSSWJG_DM,ZGSWSKFJ_DM,YSKM_DM,SJLY,GK_DM;
       commit;
      else
       execute immediate'truncate table SRFX_TMP_RTK_SRTJ';

       insert into SRFX_TMP_RTK_SRTJ
       select ny,ZSXM_DM,ZSPM_DM,HY_DM,SKSSQQ,SKSSQZ,DJZCLX_DM,ZSDLFS_DM,SKZL_DM,SKSSSWJG_DM,ZGSWSKFJ_DM,YSKM_DM,SJLY,R_MX.newczfp,GK_DM,
       sum(SE) from srfx_rtk t
       where t.rkrq between R_MX.fromday and R_MX.today and T.GK_DM LIKE CASE WHEN INSTR(V_GK_DM,',')>0 THEN '%' ELSE V_GK_DM END
       and t.T_DJXH =R_MX.f_djxh
       group by ny,ZSXM_DM,ZSPM_DM,HY_DM,SKSSQQ,SKSSQZ,DJZCLX_DM,ZSDLFS_DM,SKZL_DM,SKSSSWJG_DM,ZGSWSKFJ_DM,YSKM_DM,SJLY,GK_DM;
       --commit;

       insert into SRFX_TMP_RTK_SRTJ
       select ny,ZSXM_DM,ZSPM_DM,HY_DM,SKSSQQ,SKSSQZ,DJZCLX_DM,ZSDLFS_DM,SKZL_DM,SKSSSWJG_DM,ZGSWSKFJ_DM,YSKM_DM,SJLY,R_MX.oldczfp,GK_DM,
       sum(-SE) from srfx_rtk t
       where t.rkrq between R_MX.fromday and R_MX.today and T.GK_DM LIKE CASE WHEN INSTR(V_GK_DM,',')>0 THEN '%' ELSE V_GK_DM END
       and t.T_DJXH =R_MX.f_djxh
       group by ny,ZSXM_DM,ZSPM_DM,HY_DM,SKSSQQ,SKSSQZ,DJZCLX_DM,ZSDLFS_DM,SKZL_DM,SKSSSWJG_DM,ZGSWSKFJ_DM,YSKM_DM,SJLY,GK_DM;
       commit;
      end if;       
      --导入累计数
      
      
       execute immediate'truncate table SRFX_TMP_RTK_SRTJ_lb';

       for r_hz in (select distinct ny from SRFX_TMP_RTK_SRTJ order by ny) loop
       insert into SRFX_TMP_RTK_SRTJ_lb
       select r_hz.ny,ZSXM_DM,ZSPM_DM,HY_DM,SKSSQQ,SKSSQZ,DJZCLX_DM,ZSDLFS_DM,SKZL_DM,SKSSSWJG_DM,ZGSWSKFJ_DM,YSKM_DM,SJLY,CZFP_DM,GK_DM,
       sum(SE_YLJ) from SRFX_TMP_RTK_SRTJ
       where ny between substr(r_hz.ny,1,4)||'01' and r_hz.ny
       group by ZSXM_DM,ZSPM_DM,HY_DM,SKSSQQ,SKSSQZ,DJZCLX_DM,ZSDLFS_DM,SKZL_DM,SKSSSWJG_DM,ZGSWSKFJ_DM,YSKM_DM,SJLY,CZFP_DM,GK_DM;
       --commit;
       end loop;
       commit;
       ---最大日期小于12,补充累计数
       select max(ny) into v_ny from SRFX_TMP_RTK_SRTJ;
       select to_number(substr(v_ny,5,2)) into v_count from dual;
       if v_count<12 
         then loop
       v_ny:=v_ny+1;
       insert into SRFX_TMP_RTK_SRTJ_lb
       select v_ny,ZSXM_DM,ZSPM_DM,HY_DM,SKSSQQ,SKSSQZ,DJZCLX_DM,ZSDLFS_DM,SKZL_DM,SKSSSWJG_DM,ZGSWSKFJ_DM,YSKM_DM,SJLY,CZFP_DM,GK_DM,
       sum(SE_YLJ) from SRFX_TMP_RTK_SRTJ
       where ny between substr(v_ny,1,4)||'01' and v_ny
       group by ZSXM_DM,ZSPM_DM,HY_DM,SKSSQQ,SKSSQZ,DJZCLX_DM,ZSDLFS_DM,SKZL_DM,SKSSSWJG_DM,ZGSWSKFJ_DM,YSKM_DM,SJLY,CZFP_DM,GK_DM;
       --commit;           
       v_count:=v_count+1;
       if v_count=12
         then exit;
         end if;
         end loop;
         commit;
       end if;
         

       insert into SRFX_RTK_SRTJ
       select ny,ZSXM_DM,ZSPM_DM,HY_DM,DJZCLX_DM,ZSDLFS_DM,SKZL_DM,SKSSSWJG_DM,ZGSWSKFJ_DM,YSKM_DM,SJLY,CZFP_DM,GK_DM,
       sum(se_ylj),sum(se_nlj),SKSSQQ,SKSSQZ,1
       from
       (
       select ny,ZSXM_DM,ZSPM_DM,HY_DM,DJZCLX_DM,ZSDLFS_DM,SKZL_DM,SKSSSWJG_DM,ZGSWSKFJ_DM,YSKM_DM,SJLY,CZFP_DM,GK_DM,
       sum(se_ylj) se_ylj,0 se_nlj,SKSSQQ,SKSSQZ from SRFX_TMP_RTK_SRTJ
       group by ny,ZSXM_DM,ZSPM_DM,HY_DM,DJZCLX_DM,SKSSQQ,SKSSQZ,ZSDLFS_DM,SKZL_DM,SKSSSWJG_DM,ZGSWSKFJ_DM,YSKM_DM,SJLY,CZFP_DM,GK_DM
       union all
       select ny,ZSXM_DM,ZSPM_DM,HY_DM,DJZCLX_DM,ZSDLFS_DM,SKZL_DM,SKSSSWJG_DM,ZGSWSKFJ_DM,YSKM_DM,SJLY,CZFP_DM,GK_DM,
       0 se_ylj,sum(se_nlj) se_nlj,SKSSQQ,SKSSQZ from SRFX_TMP_RTK_SRTJ_lb
       group by ny,ZSXM_DM,ZSPM_DM,HY_DM,DJZCLX_DM,SKSSQQ,SKSSQZ,ZSDLFS_DM,SKZL_DM,SKSSSWJG_DM,ZGSWSKFJ_DM,YSKM_DM,SJLY,CZFP_DM,GK_DM
       )
       group by ny,ZSXM_DM,ZSPM_DM,HY_DM,DJZCLX_DM,SKSSQQ,SKSSQZ,ZSDLFS_DM,SKZL_DM,SKSSSWJG_DM,ZGSWSKFJ_DM,YSKM_DM,SJLY,CZFP_DM,GK_DM;
       commit;
         
       UPDATE srfx_dj_hdmx T SET status='1' WHERE ROWID=R_MX.ROWID;
       commit;
    exception when others then
      rollback;
      v_err:=substr(sqlerrm,1,80);
      v_out:=v_out||','||R_MX.f_djxh;
      UPDATE srfx_dj_hdmx T SET status='2' WHERE ROWID=R_MX.ROWID;
      dbms_output.put_line(v_err);
    end;
    end loop;
    
    select count(*) into v_pd from srfx_dj_hdzb z,srfx_dj_hdmx m where z.hid=R_ZB.hid and z.hid=m.hid and m.status='2';
       if v_pd>1 then
           UPDATE SRFX_DJ_HDZB A SET status='3' WHERE ROWID=R_ZB.ROWID;
          -- commit;
         else
           UPDATE SRFX_DJ_HDZB A SET status='1',A.FINSHTIME=SYSDATE WHERE ROWID=R_ZB.ROWID;
           --commit;
         end if ;
         commit;
  END LOOP;
  COMMIT;
   INSERT INTO SRFX_RRO_LOG
  VALUES('ADMIN',SYSDATE,'P_DJ_CZFPHD_JOB','JOB核定修改完成');
   COMMIT;
exception when others then
  rollback;
  v_err:=substr(sqlerrm,1,2000);
     INSERT INTO SRFX_RRO_LOG
  VALUES('ADMIN',SYSDATE,'P_DJ_CZFPHD_JOB',v_err);
   COMMIT;
  dbms_output.put_line(v_err);
End P_DJ_CZFPHD_JOB;
/

