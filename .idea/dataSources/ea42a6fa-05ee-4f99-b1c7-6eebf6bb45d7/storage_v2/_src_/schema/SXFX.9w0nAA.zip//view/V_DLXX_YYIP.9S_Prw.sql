create view V_DLXX_YYIP as
  select 'TDCB' yybm,'土地储备' yymc,'土地储备地理信息展示' zsmc,'土地储备地理信息标注' bzmc,'10.41.130.58' ip,'9080' dk,'1111'bz from dual
union all
select 'ZFTZ' yybm,'政府投资' yymc,'政府投资地理信息展示','政府投资地理信息标注','10.41.130.59' ip,'8080' dk,'222'bz from dual
/

