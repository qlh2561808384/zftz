create view V_TDCB_DLXX_TDSYQK1 as
  select "ND",nvl("SR",0) sr,nvl("BJ",0) bj,nvl("LX",0)lx,ssxzqh,'TDCB'yybm from (
select nvl(a.nd,b.nd) nd,a.ssxzqh,nvl(a.sr,0) sr,b.bj,b.lx from
(select to_char(t.yjcrrq, 'yyyy') nd,(select ssxzqy from tdcb_xmdj where xmid=t.xmid) ssxzqh, nvl(sum(t.yqtdsr),0) sr
  from tdcb_dkxx t where t.xmid not in (select xmid from tdcb_xmdj where xmzt<>'99')--where t.sjcrrq is not null
 group by to_char(t.yjcrrq, 'yyyy'),t.xmid)a
 full join
 (select to_char(t.rq, 'yyyy') nd,(select ssxzqy from tdcb_xmdj where xmid=t.xmid) ssxzqh,nvl(sum(t.yfbj),0) bj,nvl(sum(t.yflx),0) lx from tdcb_czjh t
 where t.xmid not in (select xmid from tdcb_xmdj where xmzt<>'99')
 group by to_char(t.rq, 'yyyy'),t.xmid )b
 on a.nd=b.nd and a.ssxzqh=b.ssxzqh)
 order by nd
/

