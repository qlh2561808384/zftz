create procedure P_YSDW_DWYBMXX(dwbmCursor out sys_refcursor, -- 调用返回结果集
                                             V_ISBIN_CODE in varchar2,
                                             V_USERID in varchar2
                                             ) is
ISBIN_CODE varchar2(100);
countZero number(2);
countZero2 number(2);
begin
  select count(1)
  into countZero2
  from v_dn_mh_user@sjfxpt     t,
       v_dn_mh_org             t1,
       jczl.enterprise         t3
  where t."ORGNAME" = t1.org_id_
   and t1.C_ORG_CODE = t3.isbn_code
   and t3.year = to_char(sysdate,'yyyy')
   and  t."id"= V_USERID;--'1_79e37421-306f-42fb-8'
   
   if countZero2 = 0 then
     open dwbmCursor for
      select '编码：空' bm,'名称：空' mc,'法人：空' dwxjsl_or_fr 
      from dual;
    else
      
      --用于判断用户类型（单位 or 部门）
      select t1.C_ORG_CODE
      into ISBIN_CODE
      from v_dn_mh_user@sjfxpt     t,
           v_dn_mh_org             t1,
           jczl.enterprise         t3
      where t."ORGNAME" = t1.org_id_
       and t1.C_ORG_CODE = t3.isbn_code
       and t3.year = to_char(sysdate,'yyyy')
       and  t."id"= V_USERID;--'1_79e37421-306f-42fb-8'
   
      --用于判断传过来的值是否能查到数据
      select count(e.isbn_code) 
      into  countZero 
      from jczl.enterprise e where e.year=to_char(sysdate,'yyyy') and e.isbn_code = V_ISBIN_CODE;
  
      if ISBIN_CODE like '%001' then
        if V_ISBIN_CODE like '%001' then 
          open dwbmCursor for
          select e.isbn_code bm,e.name mc,'法人：'||e.frdbname dwxjsl_or_fr 
          from jczl.enterprise e where e.year=to_char(sysdate,'yyyy') and e.isbn_code = V_ISBIN_CODE;
        else 
          open dwbmCursor for
          --部门信息卡片
          select 
          --ee1.parent_guid 部门编码,
          ee2.isbn_code bm,
          ee2.name mc,
          '下级单位数量：'||ee1.dwtotals dwxjsl_or_fr 
          from
          (
          select e.parent_guid,count(*) dwtotals
          from 
          jczl.enterprise e 
          where e.parent_guid=
          (
          select t.guid from jczl.enterprise t where t.enabled=1 and t.year=to_char(sysdate,'yyyy') and t.isbn_code = V_ISBIN_CODE
          )
          and e.enabled=1 and e.year=to_char(sysdate,'yyyy') 
          group by e.parent_guid
          ) ee1 left join
          (
          select e.guid,e.name,e.isbn_code from jczl.enterprise e 
          where e.guid=
          (
          select t.guid from jczl.enterprise t where t.enabled=1 and t.year=to_char(sysdate,'yyyy') and t.isbn_code = V_ISBIN_CODE
          )
          ) ee2
          on ee1.parent_guid=ee2.guid; 
        end if;
      
      else 
        if countZero = 0  then
        open dwbmCursor for
          select '编码：空' bm,'名称：空' mc,'法人：空' dwxjsl_or_fr 
          from dual;
        else
          open dwbmCursor for
          select e.isbn_code bm,e.name mc,'法人：'||e.frdbname dwxjsl_or_fr 
          from jczl.enterprise e where e.year=to_char(sysdate,'yyyy') and e.isbn_code = V_ISBIN_CODE;
        end if;
      end if;
    end if;
end P_YSDW_DWYBMXX;
/

