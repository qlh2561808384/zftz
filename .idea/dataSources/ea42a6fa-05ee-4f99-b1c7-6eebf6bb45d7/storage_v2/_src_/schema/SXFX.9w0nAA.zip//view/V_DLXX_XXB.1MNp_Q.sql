create view V_DLXX_XXB as
  select t.id,t.bm,t.mc,t.fjbm,t.yxbz,
case when t.fjbm='AA' then 'AA' WHEN t.fjbm='BB' then 'BB' when t.fjbm='CC' then 'CC' ELSE t.lx END LX,t.ms,'TDCB' yybm
  from tdcb_xxb t where t.lx in ('xmzt','zqqk','CC','btlx','bzlx','dxlx','tjlx')
/

