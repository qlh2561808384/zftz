create view V_YMTB_DATA as
  select case
        when t.mc = 'J4' then '交办件'
        when t.mc = 'D4' then '督办件'
        when t.mc = 'S4' then '审批件'
        when t.mc = 'F4' then '信访件'
        when t.mc = 'R4' then '任务督查件'
        when t.mc = 'Z4' then '项目协办件'
        when t.mc = 'Q4' then '其他'
       end mc,
       t.tqbj,
       t.aqbj,
       t.yqbj，
       t.wbj
  from YMTB_DATA t
/

