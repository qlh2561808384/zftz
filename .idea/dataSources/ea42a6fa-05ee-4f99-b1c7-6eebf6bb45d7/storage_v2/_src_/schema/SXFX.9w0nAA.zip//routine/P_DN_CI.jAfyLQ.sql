create procedure p_dn_ci(out_cur out sys_refcursor,v_App in VARCHAR2,  -- 应用
  v_CI_or_CF in VARCHAR2) authid current_user is
   i_count_field number(2) DEFAULT 0;
   v_log VARCHAR2(4096) DEFAULT '';
   v_err VARCHAR2(4096);
   v_ci VARCHAR2(50) DEFAULT '';
   v_cf VARCHAR2(50) DEFAULT '';
   i_index number(2);
   v_log_count number(1);
BEGIN

  -- ------------------------
  -- 判断v_ci和v_Cf
  -- ------------------------
  i_index := INSTR(v_CI_or_CF,'.');
  IF i_index > 0 THEN
    v_ci := substr(v_CI_or_cF,1,i_index-1);
    v_cf := substr(v_CI_or_cF,i_index+1,length(v_CI_or_CF));
  ELSE
    v_ci := v_CI_or_CF;
    v_cf := '';
  END IF;

  SELECT COUNT(1) INTO v_log_count FROM dn_cc_jsx_yjg_jg WHERE yymc = v_App AND jsxmc = v_ci;
    IF v_log_count = 0 THEN
        INSERT INTO dn_cc_jsx_yjg_jg(guid,yymc,jsxmc,zdmc,rzxx,zxlx,rzbz,zxr,kssj,jssj) VALUES(sys_guid(),v_App,v_ci,v_cf,null,3,1,'database',SYSDATE(),null);
    END IF;
  UPDATE dn_cc_jsx_yjg_jg SET rzbz = 2 WHERE yymc = v_App AND jsxmc = v_ci;

  SELECT COUNT(1) INTO i_index FROM dn_dy_jsx WHERE yymc =v_App AND jsxmc = v_ci;
  IF i_index = 0 THEN
    UPDATE dn_cc_jsx_yjg_jg SET rzbz = 4,rzxx = '{"error":"不存在预加工计算项'|| v_ci ||'","log":"' ||  '"}',jssj=SYSDATE() WHERE yymc = v_App AND jsxmc = v_ci;
    OPEN out_cur for SELECT 1 ZT,'{\"error\":\"不存在预加工计算项' || v_ci || '\"}' CWXX  FROM DUAL;
    return;
  END IF;

  IF v_cf is not null THEN
    SELECT COUNT(*) INTO i_index FROM dn_dy_jsx_zd WHERE yymc = v_App AND jsxmc = v_ci AND ZDMC = v_cf;
    IF i_index = 0 THEN
    UPDATE dn_cc_jsx_yjg_jg SET rzbz = 4,rzxx = '{"error":"不存在预加工计算项字段'|| v_ci || '.' || v_cf || '","log":"' ||  '"}',jssj=SYSDATE() WHERE yymc = v_App AND jsxmc = v_ci;
      OPEN out_cur for SELECT 1 ZT,'{\"error\":\"不存在预加工计算项字段'|| v_ci || '.' || v_cf || '\"}' CWXX  FROM DUAL;
      return;
    END IF;
  ELSE
    SELECT COUNT(*) INTO i_index FROM dn_dy_jsx_zd WHERE yymc = v_App AND jsxmc = v_ci;
    IF i_index = 0 THEN
    UPDATE dn_cc_jsx_yjg_jg SET rzbz = 4,rzxx = '{"error":"预加工计算项' || v_ci || '不存在字段' || '","log":"' ||  '"}',jssj=SYSDATE() WHERE yymc = v_App AND jsxmc = v_ci;
      OPEN out_cur for SELECT 1 ZT,'{\"error\":\"预加工计算项' || v_ci || '不存在字段' || '\"}' CWXX  FROM DUAL;
      return;
    END IF;
  END IF;
  p_dn_ci_compute(
      v_App, v_ci,v_cf,
      i_count_field,
      v_err,v_log
    );

  IF v_err is not null THEN
    UPDATE dn_cc_jsx_yjg_jg SET rzbz = 4,rzxx = '{"error":"' || v_err || '","log":[' || v_log || ']}',jssj=SYSDATE() WHERE yymc = v_App AND jsxmc = v_ci;
    OPEN out_cur for SELECT 1 ZT,'{\"error\":\"' || v_err || '\",\"log\":[' || v_log || ']}' CWXX
    FROM DUAL;
  ELSE
    UPDATE dn_cc_jsx_yjg_jg SET rzbz = 3,rzxx =
          '{"volume":"' || v_App || '",' ||
          '"target":"' || v_CI_or_CF || '",' ||
          '"fieldCount":"' || i_count_field || '",' ||
          '"log":[' || v_log || ']}',jssj=SYSDATE() WHERE yymc = v_App AND jsxmc = v_ci;
    OPEN out_cur for SELECT 0 ZT,
          '{\"volume\":\"' || v_App || '\",' ||
          '\"target\":\"' || v_CI_or_CF || '\",' ||
          '\"fieldCount\":\"' || i_count_field || '\",' ||
          '\"log\":[' || v_log || ']}' CWXX
    FROM DUAL;
  END IF;
  COMMIT;
  EXCEPTION
      WHEN OTHERS THEN
        Rollback;
  return;
END;
/

